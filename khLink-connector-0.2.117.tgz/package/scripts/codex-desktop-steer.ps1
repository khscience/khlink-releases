﻿# Hand a message to the turn that Codex Desktop is running in a task, the way
# a person would: put it in the task's composer, press Queue (while a turn
# runs the send button queues), then press that row's Steer button. When no
# turn is running, Send starts the next turn instead.
#
# Codex Desktop 26.1027 (ChatGPT.exe) no longer exposes its page to native
# IUIAutomation clients (the Rust desktop adapter sees only an empty D3D
# child), but .NET UI Automation still reads and drives it. Rows that another
# app-server put in the task's queue are not shown in the window, so a steer
# must go through the window's own queue (2026-10-31).
#
# Safety: nothing is written unless the window shows the requested task (its
# title) and its composer is empty, so a half-typed desktop draft is never
# sent or overwritten. The window is never brought to the front.
# Output: one JSON line {ok, code, delivery, message}; a {"phase":"write"}
# line comes first once the message may have reached Codex.
param(
  [Parameter(Mandatory = $true)][string]$ThreadId,
  # The task's title, UTF-8 Base64 (a title may start with '-').
  [Parameter(Mandatory = $true)][string]$TitleB64,
  [Parameter(Mandatory = $true)][string]$TextFile
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
$AE = [System.Windows.Automation.AutomationElement]
$Scope = [System.Windows.Automation.TreeScope]::Descendants

function Out-Result($ok, $code, $delivery, $message) {
  [Console]::Out.WriteLine((@{ ok = $ok; code = $code; delivery = $delivery; message = $message } | ConvertTo-Json -Compress))
  exit 0
}
if ($ThreadId -notmatch '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$') { Out-Result $false 'invalid_thread_id' 'not_sent' 'A valid Codex task id is required' }
$title = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($TitleB64)).Trim()
$text = [IO.File]::ReadAllText($TextFile, [Text.Encoding]::UTF8)
if (-not $title -or -not $text.Trim()) { Out-Result $false 'missing_input' 'not_sent' 'Task title and message are required' }

# Zero-width request markers may or may not survive in the accessible text.
function Plain([string]$value) { ($value -replace '[​-‍⁠⁣﻿]', '').Trim() }

function Get-CodexWindow {
  $best = $null; $bestArea = -1
  foreach ($p in Get-Process -Name ChatGPT -ErrorAction SilentlyContinue) {
    if ($p.MainWindowHandle -eq 0 -or $p.MainWindowTitle -ne 'ChatGPT') { continue }
    try { if ($p.Path -notlike '*\OpenAI.Codex_*') { continue } } catch { continue }
    $w = $AE::FromHandle($p.MainWindowHandle); $r = $w.Current.BoundingRectangle
    $area = if ($r.IsEmpty) { 0 } else { $r.Width * $r.Height }
    if ($area -gt $bestArea) { $best = $w; $bestArea = $area }
  }
  $best
}
function Get-ActiveTitle($w) {
  $doc = $w.FindFirst($Scope, (New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::Document)))
  if ($doc) { $doc.Current.Name.Trim() }
}
function Get-Composer($w) {
  foreach ($e in $w.FindAll($Scope, (New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::Edit)))) {
    if ($e.Current.ClassName -like 'ProseMirror*' -and -not $e.Current.IsOffscreen) { return $e }
  }
}
function Get-Button($w, [string[]]$names) {
  foreach ($e in $w.FindAll($Scope, (New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)))) {
    if ($names -contains $e.Current.Name -and -not $e.Current.IsOffscreen -and $e.Current.IsEnabled) { return $e }
  }
}
function Invoke-Element($e) { $e.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke() }
# The Steer button of the queued row that shows this message.
function Get-RowSteer($w, [string]$firstLine) {
  $walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker
  foreach ($steer in $w.FindAll($Scope, (New-Object System.Windows.Automation.PropertyCondition($AE::NameProperty, 'Steer')))) {
    $row = $walker.GetParent($steer)
    for ($level = 0; $row -and $level -lt 4; $level++) {
      $names = @($row.FindAll($Scope, [System.Windows.Automation.Condition]::TrueCondition) | ForEach-Object { Plain $_.Current.Name })
      if (@($names | Where-Object { $_ -eq 'Steer' }).Count -gt 1) { break }
      if ($names | Where-Object { $_ -eq $firstLine -or $_ -like "*: $firstLine" -or ($firstLine.Length -ge 12 -and $_.StartsWith($firstLine.Substring(0, 12))) }) { return $steer }
      $row = $walker.GetParent($row)
    }
  }
}

$w = Get-CodexWindow
if (-not $w) { Out-Result $false 'desktop_not_ready' 'not_sent' 'Codex Desktop was not found' }
if ((Get-ActiveTitle $w) -ne $title) {
  # The task id is the identity; the title only confirms the window shows it.
  Start-Process "codex://threads/$ThreadId"
  for ($i = 0; $i -lt 40 -and (Get-ActiveTitle $w) -ne $title; $i++) { Start-Sleep -Milliseconds 200; $w = Get-CodexWindow }
  if ((Get-ActiveTitle $w) -ne $title) { Out-Result $false 'task_identity_unconfirmed' 'not_sent' 'Codex Desktop did not show the requested task' }
}
$composer = $null
for ($i = 0; $i -lt 25 -and -not $composer; $i++) { $composer = Get-Composer $w; if (-not $composer) { Start-Sleep -Milliseconds 200 } }
if (-not $composer) { Out-Result $false 'composer_unavailable' 'not_sent' 'The task has no composer now (an approval may be waiting on the computer)' }
$value = $composer.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
$before = Plain $value.Current.Value
if ($before -and $before -ne (Plain $composer.Current.Name)) { Out-Result $false 'draft_present' 'not_sent' 'The Codex Desktop composer already holds a draft' }

$value.SetValue($text)
Start-Sleep -Milliseconds 300
if ((Plain $value.Current.Value) -ne (Plain $text)) { try { $value.SetValue('') } catch {}; Out-Result $false 'composer_write_failed' 'not_sent' 'Codex Desktop did not take the text' }
$queue = $null; $send = $null
for ($i = 0; $i -lt 15 -and -not $queue -and -not $send; $i++) {
  $queue = Get-Button $w @('Queue', '加入队列'); if (-not $queue) { $send = Get-Button $w @('Send', '发送') }
  if (-not $queue -and -not $send) { Start-Sleep -Milliseconds 100 }
}
if (-not $queue -and -not $send) { try { $value.SetValue('') } catch {}; Out-Result $false 'control_not_found' 'not_sent' 'Codex Desktop send control was not available' }

[Console]::Out.WriteLine('{"phase":"write"}')
if ($send) {
  # No turn is running: the message starts the next one.
  Invoke-Element $send
  Out-Result $true 'sent' 'confirmed' 'Codex Desktop started a turn with the message'
}
Invoke-Element $queue
$firstLine = Plain (($text -split "\r?\n" | Where-Object { (Plain $_) } | Select-Object -First 1))
$steer = $null
for ($i = 0; $i -lt 30 -and -not $steer; $i++) { Start-Sleep -Milliseconds 200; $steer = Get-RowSteer $w $firstLine }
if (-not $steer) { Out-Result $true 'steer_deferred' 'confirmed' 'Codex Desktop kept the message in the task queue' }
Invoke-Element $steer
for ($i = 0; $i -lt 15; $i++) {
  Start-Sleep -Milliseconds 200
  if (-not (Get-RowSteer $w $firstLine)) { Out-Result $true 'steer_accepted' 'confirmed' 'Sent to the running Codex Desktop turn' }
}
Out-Result $true 'steer_deferred' 'confirmed' 'Codex Desktop kept the message in the task queue'
