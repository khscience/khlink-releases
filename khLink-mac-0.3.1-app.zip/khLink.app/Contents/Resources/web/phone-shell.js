// Phone command line settings: the only place where the switch and the
// allowed phones can be changed (docs/zh-CN/phone-shell-2026-11.md).
(function () {
  'use strict';
  const el = (id) => document.getElementById(id);
  let state = null;
  let timer = null;

  const minutes = (sec) => (sec >= 60 ? `${Math.round(sec / 60)} 分钟` : `${sec} 秒`);
  const when = (ms) => (ms ? new Date(ms).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false }) : '');
  const shortId = (id) => String(id || '').slice(0, 8);

  function node(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }

  function phoneRow(phone, actions) {
    const row = node('div', 'phone-shell-item');
    const label = node('div', 'phone-shell-name');
    label.append(node('strong', '', phone.name || '手机'), node('span', 'subtle', ` ${shortId(phone.id)} · ${when(phone.at)}`));
    row.append(label);
    const buttons = node('div', 'phone-shell-actions');
    for (const [text, cls, handler] of actions) {
      const b = node('button', cls, text);
      b.addEventListener('click', handler);
      buttons.append(b);
    }
    row.append(buttons);
    return row;
  }

  function render() {
    if (!state) return;
    el('phone-shell-toggle').checked = state.enabled;
    const select = el('phone-shell-timeout');
    select.replaceChildren(...state.timeouts.map((sec) => { const o = node('option', '', minutes(sec)); o.value = String(sec); return o; }));
    select.value = String(state.timeoutSec);
    const devices = el('phone-shell-devices');
    devices.replaceChildren(...(state.devices.length
      ? state.devices.map((p) => phoneRow(p, [['移除', 'link', () => allow(p, false)]]))
      : [node('p', 'subtle', '还没有允许任何手机')]));
    const requests = el('phone-shell-requests');
    requests.replaceChildren(...(state.requests.length
      ? state.requests.map((p) => phoneRow(p, [['允许', 'primary', () => allow(p, true)], ['忽略', 'link', () => dismiss(p)]]))
      : [node('p', 'subtle', state.enabled ? '暂无' : '开启后，手机点「在电脑上运行」时会出现在这里')]));
    const audit = el('phone-shell-audit');
    const starts = state.audit.filter((row) => row.event === 'start').slice(0, 20);
    const ends = new Map(state.audit.filter((row) => row.event === 'end').map((row) => [row.run, row]));
    audit.replaceChildren(...(starts.length ? starts.map((row) => {
      const end = ends.get(row.run);
      const item = node('div', 'phone-shell-log');
      const result = !end ? '运行中' : end.state === 'exited' ? `退出码 ${end.exitCode}` : end.state === 'timeout' ? '超时停止' : end.state === 'cancelled' ? '已停止' : '启动失败';
      item.append(node('div', 'subtle', `${when(row.at)} · ${row.deviceName || shortId(row.device)} · ${row.shell} · ${result}`));
      item.append(node('code', '', row.command.length > 300 ? `${row.command.slice(0, 300)}…` : row.command));
      return item;
    }) : [node('p', 'subtle', '还没有运行记录')]));
  }

  async function call(command, args) {
    try { state = await invoke(command, args); render(); }
    catch (error) { toast(String(error)); }
  }

  const load = () => call('phone_shell_state');
  const allow = (phone, value) => call('phone_shell_allow', { id: phone.id, name: phone.name || null, allow: value });
  const dismiss = (phone) => call('phone_shell_dismiss', { id: phone.id });
  const save = (enabled) => call('phone_shell_set', { enabled, timeoutSec: Number(el('phone-shell-timeout').value) || 120 });

  function open() {
    show('account-sheet', false);
    show('phone-shell-sheet');
    load();
    clearInterval(timer);
    // New requests and finished runs appear without reopening the sheet.
    timer = setInterval(() => { if (el('phone-shell-sheet').classList.contains('hidden')) clearInterval(timer); else load(); }, 3000);
  }

  window.addEventListener('DOMContentLoaded', () => {
    el('sheet-phone-shell').addEventListener('click', open);
    el('phone-shell-toggle').addEventListener('change', (event) => {
      if (event.target.checked && !window.confirm('开启后，你允许的手机可以在这台电脑上运行命令，效果和你坐在电脑前打开命令行一样。\n\n只允许你自己的手机；手机丢失时先在这里关闭。\n\n确定开启吗？')) {
        event.target.checked = false;
        return;
      }
      save(event.target.checked);
    });
    el('phone-shell-timeout').addEventListener('change', () => save(el('phone-shell-toggle').checked));
    el('phone-shell-stop').addEventListener('click', () => save(false));
  });
})();
