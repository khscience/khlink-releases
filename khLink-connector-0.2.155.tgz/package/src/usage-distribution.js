// Statistics only from native usage records. Never reads credentials or invokes a model.
const safe = value => Number.isSafeInteger(value) && value >= 0 ? value : null;

function dshDistribution(records, periods, truncated = false) {
  const seen = new Set();
  const result = { today: 0, month: 0, all: 0 };
  let earliest = Infinity, missingTime = false, missingUsage = false, observed = 0;
  for (const record of records || []) {
    const event = record?.event || record;
    const at = Number(event?.time);
    if (Number.isFinite(at) && at > 0) earliest = Math.min(earliest, at);
    if (event?.type !== 'assistant/message') continue;
    const id = event.seq;
    if (!Number.isSafeInteger(id) || seen.has(id)) { if (!Number.isSafeInteger(id)) missingUsage = true; continue; }
    seen.add(id);
    const usage = event.data?.usage;
    if (!usage || !['inputTokens', 'outputTokens', 'cacheReadTokens', 'cacheWriteTokens'].some(key => usage[key] != null)) { missingUsage = true; continue; }
    const values = ['inputTokens', 'outputTokens', 'cacheReadTokens', 'cacheWriteTokens'].map(key => usage[key] == null ? 0 : safe(usage[key]));
    if (values.some(value => value == null)) { missingUsage = true; continue; }
    const total = values.reduce((sum, value) => sum + value, 0);
    if (!Number.isSafeInteger(total)) { missingUsage = true; continue; }
    observed++;
    result.all += total;
    if (!Number.isFinite(at) || at <= 0) { missingTime = true; continue; }
    if (at >= periods.todayFrom) result.today += total;
    if (at >= periods.monthFrom) result.month += total;
  }
  if (!observed) return { status: 'unavailable', reason: '此对话没有可读取的 Token 记录' };
  const part = from => Boolean(missingTime || missingUsage || (truncated && earliest >= from));
  return { status: 'ready', periods: { ...periods,
    today: { total: result.today, partial: part(periods.todayFrom) },
    month: { total: result.month, partial: part(periods.monthFrom) },
    all: { total: result.all, partial: Boolean(truncated || missingUsage) } } };
}

async function readDshDistribution(client, meta, periods) {
  if (!client || !meta?.sessionId) return { status: 'unavailable', reason: '暂时找不到 DSH 对话记录' };
  const page = await client.sessionPage(meta.sessionId, Math.max(0, Number(meta.syncedSeq) || 0), 800);
  const records = Array.isArray(page?.records) ? page.records : [];
  // Different DSH versions expose the page boundary differently. Treat a full
  // page as incomplete unless the Host explicitly proves otherwise.
  const truncated = page?.hasMore === true || (records.length >= 800 && page?.hasMore !== false);
  return dshDistribution(records, periods, truncated);
}

module.exports = { dshDistribution, readDshDistribution };
