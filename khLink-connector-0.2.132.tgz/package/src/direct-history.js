const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { encryptJson, decryptJson } = require('./crypto');
const { LatestFileWriter } = require('./latest-file-writer');

class DirectHistory {
  constructor(directory, config) {
    this.directory = directory; this.config = config;
    fs.mkdirSync(directory, { recursive: true });
    this.indexFile = path.join(directory, 'threads.json');
    this.fresh = !fs.existsSync(this.indexFile);
    this.items = new Map(); this.writers = new Map();
    this.ready = this.read(this.indexFile).then((rows) => { this.threads = new Map(rows.map((row) => [row.id, row])); });
  }
  async read(file) {
    try { return JSON.parse(await fs.promises.readFile(file, 'utf8')); }
    catch (error) { if (error.code === 'ENOENT') return []; throw error; }
  }
  async write(file, value) {
    let entry = this.writers.get(file);
    if (!entry) {
      entry = { error: null };
      entry.writer = new LatestFileWriter(file, { onError: (error) => { entry.error = error; } });
      this.writers.set(file, entry);
    }
    entry.error = null; await entry.writer.write(JSON.stringify(value));
    if (entry.error) throw entry.error;
  }
  async flush() { await this.ready; await Promise.all([...this.writers.values()].map((entry) => entry.writer.running)); }
  itemFile(id) { return path.join(this.directory, `${crypto.createHash('sha256').update(id).digest('hex')}.json`); }
  async withItems(file, use) {
    let entry = this.items.get(file);
    if (!entry) {
      entry = { busy: 0, rows: this.read(file).then((rows) => new Map(rows.map((row) => [row.id, row]))) };
      this.items.set(file, entry);
    } else { this.items.delete(file); this.items.set(file, entry); }
    entry.busy++;
    try { return await use(await entry.rows); }
    finally {
      entry.busy--;
      for (const [key, value] of this.items) {
        if (this.items.size <= 8) break;
        if (!value.busy) this.items.delete(key);
      }
    }
  }
  async put(route, body) {
    await this.ready;
    if (route.endsWith('/history/threads')) {
      this.threads.set(body.id, { ...body, connectorId: this.config.deviceId });
      await this.write(this.indexFile, [...this.threads.values()]); return { saved: true };
    }
    const match = /\/history\/threads\/([^/]+)\/items$/.exec(route);
    if (!match) return null;
    const file = this.itemFile(decodeURIComponent(match[1]));
    return this.withItems(file, async (rows) => {
      const byOrder = new Map([...rows.values()].map((row) => [row.itemOrder, row.id]));
      for (const item of body.items || []) {
        const oldId = byOrder.get(item.order);
        if (oldId && oldId !== item.id) rows.delete(oldId);
        rows.set(item.id, { ...item, itemOrder: item.order }); byOrder.set(item.order, item.id);
      }
      await this.write(file, [...rows.values()]); return { saved: body.items.length };
    });
  }
  async get(route, key) {
    await this.ready;
    const url = new URL(route, 'http://localhost');
    const limit = Math.max(1, Math.min(100, Number(url.searchParams.get('limit')) || 30));
    const before = url.searchParams.has('before') ? Number(url.searchParams.get('before')) : null;
    const after = url.searchParams.has('after') ? Number(url.searchParams.get('after')) : null;
    if (before !== null && after !== null) throw new Error('分页参数冲突');
    let rows, kind, threadId;
    if (url.pathname === '/api/v2/history/threads') {
      rows = [...this.threads.values()].filter((row) => before === null || row.updatedAt < before).sort((a, b) => b.updatedAt - a.updatedAt);
      kind = 'history.thread';
    } else {
      const match = /^\/api\/v2\/history\/threads\/([^/]+)\/items$/.exec(url.pathname);
      if (!match) throw new Error('直连不支持此读取接口');
      threadId = decodeURIComponent(match[1]); kind = 'history.item';
      rows = await this.withItems(this.itemFile(threadId), (values) => [...values.values()]);
      rows = rows.filter((row) => (before === null || row.itemOrder < before) && (after === null || row.itemOrder > after))
        .sort((a, b) => after === null ? b.itemOrder - a.itemOrder : a.itemOrder - b.itemOrder);
    }
    const items = rows.slice(0, limit).map((row) => {
      const value = decryptJson(this.config.accountKey, { ...row, kind, threadId: threadId || row.id });
      return { ...row, ...encryptJson(key, kind, threadId || row.id, row.id, value) };
    });
    return { items, hasMore: rows.length > limit };
  }
}
module.exports = { DirectHistory };
