const { updateSecrets } = require('./config');

const TOKEN_MARGIN_MS = 3 * 60_000;
// Idempotent requests (history uploads are upserts by id) ride out a flaky or
// throttled link instead of failing a whole sync pass.
const RETRY_DELAYS_MS = [1_500, 4_000, 10_000];
// A request stuck on a half-dead network (seen: a token refresh that took
// 40 minutes to fail) held up every reconnect behind it.
const REQUEST_TIMEOUT_MS = 45_000;
const RETRYABLE_STATUS = new Set([429, 502, 503, 504]);
const IDEMPOTENT = new Set(['GET', 'PUT', 'DELETE']);
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

class BridgeApi {
  constructor(config) { this.config = config; this.accessToken = null; this.expiresAt = 0; this.serverAbort = new AbortController(); }

  get version() { return this.config.protocolVersion === 2 ? 'v2' : 'v1'; }
  path(suffix) { return `/api/${this.version}${suffix}`; }
  webSocketPath() { return this.version === 'v2' ? '/bridge/v2/ws' : '/bridge/ws'; }

  async setup(password) {
    const challenge = await this.request('/api/v1/auth/challenge', { method: 'POST', auth: false });
    const { deriveAccountKey, loginProof, wrapAccountKey } = require('./crypto');
    const passwordKey = deriveAccountKey(password, challenge.salt, challenge.iterations);
    const key = this.config.accountKey ? Buffer.from(this.config.accountKey, 'base64') : require('node:crypto').randomBytes(32);
    const keyEnvelope = wrapAccountKey(passwordKey, key);
    const result = await this.request('/api/v1/auth/login', { method: 'POST', auth: false, body: {
      challengeId: challenge.challengeId, proof: loginProof(passwordKey, challenge.challengeId, challenge.nonce), keyEnvelope,
      deviceId: this.config.deviceId, deviceName: this.config.deviceName, deviceType: 'connector',
    }});
    this.accessToken = result.accessToken; this.expiresAt = result.expiresAt;
    this.config = updateSecrets(this.config, { accountKey: key.toString('base64'), refreshToken: result.refreshToken });
    return this.config;
  }

  // Refreshed well before expiry: on a throttled link a large upload can take
  // minutes to reach the server, which checks the token only on arrival.
  async token() {
    if (this.accessToken && this.expiresAt > Date.now() + TOKEN_MARGIN_MS) return this.accessToken;
    // Concurrent callers share one refresh instead of racing each other.
    if (!this.refreshing) this.refreshing = this.refreshToken().finally(() => { this.refreshing = null; });
    return this.refreshing;
  }

  async refreshToken() {
    if (!this.config.refreshToken) throw new Error('Connector login required');
    const path = this.version === 'v2' ? this.path('/session/refresh') : this.path('/auth/refresh');
    const body = { deviceId: this.config.deviceId, refreshToken: this.config.refreshToken };
    if (this.version === 'v2') body.accountId = this.config.accountId;
    const result = await this.request(path, { method: 'POST', auth: false, body });
    this.accessToken = result.accessToken; this.expiresAt = result.expiresAt;
    this.config = updateSecrets(this.config, { refreshToken: result.refreshToken });
    return this.accessToken;
  }

  async request(path, options = {}, retried = false) {
    if (options.method === 'PUT' && path.includes('/history/') && this.localHistory) {
      let saved;
      try { saved = await this.localHistory.put(path, options.body); }
      catch (error) { if (this.config.directOnly) throw error; }
      if (this.config.directOnly && saved) return saved;
    }
    if (this.config.directOnly) throw new Error('当前为二维码直连模式，已关闭业务服务器请求');
    const method = options.method || 'GET';
    const delays = IDEMPOTENT.has(method) ? (this.retryDelays || RETRY_DELAYS_MS) : [];
    const body = options.body === undefined ? undefined : JSON.stringify(options.body);
    let response;
    for (let attempt = 0; ; attempt++) {
      if (this.config.directOnly) throw new Error('当前为二维码直连模式，已关闭业务服务器请求');
      const headers = { 'content-type': 'application/json' };
      if (options.auth !== false) headers.authorization = `Bearer ${await this.token()}`;
      try {
        response = await fetch(`${this.config.serverUrl}${path}`, { method, headers, body,
          signal: AbortSignal.any([AbortSignal.timeout(options.timeoutMs || REQUEST_TIMEOUT_MS), this.serverAbort.signal]) });
      } catch (error) {
        if (attempt >= delays.length) throw error;
        await sleep(delays[attempt]); continue;
      }
      if (!RETRYABLE_STATUS.has(response.status) || attempt >= delays.length) break;
      await response.text().catch(() => '');
      await sleep(delays[attempt]);
    }
    if (!response.ok) {
      const text = await response.text();
      // The token ran out while the request was on its way: renew and resend once.
      if (response.status === 401 && options.auth !== false && !retried && /Token expired/i.test(text)) {
        this.accessToken = null; this.expiresAt = 0;
        return this.request(path, options, true);
      }
      // An error page (e.g. a proxy's 503 HTML) is not worth carrying whole.
      const brief = text.length > 300 ? `${text.replace(/\s+/g, ' ').slice(0, 300)}…` : text;
      throw new Error(`${response.status} ${brief}`);
    }
    return response.json();
  }
}

module.exports = { BridgeApi };
