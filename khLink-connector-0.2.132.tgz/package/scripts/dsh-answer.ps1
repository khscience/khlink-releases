param(
    [Parameter(Mandatory = $true)][ValidateSet('list', 'answer')][string]$Action,
    [string]$SessionTitle = '',
    [string]$Option = '',
    [int]$TimeoutSeconds = 15
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName UIAutomationClient | Out-Null
Add-Type -AssemblyName UIAutomationTypes | Out-Null

function Get-DshWindow {
    $proc = Get-Process | Where-Object {
        $_.MainWindowHandle -ne 0 -and $_.ProcessName -ne 'chrome' -and $_.MainWindowTitle -like '*DeepSeek Harness*'
    } | Select-Object -First 1
    if (-not $proc) { throw 'DSH desktop window not found' }
    [System.Windows.Automation.AutomationElement]::FromHandle($proc.MainWindowHandle)
}

function Get-Elements($root, $type) {
    $cond = New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty, $type)
    $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
}

function Invoke-Element($element) {
    if ($null -eq $element) { return $false }
    $pattern = $null
    if ($element.TryGetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern, [ref]$pattern)) {
        $pattern.Invoke()
        return $true
    }
    if ($element.TryGetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern, [ref]$pattern)) {
        $pattern.Select()
        return $true
    }
    return $false
}

function Select-Session($root, $title) {
    $items = @(Get-Elements $root ([System.Windows.Automation.ControlType]::TreeItem) | Where-Object { $_.Current.Name })
    if ($title -ne '') {
        $matches = @($items | Where-Object { $_.Current.Name -like "*$title*" })
        if ($matches.Count -eq 0) { throw "DSH session not found: $title" }
        $target = $matches | Where-Object { $_.Current.Name -like '*等待回答*' } | Select-Object -First 1
        # DSH can leave the sidebar label at "进行中" while the question card is
        # already open. Select the named session and let Wait-Card decide.
        if (-not $target) { $target = $matches | Select-Object -First 1 }
    } else {
        $target = $items | Where-Object { $_.Current.Name -like '*等待回答*' } | Select-Object -First 1
        if (-not $target) { throw 'DSH 桌面端没有等待回答的问题或审批' }
    }
    if (-not (Invoke-Element $target)) { throw 'DSH session could not be selected' }
    Start-Sleep -Milliseconds 450
}

function Get-Card($root) {
    $radios = @(Get-Elements $root ([System.Windows.Automation.ControlType]::RadioButton) | Where-Object { $_.Current.Name })
    $buttons = @(Get-Elements $root ([System.Windows.Automation.ControlType]::Button) | Where-Object { $_.Current.Name })
    $texts = @(Get-Elements $root ([System.Windows.Automation.ControlType]::Text) | Where-Object { $_.Current.Name })
    $submit = $buttons | Where-Object { $_.Current.Name -in @('提交', 'Submit') } | Select-Object -First 1
    $allow = $buttons | Where-Object { $_.Current.Name -match '允许一次|允许|Allow once|Approve' } | Select-Object -First 1
    $deny = $buttons | Where-Object { $_.Current.Name -match '^(拒绝|Deny|Reject)$' } | Select-Object -First 1
    $prompt = $texts | Where-Object {
        $_.Current.Name.Length -gt 8 -and $_.Current.Name -ne $SessionTitle -and
        $_.Current.Name -notmatch 'DeepSeek Harness|等待回答|电脑在线|^(复制|用量|等待你的操作)'
    } | Where-Object { $_.Current.Name -match '[?？]|权限|允许|文件|file' } | Select-Object -First 1
    if (-not $prompt) {
        $prompt = $texts | Where-Object {
            $_.Current.Name.Length -gt 8 -and $_.Current.Name -ne $SessionTitle -and
            $_.Current.Name -notmatch 'DeepSeek Harness|等待回答|电脑在线|^(复制|用量|等待你的操作)'
        } | Select-Object -First 1
    }
    [pscustomobject]@{
        RadioElements = @($radios)
        RadioNames = @($radios | ForEach-Object { $_.Current.Name })
        Submit = $submit
        Allow = $allow
        Deny = $deny
        Prompt = if ($prompt) { $prompt.Current.Name } else { '' }
    }
}

function Wait-Card($root, $timeoutSeconds) {
    $deadline = (Get-Date).AddSeconds($timeoutSeconds)
    do {
        $card = Get-Card $root
        if ($card.RadioElements.Count -gt 0 -or $card.Allow -or $card.Deny) { return $card }
        Start-Sleep -Milliseconds 300
    } while ((Get-Date) -lt $deadline)
    throw 'no pending DSH question or approval card found'
}

try {
    $root = Get-DshWindow
    Select-Session $root $SessionTitle
    $card = Wait-Card $root $TimeoutSeconds

    if ($Action -eq 'list') {
        if ($card.RadioElements.Count -gt 0) {
            [pscustomobject]@{
                ok = $true
                kind = 'question'
                prompt = $card.Prompt
                options = @($card.RadioNames)
                sessionTitle = $SessionTitle
            } | ConvertTo-Json -Compress
        } else {
            $options = @()
            if ($card.Allow) { $options += $card.Allow.Current.Name }
            if ($card.Deny) { $options += $card.Deny.Current.Name }
            [pscustomobject]@{
                ok = $true
                kind = 'approval'
                prompt = $card.Prompt
                options = $options
                sessionTitle = $SessionTitle
            } | ConvertTo-Json -Compress
        }
    } else {
        $clicked = ''
        if ($card.RadioElements.Count -gt 0) {
            $radio = $card.RadioElements | Where-Object { $_.Current.Name -eq $Option } | Select-Object -First 1
            if (-not $radio) {
                # DSH often omits a display-only suffix such as "（推荐）" from
                # the radio's accessible name. Match the label without a trailing
                # parenthetical before falling back to prefix matching.
                $normalized = ($Option -replace '\s*[（(][^）)]*[）)]\s*$', '').Trim()
                if ($normalized) {
                    $radio = $card.RadioElements | Where-Object { $_.Current.Name -eq $normalized } | Select-Object -First 1
                }
            }
            if (-not $radio) {
                $normalized = ($Option -replace '\s*[（(][^）)]*[）)]\s*$', '').Trim()
                $radio = $card.RadioElements | Where-Object {
                    $_.Current.Name -and ($normalized.StartsWith($_.Current.Name) -or $_.Current.Name.StartsWith($normalized))
                } | Select-Object -First 1
            }
            if (-not $radio) { throw "option not found: $Option" }
            if (-not (Invoke-Element $radio)) { throw 'option could not be selected' }
            Start-Sleep -Milliseconds 250
            if (-not $card.Submit -or -not (Invoke-Element $card.Submit)) { throw 'question submit not found' }
            $clicked = $Option
        } elseif ($Option -match '^(拒绝|Deny|Reject)$' -and $card.Deny) {
            if (-not (Invoke-Element $card.Deny)) { throw 'deny could not be clicked' }
            $clicked = $card.Deny.Current.Name
        } elseif ($card.Allow) {
            if (-not (Invoke-Element $card.Allow)) { throw 'allow could not be clicked' }
            $clicked = $card.Allow.Current.Name
        } else {
            throw 'approval controls not found'
        }
        Start-Sleep -Milliseconds 500
        [pscustomobject]@{ ok = $true; clicked = $clicked } | ConvertTo-Json -Compress
    }
} catch {
    [pscustomobject]@{ ok = $false; error = $_.Exception.Message } | ConvertTo-Json -Compress
}
