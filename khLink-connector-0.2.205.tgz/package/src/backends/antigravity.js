// Read-only view of Google Antigravity conversations, from the files the
// desktop app keeps under ~/.gemini/antigravity:
//
//   conversations/<id>.db   SQLite; table `steps` holds one protobuf message per
//                           agent step (user input, model reply, tool call, ...)
//   annotations/<id>.pbtxt  title and the time the user last viewed it
//
// Nothing here talks to Antigravity or Google (messages from the phone go
// through its window, see antigravity-sync.js). The step layout below was read
// from these local files (field numbers are stable across the conversations
// on this machine).

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { detectImageMime } = require('../attachment-store');

const MAX_USER_MEDIA_IMAGES = 6;
const MAX_USER_IMAGE_BYTES = 512 * 1024;

const STEP_USER = 14;
const STEP_MODEL = 15;
const STEP_ERROR = 17;
const STEP_SUBTASK_MESSAGE = 101;
const STEP_TOOL = 132;
// CortexStepStatus from the installed official language_server.exe descriptor:
// 1 pending, 2 running, 3 done, 4 invalid, 5 cleared, 6 canceled, 7 error,
// 8 generating, 9 waiting, 10 halted, 11 queued, 12 interrupted. In particular,
// a live streamed reply moves 8 -> 3; 8 must never mean "stopped".
const STATUS_PENDING = 1;
const STATUS_RUNNING = 2;
const STATUS_DONE = 3;
const STATUS_CLEARED = 5;
const STATUS_WAITING = 9;
const STATUS_QUEUED = 11;
const STATUS_ACTIVE = new Set([1, 2, 8, 11]);
const STATUS_FAILED = new Set([4, 7]);
const STATUS_STOPPED = new Set([6, 10, 12]);

function stepState(status) {
  if (STATUS_ACTIVE.has(status) || status === STATUS_WAITING) return 'inProgress';
  if (STATUS_FAILED.has(status)) return 'failed';
  if (STATUS_STOPPED.has(status)) return 'interrupted';
  return 'completed';
}

function antigravityHome() {
  return path.join(os.homedir(), '.gemini', 'antigravity');
}

function antigravityStorageFile() {
  if (process.platform === 'win32') {
    const appData = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
    return path.join(appData, 'Antigravity', 'app_storage.json');
  }
  if (process.platform === 'darwin') {
    return path.join(os.homedir(), 'Library', 'Application Support', 'Antigravity', 'app_storage.json');
  }
  const configHome = process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config');
  return path.join(configHome, 'Antigravity', 'app_storage.json');
}

// ---- minimal protobuf wire decoding --------------------------------------
function readVarint(buffer, offset) {
  let result = 0; let shift = 0; let index = offset;
  for (;;) {
    if (index >= buffer.length) throw new RangeError('truncated varint');
    const byte = buffer[index++];
    result += (byte & 0x7f) * 2 ** shift;
    if (!(byte & 0x80)) return [result, index];
    shift += 7;
    if (shift > 63) throw new RangeError('varint too long');
  }
}

// Returns [{ field, wire, value }] (value: number or Buffer), or null when the
// bytes are not a well-formed message.
function decodeMessage(buffer) {
  const fields = []; let index = 0;
  try {
    while (index < buffer.length) {
      let key; [key, index] = readVarint(buffer, index);
      const field = Math.floor(key / 8); const wire = key % 8;
      if (field === 0) return null;
      if (wire === 0) { let value; [value, index] = readVarint(buffer, index); fields.push({ field, wire, value }); }
      else if (wire === 1) { index += 8; fields.push({ field, wire, value: null }); }
      else if (wire === 5) { index += 4; fields.push({ field, wire, value: null }); }
      else if (wire === 2) {
        let length; [length, index] = readVarint(buffer, index);
        if (index + length > buffer.length) return null;
        fields.push({ field, wire, value: buffer.subarray(index, index + length) }); index += length;
      } else return null;
      if (index > buffer.length) return null;
    }
    return fields;
  } catch { return null; }
}

// Walk a path of field numbers; returns the first matching raw value.
function pick(buffer, ...pathFields) {
  let current = buffer;
  for (let depth = 0; depth < pathFields.length; depth += 1) {
    if (!Buffer.isBuffer(current)) return undefined;
    const fields = decodeMessage(current); if (!fields) return undefined;
    const hit = fields.find((entry) => entry.field === pathFields[depth]);
    if (!hit) return undefined;
    current = hit.value;
  }
  return current;
}

function pickAll(buffer, field) {
  const fields = Buffer.isBuffer(buffer) ? decodeMessage(buffer) : null;
  return fields ? fields.filter((entry) => entry.field === field).map((entry) => entry.value) : [];
}

function text(value) { return Buffer.isBuffer(value) ? value.toString('utf8') : ''; }

function timestampMs(buffer) {
  const seconds = pick(buffer, 1); const nanos = pick(buffer, 2);
  return typeof seconds === 'number' ? seconds * 1000 + Math.floor((typeof nanos === 'number' ? nanos : 0) / 1e6) : null;
}

function parseJson(value) { try { return JSON.parse(value); } catch { return null; } }

// ---- step -> KH Link history item ----------------------------------------
const FILE_TOOLS = new Set(['write_to_file', 'replace_file_content', 'multi_replace_file_content', 'create_file', 'edit_file', 'delete_file']);
const SEARCH_TOOLS = new Set(['search_web', 'read_url_content', 'web_search']);

function toolItem(call, status, reason = '') {
  const name = text(pick(call, 2)) || 'tool';
  const args = parseJson(text(pick(call, 3))) || {};
  const summary = [args.toolSummary || args.toolAction || '', reason].filter(Boolean).join('\n');
  const state = stepState(status);
  if (name === 'run_command') {
    return { type: 'commandExecution', text: [args.CommandLine || args.command || '', summary].filter(Boolean).join('\n\n') || '命令', status: state };
  }
  if (FILE_TOOLS.has(name)) {
    const file = args.TargetFile || args.AbsolutePath || args.path || '';
    const verb = name === 'write_to_file' || name === 'create_file' ? '新增' : name === 'delete_file' ? '删除' : '修改';
    return { type: 'fileChange', text: [file ? `${verb} ${file}` : '', summary].filter(Boolean).join('\n') || '文件变更', status: state };
  }
  if (SEARCH_TOOLS.has(name)) return { type: 'webSearch', text: args.query || args.Url || args.url || summary || '网络搜索', status: state };
  const target = args.AbsolutePath || args.DirectoryPath || args.SearchPath || args.Query || args.Pattern || '';
  return { type: 'mcpToolCall', text: [name, summary || target].filter(Boolean).join('\n'), status: state };
}

// ask_question: {"questions":[{"question","options":[...],"is_multi_select"}]}
function askQuestions(call) {
  const args = parseJson(text(pick(call, 3))) || {};
  return (Array.isArray(args.questions) ? args.questions : []).map((question) => ({
    question: String(question?.question || ''), header: '', multiSelect: Boolean(question?.is_multi_select),
    options: (Array.isArray(question?.options) ? question.options : []).map((option) => ({ label: String(option), description: '' })),
  })).filter((question) => question.question);
}

// What a step waiting for the user asks, in the shape the phone's waiting
// card reads (as for Codex and Claude); null when the step is not waiting.
function waitingFor(row) {
  if (!row || row.status !== STATUS_WAITING) return null;
  const payload = Buffer.from(row.step_payload || []);
  const call = pick(payload, 5, 4) || pick(payload, 4);
  const tool = Buffer.isBuffer(call) ? text(pick(call, 2)) : '';
  const requestId = (Buffer.isBuffer(call) && text(pick(call, 1))) || `ag-${row.idx}`;
  if (tool === 'ask_question') {
    const questions = askQuestions(call);
    const first = questions[0]?.question || '';
    // Answered from the phone through the app's own option buttons (antigravity-send.ps1 -Mode answer).
    return { kind: 'question', tool, requestId, summary: first ? `反重力在问你：${first.slice(0, 60)}` : '反重力在等你回答', description: '', questions, answerable: questions.length > 0 };
  }
  const args = Buffer.isBuffer(call) ? (parseJson(text(pick(call, 3))) || {}) : {};
  return { kind: 'approval', tool: tool || 'step', requestId, summary: '反重力在等你确认', description: String(args.CommandLine || args.toolSummary || args.toolAction || tool || ''), questions: [], answerable: false };
}

// One step can become several items (a reply with text and thinking).
function stepItems(row) {
  const payload = Buffer.from(row.step_payload || []);
  const at = timestampMs(pick(payload, 5, 1)) || null;
  const items = [];
  const push = (suffix, value) => {
    if (value && (String(value.text || '').trim() || (Array.isArray(value.images) && value.images.length))) {
      items.push({ id: `ag-${row.idx}${suffix}`, at, value });
    }
  };
  if (row.step_type === STEP_USER) {
    // Queued user input (status 11) lives in Antigravity's waiting queue until
    // the active turn / background task yields; keep it out of sent history.
    if (row.status === STATUS_QUEUED || STATUS_STOPPED.has(row.status) || STATUS_FAILED.has(row.status)) return items;
    const content = userStepText(payload);
    const images = userStepImages(payload);
    push('', { type: 'userMessage', text: content, status: null, ...(images.length ? { images } : {}) });
  } else if (row.step_type === STEP_MODEL) {
    push('-think', { type: 'reasoning', text: text(pick(payload, 20, 3)), status: null });
    push('', { type: 'agentMessage', text: text(pick(payload, 20, 1)), status: STATUS_STOPPED.has(row.status) ? 'interrupted' : null });
  } else if (row.step_type === STEP_TOOL) {
    // The call sits in the step header (5.4); older builds put it at 4.
    const call = pick(payload, 5, 4) || pick(payload, 4);
    if (Buffer.isBuffer(call) && text(pick(call, 2)) === 'ask_question') {
      // The question and, once given, the answer ("A1: <option>").
      const asked = askQuestions(call).map((question) => question.question).join('\n');
      // Only a finished step holds the answer; while waiting the field says so instead.
      const answer = row.status === 3 || row.status === 5 ? text(pick(payload, 140, 2, 1)) : '';
      push('', { type: 'mcpToolCall', text: ['提问', [asked, answer && `回答：${answer.replace(/^A\d+:\s*/, '')}`].filter(Boolean).join('\n')].join('\n'), status: stepState(row.status) });
      return items;
    }
    // Why a call was refused before it ran (e.g. missing arguments).
    const reason = STATUS_FAILED.has(row.status) ? text(pick(payload, 31, 2)) : '';
    // Stopped by the user (Stop Task / Cancel): "context canceled" in the result.
    const canceled = row.status === 6 && /\bcancel(l)?ed\b/i.test(text(pick(payload, 140, 2, 6, 2, 31, 2)) || reason);
    if (Buffer.isBuffer(call) && text(pick(call, 2))) {
      const item = toolItem(call, row.status, canceled ? '' : reason);
      if (canceled) item.status = 'interrupted';
      push('', item);
    }
  } else if (row.step_type === STEP_ERROR) {
    // Retries ("API error (attempt 1): ...") are noise; the final "Agent
    // execution terminated" notice carries a headline in 24.3.1.
    const headline = text(pick(payload, 24, 3, 1));
    const detail = text(pick(payload, 24, 3, 9)) || text(pick(payload, 24, 3, 2));
    if (headline || !/^API error \(attempt \d+\)/i.test(detail)) {
      push('', { type: 'error', text: [headline, detail.split(/\r?\n/)[0].slice(0, 300)].filter(Boolean).join('\n'), status: 'failed' });
    }
  } else if (row.step_type === STEP_SUBTASK_MESSAGE) {
    // "[Message] timestamp=... sender=<conv>/task-53 ... content=<text>"
    const raw = text(pick(payload, 114, 1));
    const content = raw.match(/content=([\s\S]*)$/)?.[1]?.trim() || '';
    const title = text(pick(payload, 114, 2, 1)) || content.split(/\r?\n/)[0].slice(0, 120);
    push('', { type: 'collabAgentToolCall', text: title, status: 'completed' });
  }
  return items;
}

// ---- conversation metadata --------------------------------------------------
// The sync looks at every conversation's annotation every few seconds. Reading
// all of them each time cost seconds of blocked thread while the PC was busy;
// a file whose size and time have not changed is not read again.
const annotationCache = new Map(); // file -> { mtimeMs, size, value }
const pinnedOrderCache = new Map(); // file -> { mtimeMs, size, ids }

function readAnnotation(home, id) {
  const file = path.join(home, 'annotations', `${id}.pbtxt`);
  let stat; try { stat = fs.statSync(file); } catch { annotationCache.delete(file); return {}; }
  const cached = annotationCache.get(file);
  if (cached && cached.mtimeMs === stat.mtimeMs && cached.size === stat.size) return cached.value;
  let raw = ''; try { raw = fs.readFileSync(file, 'utf8'); } catch { return {}; }
  const title = raw.match(/title:"((?:[^"\\]|\\.)*)"/)?.[1];
  const viewed = raw.match(/last_user_view_time:\{seconds:(\d+)/)?.[1];
  const archived = /\barchived:\s*true\b/.test(raw);
  const pinned = !archived && /\bpinned:\s*true\b/.test(raw);
  const value = { title: title ? title.replace(/\\(.)/g, '$1') : '', viewedAt: viewed ? Number(viewed) * 1000 : 0, pinned };
  annotationCache.set(file, { mtimeMs: stat.mtimeMs, size: stat.size, value });
  return value;
}

// Antigravity's desktop sidebar pin order lives in app_storage.json under
// `pinned_conversations_order` (a JSON-encoded array of conversation UUIDs).
// Only that single UI key is read; missing or unreadable files return [].
function readPinnedOrder(file = antigravityStorageFile()) {
  if (!file) return [];
  let stat; try { stat = fs.statSync(file); } catch { pinnedOrderCache.delete(file); return []; }
  const cached = pinnedOrderCache.get(file);
  if (cached && cached.mtimeMs === stat.mtimeMs && cached.size === stat.size) return cached.ids;
  let ids = [];
  try {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    const rawOrder = parsed?.pinned_conversations_order;
    const list = Array.isArray(rawOrder) ? rawOrder : (typeof rawOrder === 'string' ? JSON.parse(rawOrder) : []);
    if (Array.isArray(list)) {
      const seen = new Set();
      ids = list.map((item) => String(item || '').trim()).filter((id) => id && !seen.has(id) && seen.add(id));
    }
  } catch {
    // Do not poison the cache on a transient EBUSY or mid-write partial JSON.
    return [];
  }
  pinnedOrderCache.set(file, { mtimeMs: stat.mtimeMs, size: stat.size, ids });
  return ids;
}

function workspaceFromUri(uri) {
  if (!uri || !/^file:\/\//i.test(uri)) return '';
  try {
    const decoded = decodeURIComponent(uri.replace(/^file:\/\/\/?/i, ''));
    return decoded.replace(/\//g, '\\').replace(/^([a-z]):/, (m, d) => `${d.toUpperCase()}:`);
  } catch { return ''; }
}

let sqliteModule = null;
function loadSqlite() {
  if (sqliteModule) return sqliteModule;
  // node:sqlite prints a one-time ExperimentalWarning, which the connector's
  // file log would record as an error; drop just that warning.
  const emit = process.emitWarning;
  process.emitWarning = (warning, ...rest) => {
    if (/SQLite is an experimental feature/i.test(String(warning?.message || warning))) return;
    emit.call(process, warning, ...rest);
  };
  try { sqliteModule = require('node:sqlite'); } finally { process.emitWarning = emit; }
  return sqliteModule;
}

// The model of the latest request (e.g. "gemini-3.8-flash-high"): gen_metadata
// holds one record per model call, the id at field 3.28. Only that field is read.
function latestModel(db) {
  const row = db.prepare('select data from gen_metadata order by idx desc limit 1').get();
  const value = row?.data ? text(pick(Buffer.from(row.data), 3, 28)) : '';
  return /^[\w.\-\/]{1,80}$/.test(value) ? value : '';
}

function readModel(file) {
  const db = openReadOnly(file);
  try { return latestModel(db); } catch { return ''; } finally { db.close(); }
}

function openReadOnly(file) {
  const { DatabaseSync } = loadSqlite();
  return new DatabaseSync(file, { readOnly: true, timeout: 1000 });
}

function normalizeSendText(value) { return String(value || '').replace(/\s+/g, ' ').trim(); }

function userStepText(payload) {
  return text(pick(payload, 19, 2)) || text(pick(payload, 19, 3, 1));
}

function userStepMedia(payload) {
  const input = pick(payload, 19);
  if (!Buffer.isBuffer(input)) return [];
  return pickAll(input, 9).filter(Buffer.isBuffer);
}

function userStepMediaCount(payload) {
  return userStepMedia(payload).length;
}

// Antigravity stores user-attached media in STEP_USER field 19.9 (repeated):
//   1: mimeType, 4: filename, 5: local disk path, 6: inline thumbnail bytes.
function userStepImages(payload) {
  const images = [];
  for (const media of userStepMedia(payload)) {
    if (images.length >= MAX_USER_MEDIA_IMAGES) break;
    let bytes = pick(media, 6);
    let mime = Buffer.isBuffer(bytes) && bytes.length <= MAX_USER_IMAGE_BYTES ? detectImageMime(bytes) : null;
    if (!mime) {
      const filePath = text(pick(media, 5)).trim();
      if (filePath) {
        try {
          const stat = fs.statSync(filePath);
          if (stat.isFile() && stat.size > 0 && stat.size <= MAX_USER_IMAGE_BYTES) {
            const diskBytes = fs.readFileSync(filePath);
            const diskMime = detectImageMime(diskBytes);
            if (diskMime) { bytes = diskBytes; mime = diskMime; }
          }
        } catch { /* missing or unreadable media path */ }
      }
    }
    if (mime && Buffer.isBuffer(bytes)) {
      images.push({ data: `data:${mime};base64,${bytes.toString('base64')}`, mimeType: mime });
    }
  }
  return images;
}

// Confirm a send only against a new user step in the intended conversation.
// An identical message from an older turn is not an acceptance receipt.
// Also reports whether Antigravity queued the step (status 11) instead of
// executing it immediately (e.g. while a background task or turn is active).
function readSendState(file, message = '', afterIdx = -1, { expectMedia = false } = {}) {
  const db = openReadOnly(file);
  try {
    const lastIdx = db.prepare('select max(idx) as idx from steps').get()?.idx ?? -1;
    let receipt = null;
    const wantedText = normalizeSendText(message);
    if (wantedText || expectMedia) {
      const rows = db.prepare('select idx, step_type, status, step_payload from steps where step_type = ? and idx > ? order by idx').all(STEP_USER, afterIdx);
      for (const row of rows) {
        if (STATUS_STOPPED.has(row.status) || STATUS_FAILED.has(row.status)) continue;
        const payload = Buffer.from(row.step_payload || []);
        const content = normalizeSendText(userStepText(payload));
        const matched = wantedText
          ? content === wantedText
          : (!content && userStepMediaCount(payload) > 0);
        if (matched) {
          receipt = { idx: row.idx, at: timestampMs(pick(payload, 5, 1)) || null, status: row.status, queued: row.status === STATUS_QUEUED };
          break;
        }
      }
    }
    return { lastIdx, receipt };
  } finally { db.close(); }
}

function readStepStatuses(file, indices = []) {
  const wanted = [...new Set((indices || []).filter((n) => Number.isInteger(n) && n >= 0))];
  const result = new Map();
  if (!wanted.length) return result;
  const db = openReadOnly(file);
  try {
    const stmt = db.prepare('select status from steps where idx = ?');
    for (const idx of wanted) {
      const row = stmt.get(idx);
      if (row) result.set(idx, row.status);
    }
    return result;
  } finally { db.close(); }
}

const summaryCache = new Map(); // file -> { mtimeMs, size, map }

// Read Antigravity's conversation_summaries.db (status & not_fully_idle), cached
// by mtime + size including WAL so background-task activity is observed cheaply.
function readConversationSummaries(home = antigravityHome()) {
  const file = path.join(home, 'conversation_summaries.db');
  let stat;
  try {
    stat = fs.statSync(file);
    try {
      const wal = fs.statSync(`${file}-wal`);
      stat = { mtimeMs: Math.max(stat.mtimeMs, wal.mtimeMs), size: stat.size + wal.size };
    } catch {}
  } catch { summaryCache.delete(file); return new Map(); }
  const cached = summaryCache.get(file);
  if (cached && cached.mtimeMs === stat.mtimeMs && cached.size === stat.size) return cached.map;
  const map = new Map();
  let db = null;
  let loaded = false;
  try {
    db = openReadOnly(file);
    let rows;
    try {
      rows = db.prepare('select conversation_id, status, not_fully_idle, parent_conversation_id, nesting_depth from conversation_summaries').all();
    } catch {
      rows = db.prepare('select conversation_id, status, not_fully_idle from conversation_summaries').all();
    }
    for (const row of rows) {
      if (!row?.conversation_id) continue;
      const parentId = String(row.parent_conversation_id || '').trim();
      const depth = Number(row.nesting_depth) || 0;
      map.set(String(row.conversation_id), {
        status: String(row.status || ''),
        notFullyIdle: Boolean(row.not_fully_idle),
        isSubagent: Boolean(parentId || depth > 0),
      });
    }
    loaded = true;
  } catch { /* older or locked summaries db */ } finally { try { db?.close(); } catch {} }
  if (!loaded) return new Map();
  summaryCache.set(file, { mtimeMs: stat.mtimeMs, size: stat.size, map });
  return map;
}

// Parse relative duration strings from Antigravity's Usage UI:
//   "6d 15h", "4h 21m", "6 days, 15 hours", "4 hours, 22 minutes", "45 minutes"
function parseRelativeDurationMs(raw) {
  const value = String(raw || '');
  let total = 0;
  let matched = false;
  const units = [
    [/(\d+)\s*(?:days?|d)\b/gi, 86_400_000],
    [/(\d+)\s*(?:hours?|hrs?|h)\b/gi, 3_600_000],
    [/(\d+)\s*(?:minutes?|mins?|m)\b/gi, 60_000],
  ];
  for (const [pattern, factor] of units) {
    let m;
    while ((m = pattern.exec(value)) !== null) {
      total += Number(m[1]) * factor;
      matched = true;
    }
  }
  return matched && total > 0 ? total : null;
}

function usageGroupMeta(line) {
  const trimmed = String(line || '').trim();
  if (/^Gemini\s+Models$/i.test(trimmed)) return { id: 'gemini', name: 'Gemini' };
  if (/^Claude\s+and\s+GPT\s+models$/i.test(trimmed)) return { id: 'claude_gpt', name: 'Claude / GPT' };
  if (/^[A-Za-z0-9][A-Za-z0-9 .+/&-]{1,40}\s+models$/i.test(trimmed) && !/your|model quota|enable|credits/i.test(trimmed)) {
    const clean = trimmed.replace(/\s+models$/i, '').trim();
    return { id: clean.toLowerCase().replace(/[^a-z0-9]+/g, '_'), name: clean };
  }
  return null;
}

// Parse text lines collected from Antigravity's official "View Usage" submenu
// or "Models & Usage" settings view into structured per-group quota windows.
function parseAntigravityUsage(rawLines, now = Date.now()) {
  const split = (Array.isArray(rawLines) ? rawLines : String(rawLines || '').split(/\r?\n/))
    .flatMap((line) => String(line || '').split(/\r?\n/))
    .map((line) => line.replace(/\s+/g, ' ').trim())
    .filter(Boolean);
  if (!split.length) return null;
  // Antigravity's accessibility tree can emit "82" and "% left" as two adjacent nodes.
  const lines = [];
  for (let i = 0; i < split.length; i += 1) {
    if (/^\d{1,3}$/.test(split[i]) && /^%(?:\s*left\b)?$/i.test(split[i + 1] || '')) {
      lines.push(`${split[i]}${split[i + 1]}`);
      i += 1;
    } else {
      lines.push(split[i]);
    }
  }
  let plan = null;
  let credits = null;
  const groups = [];
  let currentGroup = null;
  let currentWindowKey = null;

  const ensureWindow = (group, key) => {
    if (!group[key]) group[key] = { remainingPercent: null, resetsAt: null, observedAt: now };
    return group[key];
  };

  for (const line of lines) {
    const planMatch = line.match(/^Your\s+Plan:\s*(.+)$/i);
    if (planMatch) { plan = planMatch[1].trim(); continue; }
    const creditMatch = line.match(/^Available\s+AI\s+Credits:\s*([\d,]+)/i);
    if (creditMatch) {
      const parsed = Number(creditMatch[1].replace(/,/g, ''));
      if (Number.isFinite(parsed)) credits = parsed;
      continue;
    }
    const groupMeta = usageGroupMeta(line);
    if (groupMeta) {
      currentGroup = groups.find((g) => g.id === groupMeta.id) || null;
      if (!currentGroup) {
        currentGroup = { id: groupMeta.id, name: groupMeta.name, fiveHour: null, sevenDay: null };
        groups.push(currentGroup);
      }
      currentWindowKey = null;
      continue;
    }
    if (!currentGroup) continue;

    if (/^Weekly\s+limit(?:\s+Remaining)?\b/i.test(line)) {
      currentWindowKey = 'sevenDay';
      ensureWindow(currentGroup, currentWindowKey);
    } else if (/^(?:5h\s+limit|Five\s+Hour\s+Limit(?:\s+Remaining)?)\b/i.test(line)) {
      currentWindowKey = 'fiveHour';
      ensureWindow(currentGroup, currentWindowKey);
    }

    if (!currentWindowKey) continue;
    const win = ensureWindow(currentGroup, currentWindowKey);
    const pctMatch = line.match(/(?:^|\b)(\d{1,3})%(?:\s*left\b)?/i);
    if (pctMatch) {
      const pct = Number(pctMatch[1]);
      if (Number.isFinite(pct) && pct >= 0 && pct <= 100) win.remainingPercent = pct;
    }
    const resetMatch = line.match(/(?:resets?\s+in|refresh\s+in)\s+([^.]+)/i);
    if (resetMatch) {
      const ms = parseRelativeDurationMs(resetMatch[1]);
      if (ms !== null) win.resetsAt = now + ms;
    }
  }

  const validGroups = groups.filter((group) =>
    group.fiveHour?.remainingPercent !== null && group.fiveHour?.remainingPercent !== undefined
    || group.sevenDay?.remainingPercent !== null && group.sevenDay?.remainingPercent !== undefined);
  if (!validGroups.length) return null;
  return { groups: validGroups, plan, credits, observedAt: now };
}

// Everything the phone needs from one conversation file. `afterIdx` limits
// the steps read to new ones (plus a couple before, which may still change);
// `openIdx` is the first step last seen in progress, read again until it ends.
function readConversation(file, afterIdx = -1, openIdx = null) {
  const db = openReadOnly(file);
  try {
    const metaRow = db.prepare('select data from trajectory_metadata_blob limit 1').get();
    const meta = metaRow?.data ? Buffer.from(metaRow.data) : null;
    const createdAt = meta ? timestampMs(pick(meta, 2)) : null;
    const cwd = meta ? workspaceFromUri(text(pick(meta, 7))) : '';
    const parentConversationId = meta ? text(pick(meta, 5)).trim() : '';
    const nestingDepth = meta ? (Number(pick(meta, 17)) || 0) : 0;
    const isSubagent = Boolean(parentConversationId || nestingDepth > 0);
    const last = db.prepare('select max(idx) as idx from steps').get()?.idx ?? -1;
    const queuedRows = db.prepare('select idx, step_type, status, step_payload from steps where step_type = ? and status = ? order by idx').all(STEP_USER, STATUS_QUEUED);
    const queuedSteps = queuedRows.map((row) => {
      const payload = Buffer.from(row.step_payload || []);
      const content = userStepText(payload);
      const mediaCount = userStepMediaCount(payload);
      const at = timestampMs(pick(payload, 5, 1)) || null;
      return (content.trim() || mediaCount > 0) ? { idx: row.idx, text: content, mediaCount, at } : null;
    }).filter(Boolean);
    const earliestQueued = queuedSteps.length ? queuedSteps[0].idx : Infinity;
    const from = Math.max(0, Math.min(afterIdx - 2, Number.isInteger(openIdx) ? openIdx : Infinity, earliestQueued));
    const rows = db.prepare('select idx, step_type, status, step_payload from steps where idx >= ? order by idx').all(from);
    const items = rows.flatMap(stepItems);
    const openRowIdx = rows.find((row) => STATUS_ACTIVE.has(row.status) || row.status === STATUS_WAITING)?.idx ?? null;
    const open = Number.isFinite(earliestQueued)
      ? (openRowIdx !== null ? Math.min(openRowIdx, earliestQueued) : earliestQueued)
      : openRowIdx;
    // Ignore queued, cancelled, or failed user follow-up rows when determining
    // the conversation's active/waiting/completed tail status.
    const tail = db.prepare(
      'select idx, step_type, status, step_payload from steps where not (step_type = ? and status in (4, 5, 6, 7, 11)) order by idx desc limit 1',
    ).get(STEP_USER)
      || db.prepare('select idx, step_type, status, step_payload from steps order by idx desc limit 1').get();
    const lastAt = tail ? timestampMs(pick(Buffer.from(tail.step_payload || []), 5, 1)) : null;
    const lastStatus = tail?.status ?? null;
    const lastType = tail?.step_type ?? null;
    const lastErrorRetryable = isRetryableErrorStep(tail);
    const waiting = waitingFor(tail);
    let model = ''; try { model = latestModel(db); } catch { /* older files have no gen_metadata */ }
    const firstUser = db.prepare('select step_payload from steps where step_type = ? order by idx limit 1').get(STEP_USER);
    const firstPayload = firstUser ? Buffer.from(firstUser.step_payload || []) : null;
    const firstText = firstPayload ? (userStepText(firstPayload) || (userStepMediaCount(firstPayload) > 0 ? '[图片]' : '')) : '';
    return { createdAt, cwd, isSubagent, lastIdx: last, items, queuedSteps, lastAt, lastStatus, lastType, lastErrorRetryable, openIdx: open, waiting, model, firstText };
  } finally { db.close(); }
}

function isRetryableErrorStep(row) {
  if (!row || row.step_type !== STEP_ERROR) return false;
  const payload = Buffer.from(row.step_payload || []);
  const headline = text(pick(payload, 24, 3, 1));
  const detail = text(pick(payload, 24, 3, 9)) || text(pick(payload, 24, 3, 2));
  return !headline && /^API error \(attempt \d+\)/i.test(detail);
}

function protoDurationMs(buffer) {
  if (!Buffer.isBuffer(buffer)) return null;
  const seconds = pick(buffer, 1);
  const nanos = pick(buffer, 2);
  if (seconds == null && nanos == null) return null;
  const s = typeof seconds === 'number' && Number.isSafeInteger(seconds) && seconds >= 0 ? seconds : 0;
  const n = typeof nanos === 'number' && Number.isSafeInteger(nanos) && nanos >= 0 ? nanos : 0;
  const ms = s * 1000 + Math.round(n / 1e6);
  return Number.isSafeInteger(ms) && ms >= 0 ? ms : null;
}

function safeNonNegInt(value) {
  return typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 ? value : null;
}

function sumUsageRows(rows) {
  if (!rows.length) return null;
  let input = 0; let output = 0; let cacheRead = 0; let reasoning = 0; let total = 0;
  for (const row of rows) {
    input += row.input;
    output += row.output;
    total += row.total;
    cacheRead = cacheRead == null || row.cacheRead == null ? null : cacheRead + row.cacheRead;
    reasoning = reasoning == null || row.reasoning == null ? null : reasoning + row.reasoning;
  }
  if (!Number.isSafeInteger(input) || !Number.isSafeInteger(output) || !Number.isSafeInteger(total)) return null;
  return { input, output, cacheRead, cacheWrite: null, reasoning, total };
}

const usageCache = new Map(); // file -> { signature, parsed }
const MAX_USAGE_CACHE_FILES = 128;

function fileWalSignature(file) {
  const stat = fs.statSync(file);
  if (!stat.isFile()) throw new Error('用量来源不是对话文件');
  let mtimeMs = stat.mtimeMs;
  let size = stat.size;
  try {
    const wal = fs.statSync(`${file}-wal`);
    mtimeMs = Math.max(mtimeMs, wal.mtimeMs);
    size += wal.size;
  } catch { /* no WAL */ }
  return `${stat.dev}:${stat.ino}:${mtimeMs}:${size}`;
}

function parseGenMetadataRow(row) {
  if (!row?.data) return { empty: true };
  const buf = Buffer.from(row.data);
  const f1 = pick(buf, 1);
  if (!Buffer.isBuffer(f1)) return { empty: true };
  const f4 = pick(f1, 4);
  if (!Buffer.isBuffer(f4)) return { empty: true };
  const rawUncached = pick(f4, 2);
  const rawOutput = pick(f4, 3);
  const rawCacheRead = pick(f4, 5);
  if (rawUncached == null && rawOutput == null && rawCacheRead == null) return { empty: true };
  // Proto3 omits integer fields whose value is 0 (e.g. zero-output or 100% cache-hit calls).
  const uncachedInput = rawUncached == null ? 0 : safeNonNegInt(rawUncached);
  const output = rawOutput == null ? 0 : safeNonNegInt(rawOutput);
  const cacheRead = rawCacheRead == null ? 0 : safeNonNegInt(rawCacheRead);
  if (uncachedInput == null || output == null || cacheRead == null) return { invalid: true };
  const f9 = safeNonNegInt(pick(f4, 9));
  const f10 = safeNonNegInt(pick(f4, 10));
  const reasoning = f9 != null && f9 <= output
    ? f9
    : (f9 == null && (output === 0 || (f10 != null && f10 === output)) ? 0 : null);
  const input = uncachedInput + cacheRead;
  const total = input + output;
  if (!Number.isSafeInteger(input) || !Number.isSafeInteger(total) || cacheRead > input || (reasoning != null && reasoning > output)) {
    return { invalid: true };
  }
  const model = text(pick(f1, 21)).trim() || text(pick(f1, 19)).trim() || text(pick(buf, 3, 28)).trim() || null;
  const durationMs = protoDurationMs(pick(f1, 11));
  const rawTtftMs = protoDurationMs(pick(f1, 12));
  const ttftMs = rawTtftMs != null && durationMs != null && rawTtftMs <= durationMs ? rawTtftMs : null;
  let lastStepIdx = null;
  for (const kv of pickAll(f1, 20)) {
    if (text(pick(kv, 1)) === 'last_step_index') {
      const parsed = Number(text(pick(kv, 2)));
      if (Number.isSafeInteger(parsed) && parsed >= 0) lastStepIdx = parsed;
      break;
    }
  }
  return {
    usage: { input, output, cacheRead, cacheWrite: null, reasoning, total },
    model, durationMs, ttftMs, lastStepIdx,
  };
}

function parseAntigravityUsageDb(file) {
  const db = openReadOnly(file);
  try {
    const metaRow = db.prepare('select data from trajectory_metadata_blob limit 1').get();
    const metaBuf = metaRow?.data ? Buffer.from(metaRow.data) : null;
    const createdAt = metaBuf ? (timestampMs(pick(metaBuf, 2)) || 0) : 0;

    const stepRows = db.prepare('select idx, step_type, status, step_payload from steps order by idx').all();
    const stepList = [];
    const modelSteps = [];
    const turns = [];
    let currentTurn = null;
    let updatedAt = createdAt;
    let lastTailStatus = null;

    for (const row of stepRows) {
      const payload = Buffer.from(row.step_payload || []);
      const at = timestampMs(pick(payload, 5, 1)) || 0;
      if (at > updatedAt) updatedAt = at;
      stepList.push({ idx: row.idx, type: row.step_type, at });
      lastTailStatus = row.status;
      if (row.step_type === STEP_USER && row.status !== STATUS_QUEUED && !STATUS_STOPPED.has(row.status) && !STATUS_FAILED.has(row.status)) {
        currentTurn = {
          turnId: `ag-${row.idx}`,
          startIdx: row.idx,
          startedAt: at,
          lastStepAt: at,
          finalMessageAt: 0,
          finalMessageId: null,
          finalStepIdx: null,
          requests: [],
          partial: false,
        };
        turns.push(currentTurn);
      } else if (row.step_type === STEP_MODEL) {
        const hasVisibleText = Boolean(text(pick(payload, 20, 1)).trim());
        modelSteps.push({ idx: row.idx, at, hasVisibleText });
        if (currentTurn) {
          if (at > currentTurn.lastStepAt) currentTurn.lastStepAt = at;
          if (hasVisibleText && at >= currentTurn.finalMessageAt) {
            currentTurn.finalMessageAt = at;
            currentTurn.finalMessageId = `ag-${row.idx}`;
            currentTurn.finalStepIdx = row.idx;
          }
        }
      } else if (currentTurn && at > currentTurn.lastStepAt) {
        currentTurn.lastStepAt = at;
      }
    }

    const findTimestampAfter = (lsi) => {
      if (lsi == null) return 0;
      let lo = 0; let hi = stepList.length;
      while (lo < hi) {
        const mid = (lo + hi) >> 1;
        if (stepList[mid].idx <= lsi) lo = mid + 1;
        else hi = mid;
      }
      for (let i = lo; i < stepList.length; i += 1) {
        if (stepList[i].at > 0) return stepList[i].at;
      }
      for (let i = lo - 1; i >= 0; i -= 1) {
        if (stepList[i].at > 0) return stepList[i].at;
      }
      return createdAt;
    };

    const findResponseModelStep = (lsi, nextLsi) => {
      if (lsi == null) return null;
      let lo = 0; let hi = modelSteps.length;
      while (lo < hi) {
        const mid = (lo + hi) >> 1;
        if (modelSteps[mid].idx <= lsi) lo = mid + 1;
        else hi = mid;
      }
      const candidate = modelSteps[lo];
      if (!candidate) return null;
      if (nextLsi != null && candidate.idx > nextLsi) return null;
      return candidate;
    };

    const findOwnerTurn = (lsi) => {
      if (!turns.length) return null;
      if (lsi == null) return turns[turns.length - 1];
      let lo = 0; let hi = turns.length - 1; let hit = null;
      while (lo <= hi) {
        const mid = (lo + hi) >> 1;
        if (turns[mid].startIdx <= lsi) { hit = turns[mid]; lo = mid + 1; }
        else hi = mid - 1;
      }
      return hit;
    };

    let genRows = [];
    try { genRows = db.prepare('select idx, data from gen_metadata order by idx').all(); } catch { genRows = []; }

    const parsedGen = genRows.map((row) => ({ idx: row.idx, ...parseGenMetadataRow(row) }));
    const requests = [];
    let partial = false;
    let model = null;
    let usageUpdatedAt = 0;

    for (let i = 0; i < parsedGen.length; i += 1) {
      const entry = parsedGen[i];
      if (entry.empty) continue;
      const owner = findOwnerTurn(entry.lastStepIdx);
      if (entry.invalid || !entry.usage) {
        partial = true;
        if (owner) owner.partial = true;
        continue;
      }
      let nextLsi = null;
      for (let j = i + 1; j < parsedGen.length; j += 1) {
        if (parsedGen[j].lastStepIdx != null && parsedGen[j].lastStepIdx > (entry.lastStepIdx ?? -1)) {
          nextLsi = parsedGen[j].lastStepIdx;
          break;
        }
      }
      const responseStep = findResponseModelStep(entry.lastStepIdx, nextLsi);
      const baseAt = responseStep?.at || findTimestampAfter(entry.lastStepIdx) || updatedAt || createdAt;
      const requestAt = baseAt && entry.durationMs ? baseAt + entry.durationMs : baseAt;
      if (requestAt > usageUpdatedAt) {
        usageUpdatedAt = requestAt;
        if (entry.model) model = entry.model;
      } else if (!model && entry.model) {
        model = entry.model;
      }
      const record = {
        idx: entry.idx,
        usage: entry.usage,
        requestAt,
        turnId: owner?.turnId || null,
        durationMs: entry.durationMs,
        ttftMs: entry.ttftMs,
        responseStepIdx: responseStep?.idx ?? null,
        responseHasText: Boolean(responseStep?.hasVisibleText),
      };
      requests.push(record);
      if (owner) owner.requests.push(record);
    }

    return {
      createdAt,
      updatedAt: Math.max(updatedAt, usageUpdatedAt),
      usageUpdatedAt,
      model,
      partial,
      inferredActive: STATUS_ACTIVE.has(lastTailStatus),
      requests,
      turns,
    };
  } finally {
    db.close();
  }
}

function readConversationUsage(file, { historyFrom = 0, periods = null, turnActive = null } = {}) {
  if (!file) {
    return { schemaVersion: 1, backend: 'antigravity', status: 'unavailable', reason: '暂时找不到此对话的用量记录' };
  }
  let signature;
  try {
    signature = fileWalSignature(file);
  } catch (error) {
    if (error?.code === 'ENOENT') {
      return { schemaVersion: 1, backend: 'antigravity', status: 'unavailable', reason: '此对话的本地记录已不存在' };
    }
    throw error;
  }
  let cached = usageCache.get(file);
  if (!cached || cached.signature !== signature) {
    const parsed = parseAntigravityUsageDb(file);
    cached = { signature, parsed };
    usageCache.delete(file);
    usageCache.set(file, cached);
    if (usageCache.size > MAX_USAGE_CACHE_FILES) {
      usageCache.delete(usageCache.keys().next().value);
    }
  }
  const data = cached.parsed;
  const totals = sumUsageRows(data.requests.map((r) => r.usage));
  if (!totals) {
    return {
      schemaVersion: 1,
      backend: 'antigravity',
      status: 'unavailable',
      totals: null,
      turn: null,
      latest: null,
      turnId: data.turns.at(-1)?.turnId || null,
      turnActive: Boolean(turnActive ?? data.inferredActive),
      completedTurns: [],
      historyFromAt: 0,
      model: data.model,
      updatedAt: data.updatedAt,
      usageUpdatedAt: data.usageUpdatedAt,
      partial: data.partial,
      scope: 'session_records',
      reason: '此对话尚无可读取的 token 用量记录',
    };
  }

  const active = turnActive == null ? data.inferredActive : Boolean(turnActive);
  const lastReq = data.requests.at(-1);
  const latest = lastReq?.usage || null;
  const latestOutputSpeed = lastReq && lastReq.usage.output > 0 && lastReq.durationMs > 0
    && lastReq.requestAt >= lastReq.durationMs && lastReq.requestAt - lastReq.durationMs >= 1_000_000_000_000
    && lastReq.responseStepIdx != null
    ? {
      method: 'antigravity_request_elapsed_v1',
      outputTokens: lastReq.usage.output,
      durationMs: lastReq.durationMs,
      completedAt: lastReq.requestAt,
      turnId: lastReq.turnId,
      messageId: `ag-${lastReq.responseStepIdx}`,
    }
    : null;

  const latestTurn = data.turns.at(-1) || null;
  const turn = latestTurn && latestTurn.requests.length
    ? sumUsageRows(latestTurn.requests.map((r) => r.usage))
    : null;

  const completedTurns = [];
  const lastTurnIndex = data.turns.length - 1;
  for (let i = 0; i < data.turns.length; i += 1) {
    if (i === lastTurnIndex && active) continue;
    const t = data.turns[i];
    if (!t.startedAt || !t.finalMessageAt || t.finalMessageAt < t.startedAt || !t.requests.length) continue;
    const maxReqAt = t.requests.reduce((max, r) => Math.max(max, r.requestAt || 0), 0);
    const completedAt = Math.max(t.finalMessageAt, t.lastStepAt || t.finalMessageAt, maxReqAt);
    if (completedAt < historyFrom) continue;
    const turnUsage = sumUsageRows(t.requests.map((r) => r.usage));
    if (!turnUsage) continue;
    const finalReq = t.finalStepIdx != null
      ? t.requests.findLast((r) => r.responseStepIdx === t.finalStepIdx)
      : null;
    const finalOutputSpeed = finalReq && finalReq.usage.output > 0 && finalReq.durationMs > 0
      && finalReq.requestAt >= finalReq.durationMs && finalReq.requestAt - finalReq.durationMs >= 1_000_000_000_000
      && finalReq.usage.output <= turnUsage.output
      ? {
        method: 'antigravity_request_elapsed_v1',
        outputTokens: finalReq.usage.output,
        durationMs: finalReq.durationMs,
        completedAt: finalReq.requestAt,
        turnId: t.turnId,
        messageId: t.finalMessageId,
      }
      : null;
    const elapsedMs = completedAt - t.startedAt;
    const firstTtft = t.requests[0]?.ttftMs;
    completedTurns.push({
      turnId: t.turnId,
      startedAt: t.startedAt,
      completedAt,
      finalMessageAt: t.finalMessageAt,
      finalMessageId: t.finalMessageId,
      usage: turnUsage,
      ...(elapsedMs > 0 ? { durationMs: elapsedMs } : {}),
      ...(firstTtft != null && elapsedMs > 0 && firstTtft <= elapsedMs ? { firstTokenMs: firstTtft } : {}),
      ...(finalOutputSpeed ? { finalOutputSpeed } : {}),
      partial: Boolean(t.partial || data.partial),
    });
  }

  let periodStats;
  if (periods) {
    const missingTime = data.requests.some((r) => !r.requestAt);
    let today = 0; let month = 0;
    for (const r of data.requests) {
      if (r.requestAt >= periods.todayFrom) today += r.usage.total;
      if (r.requestAt >= periods.monthFrom) month += r.usage.total;
    }
    periodStats = {
      todayFrom: periods.todayFrom,
      monthFrom: periods.monthFrom,
      today: { total: today, partial: Boolean(data.partial || missingTime) },
      month: { total: month, partial: Boolean(data.partial || missingTime) },
      all: { total: totals.total, partial: Boolean(data.partial) },
    };
  }

  return {
    schemaVersion: 1,
    backend: 'antigravity',
    status: 'ready',
    ...(periodStats ? { periods: periodStats } : {}),
    totals,
    turn,
    latest,
    turnId: latestTurn?.turnId || null,
    turnActive: active,
    latestOutputSpeed,
    completedTurns: completedTurns.slice(-200),
    historyFromAt: 0,
    model: data.model,
    updatedAt: data.updatedAt,
    usageUpdatedAt: data.usageUpdatedAt,
    partial: data.partial,
    scope: 'session_records',
    reason: null,
  };
}

module.exports = { loadSqlite, antigravityHome, antigravityStorageFile, decodeMessage, pick, pickAll, stepItems, toolItem, stepState, waitingFor, askQuestions, readAnnotation, readPinnedOrder, readConversationSummaries, parseRelativeDurationMs, parseAntigravityUsage, workspaceFromUri, readConversation, readConversationUsage, readModel, readSendState, readStepStatuses, normalizeSendText, userStepImages, userStepMediaCount, isRetryableErrorStep, STEP_USER, STEP_MODEL, STEP_TOOL, STEP_ERROR, STATUS_PENDING, STATUS_RUNNING, STATUS_DONE, STATUS_CLEARED, STATUS_WAITING, STATUS_QUEUED, STATUS_ACTIVE, STATUS_FAILED, STATUS_STOPPED };
