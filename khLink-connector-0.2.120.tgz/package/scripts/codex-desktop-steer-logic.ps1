﻿# Pure checks shared by the window driver and its regression tests.
function Plain([string]$value) { ($value -replace '[\u200B-\u200D\u2060\u2063\uFEFF]', '').Trim() }

function Get-CodexQueueButtonNames { @('Queue', '加入队列', '排队') }
function Get-CodexSteerButtonNames { @('Steer', '引导', '调整方向') }

function Test-CodexQueueSendDialog([string[]]$names) {
  ($names -contains '发送消息？') -and
    [bool]($names | Where-Object { $_ -like '*要清除之前已排队*消息*' } | Select-Object -First 1) -and
    ($names -contains '清空队列') -and ($names -contains '发送消息')
}

function Test-CodexQueuePaused([string[]]$names) {
  [bool]($names | Where-Object { $_ -like '*中断了当前响应*队列已暂停*' -or $_ -like '*queue*paused*interrupted*' } | Select-Object -First 1)
}

function Test-CodexQueueRow([string[]]$names, [string]$firstLine) {
  $expected = Plain $firstLine
  if (-not $expected) { return $false }
  foreach ($name in $names) {
    $candidate = Plain (($name -split "\r?\n")[0])
    if ($candidate -eq $expected -or $candidate.EndsWith(": $expected") -or $candidate.EndsWith("：$expected")) { return $true }
  }
  return $false
}

function Test-CodexComposerEmpty([bool]$readable, [string]$value, [string]$name) {
  if (-not $readable) { return $false }
  $value = Plain $value
  return (-not $value) -or ($value -eq (Plain $name))
}
