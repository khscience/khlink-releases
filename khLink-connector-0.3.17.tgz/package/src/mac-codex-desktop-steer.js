'use strict';
// macOS counterpart of codex-desktop-steer.js: hands a message to a task the
// Codex app (ChatGPT.app) runs, through its window, with khLink.app
// (Accessibility) instead of a PowerShell script. Same contract: resolves
// {code, delivery, message}; delivery is not_sent, confirmed or uncertain.
//
// The Codex app's composer offers either Queue or Steer while a turn runs,
// depending on its follow-up setting. A queue request that finds only Steer
// answers control_not_found (not_sent) and changes nothing: the connector
// keeps the message and hands it over once the turn has ended.
const crypto = require('node:crypto');

class MacCodexDesktopSteer {
  /** `adapter`: the DesktopAdapter, or a function returning it (created later). */
  constructor(adapter, { timeoutMs = 30_000 } = {}) {
    this.adapterOf = typeof adapter === 'function' ? adapter : () => adapter;
    this.timeoutMs = timeoutMs;
  }

  async steer({ threadId, title, text, mode = 'steer', canSubmit }) {
    if (!threadId || !String(title || '').trim() || !String(text || '').trim()) {
      return { code: 'missing_input', delivery: 'not_sent', message: '缺少任务标题或消息' };
    }
    if (!['steer', 'queue'].includes(mode)) return { code: 'invalid_mode', delivery: 'not_sent', message: '不支持的发送方式' };
    const adapter = this.adapterOf();
    if (!adapter?.call) return { code: 'helper_unavailable', delivery: 'not_sent', message: '桌面控制助手没有运行' };
    // The helper cannot ask back between typing and pressing Send, so the
    // receipt is checked just before: a message the rollout already shows
    // (or one cancelled meanwhile) is never typed again.
    if (canSubmit) {
      let submit = false;
      try { submit = canSubmit(); } catch { /* treat as handled: keep it for inspection */ }
      if (!submit) return { code: 'already_handled', delivery: 'not_sent', message: '' };
    }
    try {
      const result = await adapter.call({
        action: 'dispatch', requestId: `steer-${crypto.randomUUID()}`, threadId, title: String(title).trim(), mode, text, attachments: [],
      }, this.timeoutMs);
      return shape(result);
    } catch (error) {
      if (error?.response) return shape(error.response);
      return { code: error?.code || 'script_failed', delivery: error?.delivery === 'not_sent' ? 'not_sent' : 'uncertain', message: String(error?.message || error).slice(0, 200) };
    }
  }
}

function shape(result) {
  const code = String(result?.code || 'script_failed');
  const message = String(result?.message || '');
  if (code === 'steer_accepted') return { code, delivery: 'confirmed', message };
  // A plain Send: the task was idle (or became idle), so a new turn started.
  if (code === 'dispatched' && result?.ok !== false) return { code: 'sent', delivery: 'confirmed', message };
  const delivery = result?.delivery === 'not_sent' ? 'not_sent' : 'uncertain';
  return { code, delivery, message };
}

module.exports = { MacCodexDesktopSteer };
