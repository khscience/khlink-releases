// khLink main window on the Mac. It shows the Windows desktop app's own page
// (kh-link-desktop/src, bundled as Resources/web) in WebKit, so both look and
// behave the same, and answers the page's Tauri `invoke` commands here:
// local state, login, updates and autostart through khlink-macos.sh; account,
// pairing, devices and QR direct connection through the connector's
// `cli.js desktop` (desktop-session.js), which holds the account session.
import AppKit
import ApplicationServices
import CoreImage
import Foundation
import WebKit

private let fm = FileManager.default

/// Raised as a JS error by the page's invoke().
struct KHCommandError: Error { let message: String }

// MARK: - Commands

final class KHDesktopCommands {
    private var loginProcess: Process?
    private var loginOutput: [String] = []
    private var loginExit: Int32?
    private var profile: Any = NSNull()
    private var profileFor: String?
    private let lock = NSLock()

    private var sessionFile: URL { KHPaths.data.appendingPathComponent("desktop-session.dat") }
    private var trayPlist: URL { fm.homeDirectoryForCurrentUser.appendingPathComponent("Library/LaunchAgents/com.khlink.tray.plist") }

    /// One call of the connector's `desktop` command.
    func node(_ command: String, _ args: [String: Any] = [:]) throws -> Any {
        let cli = KHPaths.connectorApp.appendingPathComponent("src/cli.js").path
        guard fm.fileExists(atPath: cli) else { throw KHCommandError(message: "连接器还没有安装") }
        let json = String(data: (try? JSONSerialization.data(withJSONObject: args)) ?? Data("{}".utf8), encoding: .utf8) ?? "{}"
        let p = Process()
        let node = KHPaths.runtime.appendingPathComponent("bin/node")
        if fm.fileExists(atPath: node.path) {
            p.executableURL = node; p.arguments = [cli, "desktop", command, json]
        } else {
            p.executableURL = URL(fileURLWithPath: "/usr/bin/env"); p.arguments = ["node", cli, "desktop", command, json]
        }
        var env = ProcessInfo.processInfo.environment
        env["PATH"] = "\(KHPaths.runtime.path)/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
        p.environment = env
        let out = Pipe()
        p.standardOutput = out
        p.standardError = FileHandle.nullDevice
        try p.run()
        // A hung call must not hold the window's queue forever.
        DispatchQueue.global().asyncAfter(deadline: .now() + 60) { if p.isRunning { p.terminate() } }
        let data = out.fileHandleForReading.readDataToEndOfFile()
        p.waitUntilExit()
        let line = String(decoding: data, as: UTF8.self).split(separator: "\n").last.map(String.init) ?? ""
        guard let obj = (try? JSONSerialization.jsonObject(with: Data(line.utf8))) as? [String: Any] else {
            throw KHCommandError(message: "连接器没有响应（\(command)）")
        }
        if obj["ok"] as? Bool == true { return obj["value"] ?? NSNull() }
        throw KHCommandError(message: obj["error"] as? String ?? "操作失败")
    }

    private func script(_ args: [String]) -> (Int32, [String]) {
        var lines: [String] = []
        var code: Int32 = -1
        let done = DispatchSemaphore(value: 0)
        DispatchQueue.main.async {
            khScript(args, onLine: { lines.append($0) }, completion: { c in code = c; done.signal() })
        }
        done.wait()
        return (code, lines)
    }

    private func authenticated() -> Bool { fm.fileExists(atPath: sessionFile.path) }

    private func currentProfile() -> Any {
        guard authenticated() else { return NSNull() }
        let stamp = ((try? fm.attributesOfItem(atPath: sessionFile.path))?[.modificationDate] as? Date)?.description
        lock.lock(); let cached: Any? = profileFor == stamp ? profile : nil; lock.unlock()
        if let cached = cached { return cached }
        let value = ((try? node("state")) as? [String: Any])?["profile"] ?? NSNull()
        lock.lock(); profile = value; profileFor = stamp; lock.unlock()
        return value
    }

    func run(_ cmd: String, _ args: [String: Any]) throws -> Any {
        switch cmd {
        case "get_state":
            let connector = khReadJSON(KHPaths.status) ?? [:]
            let direct = (khReadJSON(KHPaths.config)?["directOnly"] as? Bool) == true
            return [
                "authenticated": authenticated(),
                "connectionMode": direct ? "direct" : "server",
                "server": NSNull(), "deviceId": NSNull(),
                "profile": currentProfile(),
                "autostart": fm.fileExists(atPath: trayPlist.path),
                "connector": connector,
                "awaitingSharedKey": false, "keyHolders": [String](),
            ] as [String: Any]
        case "ensure_connector":
            guard fm.fileExists(atPath: KHPaths.config.path) else { throw KHCommandError(message: "尚未登录") }
            let (code, lines) = script(["start"])
            if code != 0 { throw KHCommandError(message: lines.last ?? "后台服务没能启动") }
            return ["started": true]
        case "begin_login":
            return try beginLogin()
        case "poll_login":
            return try pollLogin()
        case "cancel_login":
            cancelLogin(); return NSNull()
        case "logout":
            _ = try node("logout"); return NSNull()
        case "account", "pairing_status", "confirm_pairing", "revoke_device":
            return try node(cmd, args)
        case "create_pairing":
            return try withQR(node(cmd, args), size: 256)
        case "direct_begin":
            guard fm.fileExists(atPath: KHPaths.config.path) else { throw KHCommandError(message: "请先登录 khLink 账号，再使用二维码直连") }
            _ = script(["start"])
            Thread.sleep(forTimeInterval: 2)
            return try withQR(node("direct", ["method": "POST", "route": "/offer", "body": ["stun": args["stun"] as? Bool ?? false]]), size: 512)
        case "direct_status":
            let v = try node("direct", ["method": "GET", "route": "/status"])
            return (args["qr"] as? Bool) == true ? withQR(v, size: 512) : v
        case "direct_answer":
            return try node("direct", ["method": "POST", "route": "/answer", "body": ["payload": args["payload"] ?? ""]])
        case "direct_cancel":
            return try node("direct", ["method": "POST", "route": "/cancel", "body": [String: Any]()])
        case "direct_server":
            return try node("direct", ["method": "POST", "route": "/server", "body": [String: Any]()])
        case "diagnostics":
            return diagnostics()
        case "clear_diagnostics":
            return NSNull()
        case "usage":
            return [String: Any]()
        case "set_autostart":
            _ = script(["trayautostart", (args["enabled"] as? Bool ?? true) ? "on" : "off"])
            return fm.fileExists(atPath: trayPlist.path)
        case "connector_update_check":
            let v = try node("update_check", ["app": khAppVersion]) as? [String: Any] ?? [:]
            let c = v["connector"] as? [String: Any] ?? [:], a = v["app"] as? [String: Any] ?? [:]
            let appNewer = a["available"] as? Bool ?? false, connNewer = c["available"] as? Bool ?? false
            return [
                "bundled": true, "available": appNewer || connNewer,
                "installed": appNewer ? "khLink \(a["installed"] ?? "")" : (c["installed"] ?? ""),
                "latest": appNewer ? "khLink \(a["latest"] ?? "")" : (c["latest"] ?? ""),
                "notes": (appNewer ? a["notes"] : c["notes"]) ?? "",
                "desktop": ["available": false],
            ] as [String: Any]
        case "connector_update_apply", "desktop_update_apply", "desktop_update_download":
            // The update may replace and restart this app, so it runs on its own.
            DispatchQueue.main.async { khDetachedUpdate() }
            return ["updated": true, "started": true, "installed": "最新版本"]
        case "open_external":
            if let s = args["url"] as? String, let u = URL(string: s), ["https", "http", "mailto"].contains(u.scheme ?? "") {
                DispatchQueue.main.async { NSWorkspace.shared.open(u) }
            }
            return NSNull()
        default:
            throw KHCommandError(message: "Mac 版暂不支持这个功能")
        }
    }

    private func withQR(_ value: Any, size: Int) -> Any {
        guard var v = value as? [String: Any], let payload = v["payload"] as? String else { return value }
        v["qrSvg"] = khQRSvg(payload, size: size) ?? ""
        return v
    }

    private func diagnostics() -> [String: Any] {
        let st = khReadJSON(KHPaths.status) ?? [:]
        let updated = (st["updatedAt"] as? NSNumber)?.doubleValue ?? 0
        let age = updated > 0 ? Date().timeIntervalSince1970 * 1000 - updated : -1
        let online = age >= 0 && age <= 15_000 && ((st["connected"] as? Bool) ?? false)
        let lifecycle = st["lifecycle"] as? String ?? "未知"
        let ax = AXIsProcessTrusted()
        return [
            "current": st,
            "checks": [
                ["name": "连接器心跳", "ok": online, "message": online ? "心跳正常" : "心跳缺失或已过期"],
                ["name": "状态文件", "ok": updated > 0, "message": updated > 0 ? "状态文件可读" : "尚未发现连接器状态"],
                ["name": "生命周期", "ok": lifecycle == "running", "message": "当前为 \(lifecycle)"],
                ["name": "桌面控制（辅助功能）", "ok": ax, "message": ax ? "已授权" : "未授权：点菜单栏 khLink 图标授权"],
            ],
            "heartbeatAgeMs": age >= 0 ? age : NSNull(),
            "entries": [Any](),
        ]
    }

    // MARK: login: the script's browser login, followed here

    private func beginLogin() throws -> Any {
        cancelLogin()
        lock.lock(); loginOutput = []; loginExit = nil; lock.unlock()
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/bin/bash")
        p.arguments = [KHPaths.script.path, "login"]
        var env = ProcessInfo.processInfo.environment
        env["PATH"] = "\(KHPaths.runtime.path)/bin:/usr/bin:/bin:/usr/sbin:/sbin"
        env["KHLINK_APP"] = Bundle.main.bundlePath
        p.environment = env
        let pipe = Pipe()
        p.standardOutput = pipe; p.standardError = pipe
        pipe.fileHandleForReading.readabilityHandler = { [weak self] h in
            let lines = String(decoding: h.availableData, as: UTF8.self).split(separator: "\n").map(String.init)
            self?.lock.lock(); self?.loginOutput += lines; self?.lock.unlock()
        }
        p.terminationHandler = { [weak self] proc in
            pipe.fileHandleForReading.readabilityHandler = nil
            self?.lock.lock(); self?.loginExit = proc.terminationStatus; self?.lock.unlock()
        }
        try p.run()
        lock.lock(); loginProcess = p; lock.unlock()
        return ["started": true]
    }

    private func pollLogin() throws -> Any {
        lock.lock(); let exit = loginExit; let out = loginOutput; lock.unlock()
        guard let code = exit else { return ["status": "pending"] }
        lock.lock(); loginProcess = nil; lock.unlock()
        if code == 0 && fm.fileExists(atPath: KHPaths.config.path) {
            _ = script(["start"])
            lock.lock(); profileFor = nil; lock.unlock()
            return ["status": "complete"]
        }
        let reason = out.reversed().first { !$0.isEmpty && !$0.contains("Terminated") && !$0.contains("http") } ?? "登录没有完成"
        throw KHCommandError(message: reason.replacingOccurrences(of: "khLink: ", with: ""))
    }

    private func cancelLogin() {
        lock.lock(); let p = loginProcess; loginProcess = nil; lock.unlock()
        if let p = p, p.isRunning { p.terminate() }
        khRun(["/bin/launchctl", "bootout", "gui/\(getuid())/com.khlink.login"])
    }
}

/// A QR code as SVG (one rect per dark module), like the Windows app's.
func khQRSvg(_ text: String, size: Int) -> String? {
    guard let filter = CIFilter(name: "CIQRCodeGenerator") else { return nil }
    filter.setValue(Data(text.utf8), forKey: "inputMessage")
    filter.setValue("M", forKey: "inputCorrectionLevel")
    guard let image = filter.outputImage, let cg = CIContext().createCGImage(image, from: image.extent) else { return nil }
    let w = cg.width, h = cg.height
    var pixels = [UInt8](repeating: 255, count: w * h)
    let drawn: Bool = pixels.withUnsafeMutableBytes { buf in
        guard let gray = CGContext(data: buf.baseAddress, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w,
                                   space: CGColorSpaceCreateDeviceGray(), bitmapInfo: CGImageAlphaInfo.none.rawValue) else { return false }
        gray.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
        return true
    }
    guard drawn else { return nil }
    let quiet = 2, n = w + quiet * 2
    var rects = ""
    // Row 0 of the bitmap is the top of the image.
    for y in 0..<h {
        for x in 0..<w where pixels[y * w + x] < 128 {
            rects += "<rect x=\"\(x + quiet)\" y=\"\(y + quiet)\" width=\"1\" height=\"1\"/>"
        }
    }
    return "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 \(n) \(n)\" width=\"\(size)\" height=\"\(size)\" shape-rendering=\"crispEdges\"><rect width=\"\(n)\" height=\"\(n)\" fill=\"#ffffff\"/><g fill=\"#16201c\">\(rects)</g></svg>"
}

// MARK: - Window

final class MainWindowController: NSWindowController, NSWindowDelegate, WKScriptMessageHandlerWithReply, WKNavigationDelegate {
    weak var tray: TrayController?
    private var web: WKWebView!
    private let commands = KHDesktopCommands()
    private let queue = DispatchQueue(label: "vip.fengzhu.khlink.window", attributes: .concurrent)

    init(tray: TrayController) {
        self.tray = tray
        let window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1120, height: 760),
                              styleMask: [.titled, .closable, .miniaturizable, .resizable], backing: .buffered, defer: false)
        window.title = "khLink"
        window.minSize = NSSize(width: 860, height: 620)
        window.isReleasedWhenClosed = false
        window.backgroundColor = NSColor(srgbRed: 0.953, green: 0.929, blue: 0.890, alpha: 1)
        super.init(window: window)
        window.delegate = self

        let config = WKWebViewConfiguration()
        let controller = WKUserContentController()
        controller.addScriptMessageHandler(self, contentWorld: .page, name: "khlink")
        controller.addUserScript(WKUserScript(source: Self.bridge, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        config.userContentController = controller
        web = WKWebView(frame: window.contentView!.bounds, configuration: config)
        web.autoresizingMask = [.width, .height]
        web.navigationDelegate = self
        web.setValue(false, forKey: "drawsBackground")
        window.contentView?.addSubview(web)
        if let index = Bundle.main.resourceURL?.appendingPathComponent("web/index.html"), fm.fileExists(atPath: index.path) {
            web.loadFileURL(index, allowingReadAccessTo: index.deletingLastPathComponent())
        } else {
            web.loadHTMLString("<p style='font:14px -apple-system;padding:40px'>khLink 界面文件缺失，请重新安装 khLink。</p>", baseURL: nil)
        }
        // For support and testing: `open -n khLink.app --args --snapshot` writes this window to
        // ~/Library/Application Support/khLink/window.png (khLink's own window only).
        DistributedNotificationCenter.default().addObserver(self, selector: #selector(snapshot), name: Notification.Name("vip.fengzhu.khlink.snapshot"), object: nil)
    }
    required init?(coder: NSCoder) { nil }

    /// The parts of window.__TAURI__ the desktop page uses.
    private static let bridge = """
    (() => {
      const listeners = {};
      const invoke = (cmd, args) => window.webkit.messageHandlers.khlink.postMessage({ cmd, args: JSON.stringify(args || {}) })
        .then((text) => JSON.parse(text));
      window.__TAURI__ = {
        core: { invoke },
        app: { getVersion: () => invoke('app_version') },
        event: { listen: (name, cb) => { (listeners[name] ||= []).push(cb); return Promise.resolve(() => {}); } },
      };
      document.documentElement.classList.add('platform-mac');
      // The page is shared with the Windows app; say Mac where it names the platform.
      document.addEventListener('DOMContentLoaded', () => {
        document.querySelectorAll('.desktop-label').forEach((el) => { el.textContent = 'Mac 桌面'; });
      });
    })();
    """

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage, replyHandler: @escaping (Any?, String?) -> Void) {
        guard let body = message.body as? [String: Any], let cmd = body["cmd"] as? String else { replyHandler(nil, "无效请求"); return }
        let args = (body["args"] as? String).flatMap { try? JSONSerialization.jsonObject(with: Data($0.utf8)) } as? [String: Any] ?? [:]
        if cmd == "app_version" { replyHandler("\"\(khAppVersion)\"", nil); return }
        queue.async { [commands] in
            do {
                let value = try commands.run(cmd, args)
                let data = try JSONSerialization.data(withJSONObject: [value], options: [])
                // Wrapped in an array so null and booleans survive; unwrap the brackets.
                let text = String(String(decoding: data, as: UTF8.self).dropFirst().dropLast())
                DispatchQueue.main.async { replyHandler(text, nil) }
            } catch let e as KHCommandError {
                DispatchQueue.main.async { replyHandler(nil, e.message) }
            } catch {
                DispatchQueue.main.async { replyHandler(nil, error.localizedDescription) }
            }
        }
    }

    // Links leave for the browser; the page itself stays local.
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let url = action.request.url, url.isFileURL || url.scheme == "about" { decisionHandler(.allow); return }
        // Links leave for the browser; nothing else is handed to the system.
        if let url = action.request.url, ["https", "http", "mailto"].contains(url.scheme ?? "") { NSWorkspace.shared.open(url) }
        decisionHandler(.cancel)
    }

    func refresh() { web.evaluateJavaScript("typeof load === 'function' && load()", completionHandler: nil) }

    func windowWillClose(_ notification: Notification) {
        DispatchQueue.main.async { if !NSApp.windows.contains(where: { $0.isVisible && $0 != self.window }) { NSApp.setActivationPolicy(.accessory) } }
    }

    @objc private func snapshot() {
        web.takeSnapshot(with: nil) { image, _ in
            guard let tiff = image?.tiffRepresentation, let rep = NSBitmapImageRep(data: tiff),
                  let png = rep.representation(using: .png, properties: [:]) else { return }
            try? png.write(to: KHPaths.base.appendingPathComponent("window.png"))
        }
    }
}
