# Drive a Google Antigravity conversation through the app's own window, as if
# done by hand: open the conversation (from the sidebar, or from the
# Conversation History page when the sidebar does not list it), put the text
# in its message box, press its Send button (or its Stop button).
#
#   -Mode send   switch to the conversation, put the message in, press Send
#   -Mode stop   press Stop in the conversation
#   -Mode probe  only look: is the conversation, message box and Send there
#   -Mode check  like send, but clear the box again instead of pressing Send
#   -Mode list   only look: the conversation ids in the sidebar
#   -Mode open   only open the conversation (window left as it was)
#   -Mode settings  open the conversation and read its model and agent
#                permission selectors (each menu is opened, read and closed)
#   -Mode set    choose a model and/or permission preset: -TextFile holds
#                {"model":"Gemini 3.8 Flash High","permission":"Auto"}; the
#                selector's label is read back to confirm the choice
#   -Mode answer answer the question Antigravity is asking (ask_question):
#                -TextFile holds {"answers":[{"labels":[...],"other":"..."}]};
#                the options are radio buttons / check boxes ("1 Apple") and
#                Submit, all pressed through UI Automation. The panel is only
#                drawn while the window is not minimized, so a minimized
#                window is shown without activating it and minimized again.
#   -IdleSeconds N  (send) do nothing and answer user_active when the keyboard
#                or mouse was used in the last N seconds, so a send does not
#                pull the window out from under someone at the computer
#
# It does not use Antigravity's local server, its debugging port or any
# sign-in token: every request to Google is made by Antigravity itself,
# exactly as when the button is pressed by hand. Opening the conversation and
# pressing buttons is UI Automation (Invoke). Its message editor does not take
# text through UI Automation, so the text is pasted: the window is brought to
# the front, the keyboard focus is checked to be in the message box (nothing is
# pasted anywhere else), the clipboard is restored afterwards and the window
# that was in front before gets the foreground back.
# Safety: `send` refuses when the message box already holds a draft, so a
# half-typed message on the computer is never sent or overwritten.
# Output: one JSON line {ok, reason?}.
param(
  [string]$ConversationId = '',
  [string]$TextFile = '',
  [string]$ImageFiles = '',
  [string]$ProgressFile = '',
  [ValidateSet('send', 'stop', 'probe', 'check', 'list', 'answer', 'open', 'settings', 'set', 'usage', 'queue', 'steer', 'cancel_queued', 'rename', 'pin', 'unpin', 'reorder_pin', 'new')][string]$Mode = 'send',
  [int]$IdleSeconds = 0,
  [switch]$SteerNow
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes, System.Windows.Forms, System.Drawing
Add-Type @'
using System; using System.Runtime.InteropServices;
public static class KhAgWin {
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
  [StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT { public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public UIntPtr dwExtraInfo; }
  [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public UIntPtr dwExtraInfo; }
  [StructLayout(LayoutKind.Sequential)] public struct HARDWAREINPUT { public uint uMsg; public ushort wParamL; public ushort wParamH; }
  [StructLayout(LayoutKind.Explicit)] public struct INPUTUNION { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; [FieldOffset(0)] public HARDWAREINPUT hi; }
  [StructLayout(LayoutKind.Sequential)] public struct INPUT { public uint type; public INPUTUNION u; }
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  [DllImport("user32.dll")] public static extern uint SendInput(uint n, INPUT[] inputs, int cbSize);
  [DllImport("user32.dll")] public static extern int GetSystemMetrics(int nIndex);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT pt);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr value);
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [StructLayout(LayoutKind.Sequential)] public struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }
  [DllImport("user32.dll")] static extern bool GetLastInputInfo(ref LASTINPUTINFO info);
  public static void EnableDpiAware() {
    try { if (SetProcessDpiAwarenessContext(new IntPtr(-4))) return; } catch {}
    try { SetProcessDPIAware(); } catch {}
  }
  public static void SendMouse(int x, int y, uint flags) {
    int vLeft = GetSystemMetrics(76);
    int vTop = GetSystemMetrics(77);
    int vWidth = Math.Max(1, GetSystemMetrics(78));
    int vHeight = Math.Max(1, GetSystemMetrics(79));
    int absX = (int)Math.Round((x - vLeft) * 65535.0 / Math.Max(1, vWidth - 1));
    int absY = (int)Math.Round((y - vTop) * 65535.0 / Math.Max(1, vHeight - 1));
    INPUT[] inp = new INPUT[1];
    inp[0].type = 0; // INPUT_MOUSE
    inp[0].u.mi.dx = absX;
    inp[0].u.mi.dy = absY;
    inp[0].u.mi.dwFlags = flags | 0x8000u | 0x4000u; // ABSOLUTE | VIRTUALDESK
    SendInput(1, inp, Marshal.SizeOf(typeof(INPUT)));
  }
  // Milliseconds since the last keyboard or mouse input in this session.
  public static uint IdleMs() {
    LASTINPUTINFO info = new LASTINPUTINFO(); info.cbSize = (uint)Marshal.SizeOf(info);
    if (!GetLastInputInfo(ref info)) return uint.MaxValue;
    return (uint)Environment.TickCount - info.dwTime;
  }
}
'@
$script:utf8NoBom = New-Object System.Text.UTF8Encoding($false)
try { [Console]::OutputEncoding = $script:utf8NoBom; $OutputEncoding = $script:utf8NoBom } catch {}
$script:previous = [IntPtr]::Zero
$script:wasMinimized = $false
$script:sendAttempted = $false
$script:phaseClock = [Diagnostics.Stopwatch]::StartNew()
function Write-ProgressState($phase, $extra) {
  if (-not $ProgressFile) { return }
  $state = @{ phase = $phase; elapsedMs = $script:phaseClock.ElapsedMilliseconds; mayHaveSent = $script:sendAttempted }
  if ($extra) { foreach ($key in $extra.Keys) { $state[$key] = $extra[$key] } }
  [System.IO.File]::WriteAllText($ProgressFile, ($state | ConvertTo-Json -Compress -Depth 6), $script:utf8NoBom)
}
# Shows or hides the sidebar. Older versions expose its toggle as a plain
# button (Invoke); since 2.32 it is an expand/collapse button.
function Set-Sidebar($toggle, $show) {
  try {
    $pattern = $toggle.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern)
    if (($show -and $pattern.Current.ExpandCollapseState -eq 'Expanded') -or
        (-not $show -and $pattern.Current.ExpandCollapseState -eq 'Collapsed')) { return $true }
    if ($show) { $pattern.Expand() } else { $pattern.Collapse() }
    return $true
  } catch {}
  try { $toggle.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke(); return $true } catch { return $false }
}
# Antigravity 2.32's accessibility tree only catches up when it is asked to
# do something (seen: links still missing seconds after the sidebar opened);
# scrolling the toggle into view, where it already is, is a no-op that does.
function Nudge-Tree($element) {
  try { $element.GetCurrentPattern([System.Windows.Automation.ScrollItemPattern]::Pattern).ScrollIntoView() } catch {}
}
function Out-Result($ok, $reason, $extra) {
  if ($script:sidebarShown) { Set-Sidebar $script:sidebarShown $false | Out-Null; $script:sidebarShown = $null }
  # Hand the foreground back to the window the user had in front.
  if ($script:previous -ne [IntPtr]::Zero -and $script:previous -ne $proc.MainWindowHandle -and [KhAgWin]::GetForegroundWindow() -eq $proc.MainWindowHandle) {
    [KhAgWin]::keybd_event(0x87, 0, 0, [UIntPtr]::Zero); [KhAgWin]::SetForegroundWindow($script:previous) | Out-Null; [KhAgWin]::keybd_event(0x87, 0, 2, [UIntPtr]::Zero)
  }
  if ($script:wasMinimized) { Start-Sleep -Milliseconds 300; [KhAgWin]::ShowWindow($proc.MainWindowHandle, 6) | Out-Null }
  $o = @{ ok = $ok; reason = $reason; elapsedMs = $script:phaseClock.ElapsedMilliseconds; mayHaveSent = $script:sendAttempted }
  if ($extra) { foreach ($k in $extra.Keys) { $o[$k] = $extra[$k] } }
  $json = ($o | ConvertTo-Json -Compress -Depth 6) + "`n"
  $bytes = $script:utf8NoBom.GetBytes($json)
  $stdout = [Console]::OpenStandardOutput()
  $stdout.Write($bytes, 0, $bytes.Length)
  $stdout.Flush()
  exit 0
}
trap { Out-Result $false 'automation_error' @{ mayHaveSent = $script:sendAttempted } }
if ($Mode -notin @('list', 'usage', 'new') -and $ConversationId -notmatch '^[0-9a-f-]{36}$') { Out-Result $false 'bad_conversation_id' }

$proc = Get-Process -Name Antigravity -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1
if (-not $proc) { Out-Result $false 'not_running' }
$hwnd = $proc.MainWindowHandle
$win = [System.Windows.Automation.AutomationElement]::FromHandle($hwnd)
Write-ProgressState 'finding' @{}
$ae = [System.Windows.Automation.AutomationElement]
$scope = [System.Windows.Automation.TreeScope]::Descendants

function Find-Named($type, $name) {
  $c1 = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, $type)
  $c2 = New-Object System.Windows.Automation.PropertyCondition($ae::NameProperty, $name)
  return $win.FindFirst($scope, (New-Object System.Windows.Automation.AndCondition($c1, $c2)))
}
function Find-Link($id) {
  $c = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Hyperlink)
  foreach ($link in $win.FindAll($scope, $c)) {
    try { $v = $link.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value } catch { continue }
    if ($v -match "/c/$id(?:[?#]|$)") { return $link }
  }
  return $null
}
# A project in the sidebar lists only its latest conversations behind a
# "See all (N)" button; pressing it shows the rest.
function SeeAll-Buttons {
  $c = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)
  return @($win.FindAll($scope, $c) | Where-Object { [string]$_.Current.Name -match '^See all \(\d+\)$' })
}
function Find-MessageBox { return Find-Named ([System.Windows.Automation.ControlType]::ComboBox) 'Message input' }
# The editor reports its placeholder ("Message input") while empty.
function Box-Text($box) {
  try { $t = [string]$box.GetCurrentPattern([System.Windows.Automation.TextPattern]::Pattern).DocumentRange.GetText(-1) } catch { return '' }
  $t = ($t -replace "`r", '').Trim()
  if ($t -eq 'Message input') { return '' }
  return $t
}
function Ensure-Foreground {
  for ($try = 0; $try -lt 3; $try++) {
    if ([KhAgWin]::GetForegroundWindow() -eq $hwnd -and -not [KhAgWin]::IsIconic($hwnd)) { return $true }
    if ([KhAgWin]::IsIconic($hwnd)) { [KhAgWin]::ShowWindow($hwnd, 9) | Out-Null }
    # A synthetic F24 lets a background process hand over the foreground; it does nothing anywhere.
    [KhAgWin]::keybd_event(0x87, 0, 0, [UIntPtr]::Zero); [KhAgWin]::SetForegroundWindow($hwnd) | Out-Null; [KhAgWin]::keybd_event(0x87, 0, 2, [UIntPtr]::Zero)
    Start-Sleep -Milliseconds 300
  }
  return ([KhAgWin]::GetForegroundWindow() -eq $hwnd -and -not [KhAgWin]::IsIconic($hwnd))
}
# Keystrokes only ever go out with Antigravity in front and the focus in its message box.
function Focus-Box($box) {
  $script:focusIssue = 'foreground_unavailable'
  if (-not (Ensure-Foreground)) { return $false }
  $script:focusIssue = 'focus_unavailable'
  try { $box.SetFocus() } catch { return $false }
  # 2.32 reports the new focus only after the tree is nudged: look a few times.
  for ($try = 0; $try -lt 6; $try++) {
    Start-Sleep -Milliseconds 200
    Nudge-Tree $box
    $focused = $ae::FocusedElement
    if (-not $focused -or [KhAgWin]::GetForegroundWindow() -ne $hwnd) { return $false }
    # Recent editors focus a child of the combobox. Only accept that editor's
    # own descendants, never a different control or another window.
    for ($depth = 0; $depth -lt 8 -and $focused; $depth++) {
      if ([System.Windows.Automation.Automation]::Compare($focused.GetRuntimeId(), $box.GetRuntimeId())) { return $true }
      $focused = [System.Windows.Automation.TreeWalker]::RawViewWalker.GetParent($focused)
    }
  }
  $script:focusIssue = 'focus_outside_editor'
  return $false
}
function Save-Clipboard {
  $state = @{ kind = 'empty'; value = $null }
  try {
    if ([System.Windows.Forms.Clipboard]::ContainsText()) {
      $state.kind = 'text'; $state.value = [System.Windows.Forms.Clipboard]::GetText()
    } elseif ([System.Windows.Forms.Clipboard]::ContainsImage()) {
      $state.kind = 'image'; $state.value = [System.Windows.Forms.Clipboard]::GetImage()
    } elseif ([System.Windows.Forms.Clipboard]::ContainsFileDropList()) {
      $copy = New-Object System.Collections.Specialized.StringCollection
      foreach ($entry in [System.Windows.Forms.Clipboard]::GetFileDropList()) { [void]$copy.Add($entry) }
      $state.kind = 'files'; $state.value = $copy
    }
  } catch {}
  return $state
}
function Restore-Clipboard($state) {
  try {
    if ($state -and $state.kind -eq 'text' -and $null -ne $state.value) {
      [System.Windows.Forms.Clipboard]::SetText([string]$state.value)
    } elseif ($state -and $state.kind -eq 'image' -and $null -ne $state.value) {
      try { [System.Windows.Forms.Clipboard]::SetImage($state.value) } finally { $state.value.Dispose() }
    } elseif ($state -and $state.kind -eq 'files' -and $null -ne $state.value -and $state.value.Count -gt 0) {
      [System.Windows.Forms.Clipboard]::SetFileDropList($state.value)
    } else {
      [System.Windows.Forms.Clipboard]::Clear()
    }
  } catch {}
}
function Paste-Into($box, $value) {
  $saved = Save-Clipboard
  try {
    if (-not (Focus-Box $box)) { return $false }
    [System.Windows.Forms.Clipboard]::SetText($value)
    [System.Windows.Forms.SendKeys]::SendWait('^v')
    Start-Sleep -Milliseconds 350
    return $true
  } finally {
    Restore-Clipboard $saved
  }
}
function Set-ClipboardImageOrFile($file) {
  try {
    $img = [System.Drawing.Image]::FromFile($file)
    try { [System.Windows.Forms.Clipboard]::SetImage($img); return $true } finally { $img.Dispose() }
  } catch {
    # GDI+ in Windows PowerShell does not decode WebP; FileDropList lets Chromium/Electron paste any image format.
    try {
      $list = New-Object System.Collections.Specialized.StringCollection
      [void]$list.Add($file)
      [System.Windows.Forms.Clipboard]::SetFileDropList($list)
      return $true
    } catch { return $false }
  }
}
function Paste-Images($box, $imageFiles) {
  $saved = Save-Clipboard
  try {
    foreach ($file in $imageFiles) {
      if (-not (Focus-Box $box)) { return 'image_needs_foreground' }
      if (-not (Set-ClipboardImageOrFile $file)) { return 'image_paste_failed' }
      [System.Windows.Forms.SendKeys]::SendWait('^v')
      Start-Sleep -Milliseconds 900
    }
    return 'ok'
  } finally {
    Restore-Clipboard $saved
  }
}
function Clear-Box($box) {
  if (-not (Focus-Box $box)) { return }
  [System.Windows.Forms.SendKeys]::SendWait('^a'); [System.Windows.Forms.SendKeys]::SendWait('{DEL}')
}
# The Send button that belongs to this message box. With several conversation
# panes (or a side chat) open there is more than one "Send message", and the
# first one in the window can be another pane's, disabled because its box is
# empty. Look in the box's own composer first: the nearest ancestor holding a
# Send button, the enabled one first. Only then anywhere in the window.
$script:sendNames = @('Send message', 'Send')
function Send-Candidates($root) {
  $c = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)
  return @($root.FindAll($scope, $c) | Where-Object { $script:sendNames -contains ([string]$_.Current.Name).Trim() })
}
function Pick-Send($candidates) {
  $enabled = @($candidates | Where-Object { $_.Current.IsEnabled })
  if ($enabled.Count) { return $enabled[0] }
  if ($candidates.Count) { return $candidates[0] }
  return $null
}
function Find-SendButton($box) {
  if ($box) {
    $walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker
    $node = $box
    for ($depth = 0; $depth -lt 10; $depth++) {
      try { $node = $walker.GetParent($node) } catch { $node = $null }
      if (-not $node -or [System.Windows.Automation.Automation]::Compare($node.GetRuntimeId(), $win.GetRuntimeId())) { break }
      $near = Send-Candidates $node
      if ($near.Count) { return (Pick-Send $near) }
    }
  }
  return (Pick-Send @(Send-Candidates $win | Where-Object { ([string]$_.Current.Name).Trim() -eq 'Send message' }))
}
# What sat around the box when no usable Send was found, for the log.
function Send-Diagnostics($box, $send) {
  $names = @()
  try {
    $walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker
    $node = $walker.GetParent($walker.GetParent($box))
    $c = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)
    $names = @($node.FindAll($scope, $c) | ForEach-Object { '{0}{1}' -f ([string]$_.Current.Name), $(if ($_.Current.IsEnabled) { '' } else { ' (disabled)' }) } | Select-Object -First 15)
  } catch {}
  $version = ''
  try { $version = [string]$proc.MainModule.FileVersionInfo.ProductVersion } catch {}
  return @{
    sendFound = [bool]$send
    sendEnabled = [bool]($send -and $send.Current.IsEnabled)
    sendCount = @(Send-Candidates $win).Count
    boxCount = @($win.FindAll($scope, (New-Object System.Windows.Automation.PropertyCondition($ae::NameProperty, 'Message input')))).Count
    nearButtons = $names
    antigravityVersion = $version
  }
}
# The editor keeps Send disabled until it sees its own input event; a pasted
# text it missed is announced by typing a space and taking it back.
function Wake-Editor($box) {
  if (-not (Focus-Box $box)) { return }
  [System.Windows.Forms.SendKeys]::SendWait('^{END}'); [System.Windows.Forms.SendKeys]::SendWait(' '); [System.Windows.Forms.SendKeys]::SendWait('{BS}')
}

if ($Mode -eq 'list') {
  $c = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Hyperlink)
  $ids = @()
  foreach ($l in $win.FindAll($scope, $c)) {
    try { $v = $l.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value } catch { continue }
    if ($v -match '/c/([0-9a-f-]{36})(?:[?#]|$)') { $ids += $Matches[1] }
  }
  Out-Result $true 'list' @{ ids = @($ids | Select-Object -Unique); collapsed = [bool](SeeAll-Buttons).Count }
}
if ($Mode -in @('send', 'usage') -and $IdleSeconds -gt 0) {
  $idle = [KhAgWin]::IdleMs()
  if ($idle -lt $IdleSeconds * 1000) { Out-Result $false 'user_active' @{ idleMs = $idle } }
}

function Find-QueuedAnchor {
  $c = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Text)
  foreach ($el in $win.FindAll($scope, $c)) {
    $n = [string]$el.Current.Name
    if ($n -match '^(Queued Messages(?:\s*\(\d+\))?|Sends after agent finishes working)$') { return $el }
  }
  return $null
}

function Has-QueuedMessages {
  return [bool](Find-QueuedAnchor)
}

function Normalize-QueuedText($t) {
  return (([string]$t) -replace "`r", '' -replace '\s+', ' ').Trim()
}

function Find-QueuedContainer {
  $anchor = Find-QueuedAnchor
  if (-not $anchor) { return $null }
  $walker = [System.Windows.Automation.TreeWalker]::RawViewWalker
  $cur = $anchor
  $btnCond = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)
  $composerCond = New-Object System.Windows.Automation.PropertyCondition($ae::NameProperty, 'Message input')
  $legacy = $null
  for ($depth = 0; $depth -lt 6; $depth++) {
    $cur = $walker.GetParent($cur)
    if (-not $cur) { break }
    if ($cur.FindFirst($scope, $composerCond)) { break }
    $buttons = @($cur.FindAll($scope, $btnCond))
    if (-not $legacy -and $buttons.Count -ge 3) { $legacy = $cur }
    $toggle = $buttons | Where-Object { $_.Current.Name -match '^(Expand|Collapse) queued messages$' } | Select-Object -First 1
    if (-not $toggle -and $cur.Current.Name -ne 'Queued messages') { continue }
    if ($toggle -and $toggle.Current.Name -match '^Expand') {
      $toggle.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
      Start-Sleep -Milliseconds 250
      Nudge-Tree $cur
    }
    return $cur
  }
  if ($legacy) { return $legacy }
  # A visible header with an unreadable body is not evidence of an empty queue.
  throw 'queue_unreadable'
}

function Test-QueuePreview($full, $preview) {
  if ($full -ceq $preview) { return $true }
  if ($preview -notmatch '(\.{3}|\u2026)$') { return $false }
  $prefix = ($preview -replace '(\.{3}|\u2026)$', '').TrimEnd()
  return $prefix.Length -gt 0 -and $full.StartsWith($prefix, [System.StringComparison]::Ordinal)
}

# Chromium exposes each message text followed by its Send now / Edit / Delete
# buttons, sometimes flattening several rows under the same UIA parent.
function Get-QueuedRows($container) {
  if (-not $container) { return }
  $textCond = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Text)
  $btnCond = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)
  $cond = New-Object System.Windows.Automation.OrCondition($textCond, $btnCond)
  $recent = ''
  $row = $null
  $controls = @($container.FindAll($scope, $cond))
  $count = 0
  $badge = $null
  $afterHeader = $false
  foreach ($el in $controls) {
    $name = Normalize-QueuedText $el.Current.Name
    if ($el.Current.ControlType -eq [System.Windows.Automation.ControlType]::Text) {
      if ($row) { $row; $count++; $row = $null }
      if ($afterHeader -and $name -match '^\d{1,4}$') { $badge = [int]$name }
      $afterHeader = $name -eq 'Queued Messages' -and $null -eq $badge
      $recent = $name
      continue
    }
    if (-not $name) { $name = Normalize-QueuedText $el.Current.HelpText }
    if ($name -notmatch '^(Send now|Send immediately|Steer|Edit|Delete|Remove)(?:\s*:\s*(.+))?$') { continue }
    $verb = $Matches[1]
    $preview = [string]$Matches[2]
    $kind = if ($verb -match '^(Delete|Remove)$') { 'delete' } elseif ($verb -eq 'Edit') { 'edit' } else { 'steer' }
    $text = if ($preview -and -not (Test-QueuePreview $recent $preview)) { $preview } else { $recent }
    if (-not $text) { continue }
    if ($row -and ($row.text -cne $text -or $row.ContainsKey($kind))) { $row; $count++; $row = $null }
    if (-not $row) { $row = @{ text = $text } }
    $row[$kind] = $el
  }
  if ($row) { $row; $count++ }
  if ($count -eq 0) {
    # Older versions expose three unnamed icons. Accept that layout only inside
    # a single message's own group, in its verified Send / Edit / Delete order.
    $walker = [System.Windows.Automation.TreeWalker]::RawViewWalker
    foreach ($el in $controls) {
      if ($el.Current.ControlType -ne [System.Windows.Automation.ControlType]::Text) { continue }
      $cur = $walker.GetParent($el)
      while ($cur -and -not [System.Windows.Automation.Automation]::Compare($cur, $container)) {
        if ($cur.FindAll($scope, $textCond).Count -ne 1) { break }
        $icons = @($cur.FindAll($scope, $btnCond))
        if ($icons.Count -eq 3 -and -not @($icons | Where-Object { $_.Current.Name -or $_.Current.HelpText -or $_.Current.BoundingRectangle.IsEmpty }).Count) {
          $icons = @($icons | Sort-Object { $_.Current.BoundingRectangle.Left })
          if ($icons[0].Current.BoundingRectangle.Right -le $icons[1].Current.BoundingRectangle.Left -and
              $icons[1].Current.BoundingRectangle.Right -le $icons[2].Current.BoundingRectangle.Left) {
            @{ text = Normalize-QueuedText $el.Current.Name; steer = $icons[0]; delete = $icons[2] }
            $count++
          }
          break
        }
        $cur = $walker.GetParent($cur)
      }
    }
  }
  if ($null -ne $badge -and $count -ne $badge) { throw 'queue_unreadable' }
}

function Read-QueuedItems {
  $container = Find-QueuedContainer
  foreach ($row in Get-QueuedRows $container) { $row.text }
}

function Find-QueuedRowButton($rows, $wantedText, $kind) {
  $wanted = Normalize-QueuedText $wantedText
  if (-not $rows.Count) { return @{ status = 'no_queue' } }
  $targets = @($rows | Where-Object { $_.text -ceq $wanted })
  if ($wanted -and -not $targets.Count) {
    $targets = @($rows | Where-Object { (Test-QueuePreview $wanted $_.text) -or (Test-QueuePreview $_.text $wanted) })
  }
  if (-not $targets.Count) { return @{ status = 'queued_item_not_found' } }
  if ($targets.Count -eq 1) {
    $button = $targets[0][$kind]
    if ($button -and $button.Current.IsEnabled) { return @{ status = 'ok'; button = $button; matchedText = $targets[0].text } }
  }
  return @{ status = $(if ($kind -eq 'steer') { 'steer_button_not_found' } else { 'delete_button_not_found' }) }
}

function Invoke-QueuedAction($wantedText, $kind) {
  $rows = @(Get-QueuedRows (Find-QueuedContainer))
  $before = @($rows | ForEach-Object { $_.text })
  $found = Find-QueuedRowButton $rows $wantedText $kind
  if ($found.status -ne 'ok') {
    return @{ ok = $false; reason = $found.status; queuedItems = $before }
  }
  $failed = if ($kind -eq 'steer') { 'steer_invoke_failed' } else { 'delete_invoke_failed' }
  if (-not (Is-TargetOpen)) { return @{ ok = $false; reason = 'conversation_not_opened' } }
  try { $found.button.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke() }
  catch { return @{ ok = $false; reason = $failed; queuedItems = $before } }
  $after = $before
  for ($i = 0; $i -lt 12; $i++) {
    Start-Sleep -Milliseconds 200
    if (-not (Is-TargetOpen)) { return @{ ok = $false; reason = $failed } }
    try { $after = @(Read-QueuedItems) } catch { continue }
    if ($after -cnotcontains $found.matchedText) {
      return @{ ok = $true; reason = $(if ($kind -eq 'steer') { 'steered' } else { 'deleted' }); queuedItems = $after; matchedText = $found.matchedText }
    }
  }
  return @{ ok = $false; reason = $failed; queuedItems = $after }
}

function Has-BackgroundTask {
  $c = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)
  foreach ($b in $win.FindAll($scope, $c)) {
    if ($b.Current.IsEnabled -and [string]$b.Current.Name -match '^(?i)stop task$') { return $true }
  }
  return $false
}

if ($Mode -eq 'usage') {
  $script:previous = [KhAgWin]::GetForegroundWindow()
  if ([KhAgWin]::IsIconic($hwnd)) { $script:wasMinimized = $true; [KhAgWin]::ShowWindow($hwnd, 4) | Out-Null; Start-Sleep -Milliseconds 600 }
  $textCond = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Text)
  $btnCond = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)
  $menuCond = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Menu)
  $itemCond = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::MenuItem)
  function Text-Lines($root) {
    $out = @()
    if (-not $root) { return $out }
    foreach ($el in $root.FindAll($scope, $textCond)) {
      $t = ([string]$el.Current.Name).Trim()
      if ($t) { $out += $t }
    }
    return $out
  }
  function Element-Names($root) {
    $out = @()
    if (-not $root) { return $out }
    foreach ($el in $root.FindAll($scope, [System.Windows.Automation.Condition]::TrueCondition)) {
      $t = ([string]$el.Current.Name).Trim()
      if ($t -and ($out.Count -eq 0 -or $out[$out.Count - 1] -ne $t)) { $out += $t }
    }
    return $out
  }
  function Is-UsageLines($lines) {
    if (-not $lines -or -not $lines.Count) { return $false }
    $joined = $lines -join ' '
    $hasPct = $joined -match '\b\d{1,3}\s*%'
    $hasWindow = $joined -match '(?i)(Weekly limit|Weekly Limit Remaining|5h limit|Five Hour Limit)'
    return ($hasPct -and $hasWindow)
  }
  function Find-UsageFromAnchor($anchorName) {
    $a = Find-Named ([System.Windows.Automation.ControlType]::Text) $anchorName
    if (-not $a) { return @() }
    $cur = $a
    for ($d = 0; $d -lt 8 -and $cur; $d++) {
      $cur = [System.Windows.Automation.TreeWalker]::RawViewWalker.GetParent($cur)
      if (-not $cur) { break }
      $ls = @(Text-Lines $cur)
      if ($ls.Count -gt 80) { break }
      if (Is-UsageLines $ls) {
        # Keep walking one more level if a sibling model group (e.g. Claude and GPT models) sits in the parent card.
        $parent = [System.Windows.Automation.TreeWalker]::RawViewWalker.GetParent($cur)
        if ($parent) {
          $pls = @(Text-Lines $parent)
          if ($pls.Count -le 60 -and (Is-UsageLines $pls)) {
            $cur = $parent
            $ls = $pls
            $grand = [System.Windows.Automation.TreeWalker]::RawViewWalker.GetParent($cur)
            if ($grand) {
              $gls = @(Text-Lines $grand)
              if ($gls.Count -le 60 -and (Is-UsageLines $gls)) { $ls = $gls }
            }
          }
        }
        return $ls
      }
    }
    return @()
  }
  function Find-ModalUsageLines {
    $ls = @(Find-UsageFromAnchor 'Manage your model quota and credits.')
    if ($ls.Count) { return $ls }
    return @(Find-UsageFromAnchor 'Weekly Limit Remaining')
  }
  function Find-UsageSubmenuLines($mainLabel) {
    foreach ($m in $win.FindAll($scope, $menuCond)) {
      $ml = [string]$m.Current.Name
      if ($mainLabel -and $ml -eq $mainLabel) { continue }
      $ls = @(Element-Names $m)
      if (Is-UsageLines $ls) { return $ls }
    }
    # Fast O(1) anchor lookup when the View Usage popup is a Pane/Group instead of Menu.
    $ls = @(Find-UsageFromAnchor 'Weekly limit')
    if ($ls.Count) { return $ls }
    return @(Find-UsageFromAnchor '5h limit')
  }
  # If Models & Usage modal is already open, read directly without closing it.
  $alreadyModal = @(Find-ModalUsageLines)
  if ($alreadyModal.Count) {
    Out-Result $true 'usage' @{ lines = $alreadyModal; source = 'modal_open'; observedAt = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() }
  }
  function Find-ModelSelector {
    foreach ($b in $win.FindAll($scope, $btnCond)) {
      if ([string]$b.Current.Name -like 'Select model*') { return $b }
    }
    return $null
  }
  $modelBtn = Find-ModelSelector
  if (-not $modelBtn) {
    # Open any conversation from the sidebar (prefer ConversationId if given) so Select model appears.
    $targetLink = if ($ConversationId -match '^[0-9a-f-]{36}$') { Find-Link $ConversationId } else { $null }
    if (-not $targetLink) {
      $lc = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Hyperlink)
      foreach ($l in $win.FindAll($scope, $lc)) {
        try { if ($l.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value -match '/c/[0-9a-f-]{36}$') { $targetLink = $l; break } } catch {}
      }
    }
    if ($targetLink) {
      try { $targetLink.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke() } catch {}
      for ($i = 0; $i -lt 20 -and -not $modelBtn; $i++) { Start-Sleep -Milliseconds 150; Nudge-Tree $targetLink; $modelBtn = Find-ModelSelector }
    }
  }
  if (-not $modelBtn) { Out-Result $false 'no_usage_entry' }
  # Bring Antigravity to foreground BEFORE opening the dropdown menu, otherwise
  # SetForegroundWindow afterwards dismisses the Radix popup menu.
  Ensure-Foreground | Out-Null
  Start-Sleep -Milliseconds 150
  Nudge-Tree $modelBtn
  try { $modelBtn.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand() } catch {}
  $mainLabel = [string]$modelBtn.Current.Name
  $viewUsageItem = $null
  for ($i = 0; $i -lt 16 -and -not $viewUsageItem; $i++) {
    Start-Sleep -Milliseconds 150
    Nudge-Tree $modelBtn
    foreach ($m in $win.FindAll($scope, $menuCond)) {
      if ([string]$m.Current.Name -ne $mainLabel) { continue }
      foreach ($it in $m.FindAll($scope, $itemCond)) {
        if ([string]$it.Current.Name -match '^(?i)View Usage\b') { $viewUsageItem = $it; break }
      }
      if ($viewUsageItem) { break }
    }
  }
  function Close-UsageMenus {
    try { $modelBtn.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Collapse() } catch {}
    Start-Sleep -Milliseconds 120
    $stillOpen = @($win.FindAll($scope, $menuCond)).Count -gt 0
    if ($stillOpen -and [KhAgWin]::GetForegroundWindow() -eq $hwnd) {
      [System.Windows.Forms.SendKeys]::SendWait('{ESC}')
      Start-Sleep -Milliseconds 120
      if (@($win.FindAll($scope, $menuCond)).Count -gt 0) {
        [System.Windows.Forms.SendKeys]::SendWait('{ESC}')
        Start-Sleep -Milliseconds 120
      }
    }
  }
  if (-not $viewUsageItem) {
    Close-UsageMenus
    Out-Result $false 'no_usage_entry'
  }
  # 1. Expand View Usage submenu directly via ExpandCollapsePattern (with Right-arrow fallback).
  $lines = @()
  $source = ''
  $viewUsageName = [string]$viewUsageItem.Current.Name
  $viewUsagePatterns = @($viewUsageItem.GetSupportedPatterns() | ForEach-Object { $_.ProgrammaticName })
  try {
    Nudge-Tree $viewUsageItem
    $expandedSub = $false
    try { $viewUsageItem.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand(); $expandedSub = $true } catch {}
    if (-not $expandedSub) {
      $viewUsageItem.SetFocus()
      Start-Sleep -Milliseconds 120
      [System.Windows.Forms.SendKeys]::SendWait('{RIGHT}')
    }
    for ($i = 0; $i -lt 18 -and -not $lines.Count; $i++) {
      Start-Sleep -Milliseconds 150
      Nudge-Tree $viewUsageItem
      $lines = @(Find-UsageSubmenuLines $mainLabel)
      if ($i -eq 5 -and -not $lines.Count) {
        # Some Radix submenus open only on keyboard Right or pointer hover over the item.
        try { $viewUsageItem.SetFocus(); [System.Windows.Forms.SendKeys]::SendWait('{RIGHT}') } catch {}
      }
    }
    if ($lines.Count) {
      $source = 'submenu'
      try { $viewUsageItem.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Collapse() } catch {}
      Start-Sleep -Milliseconds 100
    }
  } catch {}
  # 2. Fallback: click View Usage (clickable point or Enter) to open Models & Usage modal, read, then close.
  if (-not $lines.Count) {
    $openedModal = $false
    try { $viewUsageItem.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke(); $openedModal = $true } catch {}
    if (-not $openedModal) {
      try { $viewUsageItem.SetFocus(); Start-Sleep -Milliseconds 100; [System.Windows.Forms.SendKeys]::SendWait('{ENTER}'); $openedModal = $true } catch {}
    }
    if ($openedModal) {
      for ($i = 0; $i -lt 18 -and -not $lines.Count; $i++) {
        Start-Sleep -Milliseconds 180
        Nudge-Tree $win
        $lines = @(Find-ModalUsageLines)
      }
      if ($lines.Count) {
        $source = 'modal'
        $closed = $false
        foreach ($b in $win.FindAll($scope, $btnCond)) {
          $bn = [string]$b.Current.Name
          if ($bn -match '^(?i)(close|close settings|dismiss)$') {
            try { $b.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke(); $closed = $true; break } catch {}
          }
        }
        if (-not $closed) {
          [System.Windows.Forms.SendKeys]::SendWait('{ESC}')
          Start-Sleep -Milliseconds 150
        }
      }
    }
  } else {
    Close-UsageMenus
  }
  if (-not $lines.Count) {
    Close-UsageMenus
    Out-Result $false 'usage_unreadable'
  }
  Close-UsageMenus
  Out-Result $true 'usage' @{ lines = $lines; source = $source; observedAt = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() }
}

# With the sidebar hidden (its toggle in the title bar) no conversation link
# exists at all: show it for this run and hide it again in Out-Result.
function Any-ConversationLink {
  $c = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Hyperlink)
  foreach ($l in $win.FindAll($scope, $c)) {
    try { if ($l.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value -match '/(?:c/[0-9a-f-]{36}|history)(?:[?#]|$)') { return $true } } catch {}
  }
  return $false
}
function Show-Sidebar {
  $toggle = Find-Named ([System.Windows.Automation.ControlType]::Button) 'Toggle Sidebar'
  if ($toggle) { Nudge-Tree $toggle; Start-Sleep -Milliseconds 150 }
  if (Any-ConversationLink) { return }
  if (-not $toggle) { return }
  if (-not (Set-Sidebar $toggle $true)) { return }
  $script:sidebarShown = $toggle
  for ($i = 0; $i -lt 20 -and -not (Any-ConversationLink); $i++) { Start-Sleep -Milliseconds 150; Nudge-Tree $toggle }
}
# A minimized renderer can expose neither sidebar rows nor the current page.
# Restore it before asking it to navigate; Out-Result returns it to the taskbar.
$script:previous = [KhAgWin]::GetForegroundWindow()
if ($Mode -ne 'probe' -and [KhAgWin]::IsIconic($hwnd)) {
  $script:wasMinimized = $true
  [KhAgWin]::ShowWindow($hwnd, 4) | Out-Null
  Start-Sleep -Milliseconds 300
}
function Shown-Url {
  $c = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Document)
  foreach ($d in $win.FindAll($scope, $c)) {
    try {
      $url = [uri]$d.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value
      if ($url.IsLoopback) { return $url }
    } catch {}
  }
  return $null
}
function Shown-ConversationId {
  $url = Shown-Url
  if ($url -and $url.AbsolutePath -match '^/c/([0-9a-f-]{36})/?$') { return $Matches[1] }
  return ''
}
function Shown-ProjectId {
  $url = Shown-Url
  if ($url -and $url.Query -match '(?:^\?|&)project=([^&#]+)') { return [Uri]::UnescapeDataString($Matches[1]) }
  return ''
}
function Is-NewConversationPage {
  $url = Shown-Url
  return [bool]($url -and ($url.AbsolutePath -eq '/' -or $url.AbsolutePath -eq ''))
}

# Shared composer selector helpers used by settings, set and new modes.
$script:agPresets = @('Request Review', 'Default', 'Auto', 'Turbo')
function Confirm-SettingsTarget {
  if ($Mode -eq 'new') {
    if (-not (Is-NewConversationPage)) { Out-Result $false 'new_conversation_unavailable' }
    return
  }
  $shown = Shown-ConversationId
  if ($shown) { $matchesTarget = $shown -eq $ConversationId } else { $matchesTarget = Is-TargetOpen }
  if (-not $matchesTarget) { Out-Result $false 'conversation_not_opened' }
}
function Selector($prefix) {
  $c = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)
  foreach ($b in $win.FindAll($scope, $c)) { if ([string]$b.Current.Name -like "$prefix*") { return $b } }
  return $null
}
function Current-Of($button) { if ($button -and [string]$button.Current.Name -match 'current:\s*(.+)$') { return $Matches[1].Trim() } return '' }
function Menu-Items($button) {
  Confirm-SettingsTarget
  Nudge-Tree $button
  try { $button.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand() } catch {}
  $items = @()
  for ($i = 0; $i -lt 20 -and -not $items.Count; $i++) {
    Start-Sleep -Milliseconds 150
    Nudge-Tree $button
    # The open menu bears its button's name; a menu just closed can linger in the tree.
    $label = [string]$button.Current.Name
    $menuCondition = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Menu)
    $itemCondition = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::MenuItem)
    foreach ($menu in $win.FindAll($scope, $menuCondition)) {
      if ([string]$menu.Current.Name -ne $label) { continue }
      $items = @($menu.FindAll($scope, $itemCondition) | Where-Object { $_.Current.Name -and $_.Current.Name -ne 'View Usage' })
      if ($items.Count) { break }
    }
  }
  return $items
}
function Close-Menu($button) { try { $button.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Collapse() } catch {} ; Start-Sleep -Milliseconds 200; Nudge-Tree $button }
function Has-Levels($item) { return ($item.GetSupportedPatterns() -contains [System.Windows.Automation.ExpandCollapsePattern]::Pattern) }
function Open-ChoiceMenu($item) {
  Confirm-SettingsTarget
  $label = [string]$item.Current.Name
  if (-not $label -or -not (Ensure-Foreground)) { return $null }
  try { $item.SetFocus() } catch { return $null }
  [System.Windows.Forms.SendKeys]::SendWait('{RIGHT}')
  $menuCondition = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Menu)
  for ($i = 0; $i -lt 12; $i++) {
    Start-Sleep -Milliseconds 150
    Nudge-Tree $item
    foreach ($menu in $win.FindAll($scope, $menuCondition)) {
      if ([string]$menu.Current.Name -ceq $label -and $menu.FindFirst([System.Windows.Automation.TreeScope]::Descendants, [System.Windows.Automation.Condition]::TrueCondition)) { return $menu }
    }
  }
  return $null
}
function Menu-Choices($menu, $type) {
  if ($menu) { $menu.FindAll($scope, (New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, $type))) | Where-Object { $_.Current.Name } }
}
function Level-Buttons($item) { Menu-Choices (Open-ChoiceMenu $item) ([System.Windows.Automation.ControlType]::RadioButton) }
function Back-FromChoices {
  Confirm-SettingsTarget
  if ([KhAgWin]::GetForegroundWindow() -eq $hwnd) { [System.Windows.Forms.SendKeys]::SendWait('{LEFT}'); Start-Sleep -Milliseconds 150 }
}
function Group-Items($group) { Menu-Choices (Open-ChoiceMenu $group) ([System.Windows.Automation.ControlType]::MenuItem) }
function Model-Option($item, $withLevels) {
  $name = [string]$item.Current.Name
  $state = ''
  if ($name -match '^(.*?)\s+(Notice|Unavailable|New)$') { $name = $Matches[1]; $state = $Matches[2] }
  $option = @{ name = $name; available = ($item.Current.IsEnabled -and $state -ne 'Unavailable') }
  if ($withLevels -and $option.available -and (Has-Levels $item)) {
    $levels = @(Level-Buttons $item | ForEach-Object { [string]$_.Current.Name })
    if (-not $levels.Count) { return }
    Back-FromChoices
    foreach ($level in ($levels | Sort-Object Length -Descending)) {
      if ($name.EndsWith(" $level", [System.StringComparison]::Ordinal)) { $option.name = $name.Substring(0, $name.Length - $level.Length - 1); $option.level = $level; break }
    }
    if ($levels.Count) { $option.levels = $levels }
  }
  return $option
}
function Is-Preset($item) {
  $name = [string]$item.Current.Name
  foreach ($p in $script:agPresets) { if ($name -eq $p -or $name.StartsWith("$p ", [System.StringComparison]::Ordinal)) { return $true } }
  return $false
}
function Preset-Option($item) {
  $name = [string]$item.Current.Name
  foreach ($p in $script:agPresets) {
    if ($name -eq $p -or $name.StartsWith("$p ", [System.StringComparison]::Ordinal)) {
      $detail = $name.Substring($p.Length).Trim() -replace '^Default\s+', ''
      return @{ name = $p; detail = $detail; isDefault = ($name.Substring($p.Length).Trim() -match '^Default\s') }
    }
  }
  @{ name = $name; detail = ''; isDefault = $false }
}
function Wait-Current($prefix, $wanted) {
  for ($i = 0; $i -lt 15; $i++) { Start-Sleep -Milliseconds 150; $button = Selector $prefix; Nudge-Tree $button; if ((Current-Of $button) -eq $wanted) { return $true } }
  return $false
}
function Press-MenuElement($element) {
  Confirm-SettingsTarget
  try { $element.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke(); return $true }
  catch { try { $element.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Select(); return $true } catch { return $false } }
}
function Choose-Preset($presetButton, $wanted) {
  if ((Current-Of $presetButton) -eq $wanted) { return $true }
  $target = Menu-Items $presetButton | Where-Object { (Is-Preset $_) -and (Preset-Option $_).name -eq $wanted } | Select-Object -First 1
  if (-not $target -or -not (Press-MenuElement $target)) { Close-Menu $presetButton; return $false }
  return (Wait-Current 'Agent permissions preset' $wanted)
}
function Choose-Model($modelButton, $wanted, $level) {
  $current = Current-Of $modelButton
  if ((-not $level -and $current -eq $wanted) -or ($level -and $current -eq "$wanted $level")) { return 'ok' }
  $target = $null
  $items = @(Menu-Items $modelButton | Where-Object { -not (Is-Preset $_) })
  $rowName = $wanted
  if ($wanted.StartsWith('Orchestrator ', [System.StringComparison]::Ordinal)) {
    $group = $items | Where-Object { $_.Current.Name -like 'Orchestrator *' -and $_.Current.IsEnabled } | Select-Object -First 1
    $items = @(Group-Items $group)
    $rowName = $wanted.Substring('Orchestrator '.Length)
  }
  foreach ($item in $items) {
    $option = Model-Option $item $false
    if (-not $option.available) { continue }
    $name = $option.name
    if ($name -eq $rowName -or ((Has-Levels $item) -and $name.StartsWith("$rowName ", [System.StringComparison]::Ordinal))) { $target = $item; break }
  }
  if (-not $target) { Close-Menu $modelButton; return 'model_not_set' }
  if (-not (Has-Levels $target)) {
    if (-not (Press-MenuElement $target)) { Close-Menu $modelButton; return 'model_not_set' }
    if (Wait-Current 'Select model' $wanted) { return 'ok' } else { return 'model_not_set' }
  }
  $buttons = @(Level-Buttons $target)
  if ($name -ne $rowName) {
    $shownLevel = $name.Substring($rowName.Length + 1)
    if ($shownLevel -notin @($buttons | ForEach-Object { $_.Current.Name })) { Close-Menu $modelButton; return 'model_not_set' }
    if (-not $level) { $level = $shownLevel }
  }
  $pick = $buttons | Where-Object { [string]$_.Current.Name -eq $level } | Select-Object -First 1
  if (-not $pick -or -not (Press-MenuElement $pick)) { Close-Menu $modelButton; return 'level_not_set' }
  if (Wait-Current 'Select model' "$wanted $level") { return 'ok' } else { return 'level_not_set' }
}

if ($Mode -eq 'new') {
  $request = $null
  try { $request = ([System.IO.File]::ReadAllText($TextFile, [System.Text.Encoding]::UTF8) | ConvertFrom-Json) } catch {}
  $prompt = if ($request -and $request.prompt) { [string]$request.prompt } else { '' }
  if ([string]::IsNullOrWhiteSpace($prompt)) { Out-Result $false 'empty_message' }
  $projectId = if ($request -and $request.projectId) { ([string]$request.projectId).Trim() } else { '' }
  $projectName = if ($request -and $request.projectName) { ([string]$request.projectName).Trim() } else { '' }
  $wantedModel = if ($request -and $request.model) { ([string]$request.model).Trim() } else { '' }
  $wantedLevel = if ($request -and $request.level) { ([string]$request.level).Trim() } else { '' }
  $wantedPermission = if ($request -and $request.permission) { ([string]$request.permission).Trim() } else { '' }

  function Find-ProjectNewLink($pidWanted) {
    if (-not $pidWanted -or $pidWanted -eq 'outside-of-project') { return $null }
    $c = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Hyperlink)
    foreach ($l in $win.FindAll($scope, $c)) {
      try {
        $u = [uri]$l.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value
        if ($u.IsLoopback -and ($u.AbsolutePath -eq '/' -or $u.AbsolutePath -eq '') -and $u.Query -match "(?:^\?|&)project=$([Regex]::Escape($pidWanted))(?:&|#|$)") { return $l }
      } catch {}
    }
    return $null
  }
  function Find-GlobalNewLink {
    $c = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Hyperlink)
    foreach ($l in $win.FindAll($scope, $c)) {
      $name = [string]$l.Current.Name
      try {
        $u = [uri]$l.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value
        if ($u.IsLoopback -and ($u.AbsolutePath -eq '/' -or $u.AbsolutePath -eq '') -and [string]::IsNullOrEmpty($u.Query)) { return $l }
      } catch {}
      if ($name -eq 'New Conversation') { return $l }
    }
    return $null
  }
  function Current-ProjectName {
    $btn = Selector 'Select project'
    $cur = Current-Of $btn
    if ($cur -match '^(.*?)\s+\([^()]+\)$') { return $Matches[1].Trim() }
    return $cur
  }
  function Project-Matches($wantId, $wantName) {
    if (-not $wantId -and -not $wantName) { return $true }
    $curName = Current-ProjectName
    if ($wantId -eq 'outside-of-project') { return $curName -eq 'No Project' }
    if ($wantId -and (Shown-ProjectId) -eq $wantId) { return $true }
    if ($wantName -and $curName -eq $wantName) { return $true }
    return $false
  }

  # 1. Navigate to the New Conversation page (prefer the target project's direct sidebar link).
  $navLink = $null
  if ($projectId -and $projectId -ne 'outside-of-project') {
    $navLink = Find-ProjectNewLink $projectId
    if (-not $navLink) { Show-Sidebar; $navLink = Find-ProjectNewLink $projectId }
  }
  if (-not $navLink) {
    $navLink = Find-GlobalNewLink
    if (-not $navLink) { Show-Sidebar; $navLink = Find-GlobalNewLink }
  }
  if ($navLink) {
    try { $navLink.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke() } catch {}
  } elseif (-not (Is-NewConversationPage)) {
    Out-Result $false 'new_conversation_unavailable'
  }

  $box = $null
  $onNew = $false
  for ($i = 0; $i -lt 30; $i++) {
    Start-Sleep -Milliseconds 150
    if ($navLink) { Nudge-Tree $navLink } else { Nudge-Tree $win }
    $onNew = Is-NewConversationPage
    $box = Find-MessageBox
    if ($onNew -and $box) { break }
  }
  if (-not $onNew) { Out-Result $false 'new_conversation_unavailable' }
  if (-not $box) { Out-Result $false 'no_message_box' }
  Write-ProgressState 'opened' @{}

  # 2. Confirm or switch the selected project via the "Select project, current: ..." dropdown.
  if (-not (Project-Matches $projectId $projectName)) {
    $projBtn = Selector 'Select project'
    if (-not $projBtn) { Out-Result $false 'project_not_selected' }
    $targetLabel = if ($projectId -eq 'outside-of-project') { 'No Project' } else { $projectName }
    if (-not $targetLabel) { Out-Result $false 'project_not_selected' }
    Ensure-Foreground | Out-Null
    Nudge-Tree $projBtn
    $expanded = $false
    try { $projBtn.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand(); $expanded = $true } catch {}
    if (-not $expanded) {
      try { $projBtn.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke() } catch {}
    }
    Start-Sleep -Milliseconds 250
    function Find-ProjectChoice($wantLabel) {
      $types = @(
        [System.Windows.Automation.ControlType]::MenuItem,
        [System.Windows.Automation.ControlType]::ListItem,
        [System.Windows.Automation.ControlType]::Button
      )
      foreach ($t in $types) {
        $cond = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, $t)
        foreach ($el in $win.FindAll($scope, $cond)) {
          $n = ([string]$el.Current.Name).Trim()
          if (-not $n -or $n -like 'Select project*') { continue }
          if ($n -eq $wantLabel -or $n.StartsWith("$wantLabel (", [System.StringComparison]::Ordinal)) {
            if ($el.Current.IsEnabled -and -not $el.Current.IsOffscreen) { return $el }
          }
        }
      }
      return $null
    }
    $choice = $null
    for ($try = 0; $try -lt 8 -and -not $choice; $try++) {
      Nudge-Tree $projBtn
      $choice = Find-ProjectChoice $targetLabel
      if (-not $choice) { Start-Sleep -Milliseconds 150 }
    }
    # If the project is not in the "Recent" slice, filter using the dropdown search box.
    if (-not $choice -and $projectId -ne 'outside-of-project') {
      $editCond = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Edit)
      $searchBox = $win.FindAll($scope, $editCond) | Where-Object {
        $en = [string]$_.Current.Name
        -not $_.Current.IsOffscreen -and $en -match '(?i)search\s*(project|workspace)'
      } | Select-Object -First 1
      if ($searchBox) {
        try {
          $searchBox.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue($targetLabel)
        } catch {
          try { Paste-Into $searchBox $targetLabel | Out-Null } catch {}
        }
        for ($try = 0; $try -lt 10 -and -not $choice; $try++) {
          Start-Sleep -Milliseconds 150
          Nudge-Tree $searchBox
          $choice = Find-ProjectChoice $targetLabel
        }
      } else {
        $thisComputer = Find-ProjectChoice 'This Computer'
        if ($thisComputer) {
          try { $thisComputer.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand() }
          catch { try { $thisComputer.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke() } catch {} }
          for ($try = 0; $try -lt 10 -and -not $choice; $try++) {
            Start-Sleep -Milliseconds 150
            Nudge-Tree $thisComputer
            $choice = Find-ProjectChoice $targetLabel
          }
        }
      }
    }
    if (-not $choice) {
      Close-Menu $projBtn
      if ([KhAgWin]::GetForegroundWindow() -eq $hwnd) { [System.Windows.Forms.SendKeys]::SendWait('{ESC}') }
      Out-Result $false 'project_not_selected' @{ currentProject = (Current-ProjectName) }
    }
    if (-not (Press-MenuElement $choice)) {
      Close-Menu $projBtn
      Out-Result $false 'project_not_selected' @{ currentProject = (Current-ProjectName) }
    }
    $matched = $false
    for ($i = 0; $i -lt 15; $i++) {
      Start-Sleep -Milliseconds 150
      $projBtnNow = Selector 'Select project'
      if ($projBtnNow) { Nudge-Tree $projBtnNow }
      if (Project-Matches $projectId $projectName) { $matched = $true; break }
    }
    if (-not $matched) { Out-Result $false 'project_not_selected' @{ currentProject = (Current-ProjectName) } }
  }

  # 3. Draft safety: never overwrite half-typed text left in the New Conversation box.
  $box = Find-MessageBox
  if (-not $box) { Out-Result $false 'no_message_box' }
  if (Box-Text $box) { Out-Result $false 'draft_in_box' }

  # 4. Optional model / thinking effort / permission preset before sending.
  if ($wantedModel) {
    $modelButton = Selector 'Select model'
    if (-not $modelButton) { Out-Result $false 'no_settings' }
    $outcome = Choose-Model $modelButton $wantedModel $wantedLevel
    if ($outcome -ne 'ok') { Out-Result $false $outcome @{ model = (Current-Of $modelButton) } }
  }
  if ($wantedPermission) {
    $presetButton = Selector 'Agent permissions preset'
    if (-not $presetButton) { Out-Result $false 'no_settings' }
    if (-not (Choose-Preset $presetButton $wantedPermission)) { Out-Result $false 'permission_not_set' @{ permission = (Current-Of $presetButton) } }
  }

  # 5. Paste the first prompt and press Send.
  $box = Find-MessageBox
  if (-not $box) { Out-Result $false 'no_message_box' }
  if (-not (Is-NewConversationPage)) { Out-Result $false 'new_conversation_unavailable' }
  if (-not (Project-Matches $projectId $projectName)) { Out-Result $false 'project_not_selected' @{ currentProject = (Current-ProjectName) } }
  $norm = { param($t) ($t -replace "`r", '' -replace '\s+', ' ').Trim() }
  if (-not (Paste-Into $box $prompt)) { Out-Result $false 'needs_foreground' @{ focusIssue = $script:focusIssue } }
  $taken = $false
  for ($try = 0; $try -lt 6 -and -not $taken; $try++) {
    if ($try) { Start-Sleep -Milliseconds 200; Nudge-Tree $box }
    $taken = (& $norm (Box-Text $box)) -eq (& $norm $prompt)
  }
  if (-not $taken) { Clear-Box $box; Out-Result $false 'text_not_taken' }
  $send = $null
  for ($i = 0; $i -lt 15; $i++) {
    $send = Find-SendButton $box
    if ($send -and $send.Current.IsEnabled) { break }
    if ($i -eq 7 -and $send) { Wake-Editor $box }
    Start-Sleep -Milliseconds 150
  }
  if (-not $send -or -not $send.Current.IsEnabled) { $diag = Send-Diagnostics $box $send; Clear-Box $box; Out-Result $false 'send_unavailable' @{ sendDiag = $diag } }
  if (-not (Is-NewConversationPage)) { Clear-Box $box; Out-Result $false 'new_conversation_unavailable' }
  $invoke = $send.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
  $script:sendAttempted = $true
  Write-ProgressState 'clicking' @{}
  $invoke.Invoke()
  Write-ProgressState 'clicked' @{}

  # 6. Wait for Antigravity to navigate from / to /c/<new-uuid>.
  for ($i = 0; $i -lt 40; $i++) {
    Start-Sleep -Milliseconds 200
    $createdId = Shown-ConversationId
    if ($createdId -match '^[0-9a-f-]{36}$') {
      $receipt = @{
        conversationId = $createdId
        confirmedAt = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
        model = (Current-Of (Selector 'Select model'))
        permission = (Current-Of (Selector 'Agent permissions preset'))
        project = (Current-ProjectName)
      }
      Write-ProgressState 'confirmed' $receipt
      Out-Result $true 'created' $receipt
    }
  }
  Out-Result $true 'clicked' @{ mayHaveSent = $true }
}
if ($Mode -eq 'reorder_pin') {
  try { [KhAgWin]::EnableDpiAware() } catch {}
  $request = $null
  try { $request = ([System.IO.File]::ReadAllText($TextFile, [System.Text.Encoding]::UTF8) | ConvertFrom-Json) } catch {}
  $targetId = if ($request -and $request.targetId) { ([string]$request.targetId).Trim() } else { '' }
  $position = if ($request -and $request.position -in @('before', 'after')) { [string]$request.position } else { 'before' }
  if ($targetId -notmatch '^[0-9a-f-]{36}$' -or $targetId -eq $ConversationId) { Out-Result $false 'bad_conversation_id' }
  Show-Sidebar
  if (-not (Ensure-Foreground)) { Out-Result $false 'needs_foreground' }
  Start-Sleep -Milliseconds 250
  $win = $ae::FromHandle($hwnd)
  $walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker
  $linkCond = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Hyperlink)
  function Find-PinnedSidebarLink($convId) {
    $candidates = @()
    foreach ($l in $win.FindAll($scope, $linkCond)) {
      try {
        $u = [uri]$l.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value
        if (-not $u.IsLoopback -or $u.AbsolutePath.TrimEnd('/') -ne "/c/$convId") { continue }
      } catch { continue }
      $hasUnpin = $false
      $node = $walker.GetParent($l)
      for ($i = 0; $node -and $i -lt 3; $i++) {
        if ($node.FindAll($scope, $linkCond).Count -ne 1) { break }
        $unpinCond = New-Object System.Windows.Automation.PropertyCondition($ae::NameProperty, 'Unpin conversation')
        $hits = @($node.FindAll($scope, $unpinCond) | Where-Object { $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Button' })
        if ($hits.Count -ge 1) { $hasUnpin = $true; break }
        $node = $walker.GetParent($node)
      }
      $r = $l.Current.BoundingRectangle
      $top = if (-not $r.IsEmpty) { $r.Top } else { 1e9 }
      $candidates += @{ el = $l; hasUnpin = $hasUnpin; top = $top }
    }
    if (-not $candidates.Count) { return $null }
    $pinned = @($candidates | Where-Object { $_.hasUnpin })
    $pool = if ($pinned.Count) { $pinned } else { $candidates }
    return ($pool | Sort-Object { $_.top } | Select-Object -First 1).el
  }
  $srcLink = Find-PinnedSidebarLink $ConversationId
  $dstLink = Find-PinnedSidebarLink $targetId
  if (-not $srcLink -or -not $dstLink) { Out-Result $false 'conversation_not_in_sidebar' }
  function Valid-AgRect($el, $winRect) {
    if (-not $el) { return $null }
    $r = $el.Current.BoundingRectangle
    if ($r.IsEmpty -or $r.Width -lt 10 -or $r.Height -lt 10 -or $el.Current.IsOffscreen) { return $null }
    if (-not $winRect.IsEmpty) {
      $cx = $r.Left + $r.Width * 0.5; $cy = $r.Top + $r.Height * 0.5
      if ($cx -lt $winRect.Left -or $cx -gt $winRect.Right -or $cy -lt $winRect.Top -or $cy -gt $winRect.Bottom) { return $null }
    }
    return $r
  }
  $winRect = $win.Current.BoundingRectangle
  $srcRect = Valid-AgRect $srcLink $winRect
  $dstRect = Valid-AgRect $dstLink $winRect
  if (-not $srcRect) { try { $srcLink.GetCurrentPattern([System.Windows.Automation.ScrollItemPattern]::Pattern).ScrollIntoView(); Start-Sleep -Milliseconds 150 } catch {} }
  if (-not $dstRect) { try { $dstLink.GetCurrentPattern([System.Windows.Automation.ScrollItemPattern]::Pattern).ScrollIntoView(); Start-Sleep -Milliseconds 150 } catch {} }
  $srcRect = Valid-AgRect $srcLink $winRect
  $dstRect = Valid-AgRect $dstLink $winRect
  if (-not $srcRect -or -not $dstRect) { Out-Result $false 'drag_failed' }
  $savedPt = New-Object KhAgWin+POINT
  $savedOk = [KhAgWin]::GetCursorPos([ref]$savedPt)
  $srcX = [int][Math]::Round($srcRect.Left + $srcRect.Width * 0.35)
  $srcY = [int][Math]::Round($srcRect.Top + $srcRect.Height * 0.50)
  $dstX = [int][Math]::Round($dstRect.Left + $dstRect.Width * 0.35)
  $dstY = if ($position -eq 'before') { [int][Math]::Round($dstRect.Top + [Math]::Max(3, $dstRect.Height * 0.22)) } else { [int][Math]::Round($dstRect.Top + [Math]::Min($dstRect.Height - 3, $dstRect.Height * 0.78)) }
  $dir = if ($dstY -ge $srcY) { 1 } else { -1 }
  $down = $false
  $lastX = $srcX; $lastY = $srcY
  try {
    [KhAgWin]::SendMouse($srcX, $srcY, 0x0001)
    Start-Sleep -Milliseconds 90
    if ([KhAgWin]::GetForegroundWindow() -ne $hwnd) { Out-Result $false 'needs_foreground' }
    [KhAgWin]::SendMouse($srcX, $srcY, 0x0002)
    $down = $true
    Start-Sleep -Milliseconds 90
    $startY = $srcY + ($dir * 10)
    [KhAgWin]::SendMouse($srcX, $startY, 0x0001)
    $lastX = $srcX; $lastY = $startY
    Start-Sleep -Milliseconds 80
    $steps = 18
    for ($i = 1; $i -le $steps; $i++) {
      if (($i % 4 -eq 0) -and [KhAgWin]::GetForegroundWindow() -ne $hwnd) { Out-Result $false 'needs_foreground' }
      $t = $i / [double]$steps
      $x = [int][Math]::Round($srcX + ($dstX - $srcX) * $t)
      $y = [int][Math]::Round($startY + ($dstY - $startY) * $t)
      [KhAgWin]::SendMouse($x, $y, 0x0001)
      $lastX = $x; $lastY = $y
      Start-Sleep -Milliseconds 18
    }
    [KhAgWin]::SendMouse($dstX, $dstY + ($dir * 2), 0x0001)
    Start-Sleep -Milliseconds 50
    [KhAgWin]::SendMouse($dstX, $dstY, 0x0001)
    $lastX = $dstX; $lastY = $dstY
    Start-Sleep -Milliseconds 140
    [KhAgWin]::SendMouse($dstX, $dstY, 0x0004)
    $down = $false
    Start-Sleep -Milliseconds 180
  } finally {
    if ($down) { [KhAgWin]::SendMouse($lastX, $lastY, 0x0004) }
    if ($savedOk) { [KhAgWin]::SetCursorPos($savedPt.X, $savedPt.Y) | Out-Null }
  }
  Out-Result $true 'reordered'
}
$manageRow = $Mode -in @('rename', 'pin', 'unpin')
$alreadyOpen = -not $manageRow -and (Shown-ConversationId) -eq $ConversationId
$link = if (-not $alreadyOpen) { Find-Link $ConversationId }
$navigate = -not $alreadyOpen -and $Mode -ne 'probe'
if (-not $link -and $navigate) { Show-Sidebar; $link = Find-Link $ConversationId }
if (-not $link -and $navigate) {
  $more = SeeAll-Buttons
  foreach ($b in $more) { try { $b.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke() } catch {} }
  if ($more.Count) { Start-Sleep -Milliseconds 600; $link = Find-Link $ConversationId }
}
# Conversations outside pinned and projects are on the Conversation History
# page. That page is only drawn while the window is not minimized.
if (-not $link -and $navigate) {
  $history = $null
  $hc = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Hyperlink)
  foreach ($l in $win.FindAll($scope, $hc)) {
    try { if ($l.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value -match '/history(?:[?#]|$)') { $history = $l; break } } catch {}
  }
  if ($history) {
    $history.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
    for ($i = 0; $i -lt 15 -and -not $link; $i++) { Start-Sleep -Milliseconds 200; $link = Find-Link $ConversationId }
  }
}
$shownTitle = ''
if ($alreadyOpen) {
  $name = [string]$win.Current.Name
  $cut = $name.IndexOf(' - ')
  if ($cut -gt 0) { $shownTitle = $name.Substring(0, $cut) } else { $shownTitle = $name }
}
if (-not $link -and -not $alreadyOpen) { Out-Result $false 'conversation_not_in_sidebar' }
if ($manageRow) {
  # The action buttons and the inline title editor are siblings of this
  # exact conversation link. Never search the whole sidebar for a pin or edit.
  function Get-ActionRow {
    $target = Find-Link $ConversationId
    if (-not $target) { return }
    $url = [uri]$target.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value
    if (-not $url.IsLoopback -or $url.AbsolutePath.TrimEnd('/') -ne "/c/$ConversationId") { return }
    $walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker
    $node = $walker.GetParent($target)
    $links = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Hyperlink)
    for ($i = 0; $node -and $i -lt 3; $i++) {
      if ($node.FindAll($scope, $links).Count -ne 1) { return }
      if ((Row-Control $node Edit 'Edit title') -or (Row-Control $node Button 'More options') -or
          (Row-Control $node Button 'Pin conversation') -or (Row-Control $node Button 'Unpin conversation')) { return $node }
      $node = $walker.GetParent($node)
    }
  }
  function Row-Control($row, [string]$type, [string]$name) {
    if (-not $row) { return }
    $cond = New-Object System.Windows.Automation.PropertyCondition($ae::NameProperty, $name)
    $hits = @($row.FindAll($scope, $cond) | Where-Object { $_.Current.ControlType.ProgrammaticName -eq "ControlType.$type" -and $_.Current.IsEnabled })
    if ($hits.Count -eq 1) { return $hits[0] }
  }
  $row = Get-ActionRow
  if (-not $row) { Out-Result $false 'row_control_unavailable' }
  if ($Mode -in @('pin', 'unpin')) {
    $want = if ($Mode -eq 'pin') { 'Pin conversation' } else { 'Unpin conversation' }
    $opposite = if ($Mode -eq 'pin') { 'Unpin conversation' } else { 'Pin conversation' }
    $button = Row-Control $row Button $want
    if ($button) { $button.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke() }
    elseif (-not (Row-Control $row Button $opposite)) { Out-Result $false 'row_control_unavailable' }
    Out-Result $true 'pin_requested'
  }
  $title = [IO.File]::ReadAllText($TextFile, [Text.Encoding]::UTF8).Trim()
  if (-not $title -or $title -match '[\r\n]') { Out-Result $false 'invalid_title' }
  if (Row-Control $row Edit 'Edit title') { Out-Result $false 'title_edit_in_progress' }
  if (-not (Ensure-Foreground)) { Out-Result $false 'needs_foreground' }
  $menuButton = Row-Control (Get-ActionRow) Button 'More options'
  if (-not $menuButton) { Out-Result $false 'row_control_unavailable' }
  Nudge-Tree $menuButton
  $expand = $null
  if ($menuButton.TryGetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern, [ref]$expand)) {
    if ($expand.Current.ExpandCollapseState -ne 'Expanded') { $expand.Expand() }
  } else { $menuButton.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke() }
  $menuWait = [Diagnostics.Stopwatch]::StartNew()
  do {
    $win = $ae::FromHandle($hwnd)
    $menu = Row-Control $win Menu 'More options'
    $rename = Row-Control $menu MenuItem 'Rename'
    if ($rename -and -not $rename.Current.IsOffscreen) { break }
    if ($menu) { Nudge-Tree $menu } else { Nudge-Tree $menuButton }
    Start-Sleep -Milliseconds 100
  } while ($menuWait.ElapsedMilliseconds -lt 6500)
  if (-not $rename -or $rename.Current.IsOffscreen) { Out-Result $false 'row_control_unavailable' }
  $rename.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
  for ($i = 0; $i -lt 18; $i++) {
    $edit = Row-Control (Get-ActionRow) Edit 'Edit title'
    if ($edit) { break }
    Start-Sleep -Milliseconds 100
  }
  if (-not $edit -or -not (Focus-Box $edit)) { Out-Result $false 'title_edit_unavailable' }
  $edit.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue($title)
  $edit = Row-Control (Get-ActionRow) Edit 'Edit title'
  if (-not $edit -or -not $edit.Current.HasKeyboardFocus -or [KhAgWin]::GetForegroundWindow() -ne $hwnd) { Out-Result $false 'title_edit_unavailable' }
  [System.Windows.Forms.SendKeys]::SendWait('{ENTER}')
  Out-Result $true 'rename_requested'
}
if ($Mode -eq 'probe') {
  $box = Find-MessageBox
  $send = Find-SendButton $box
  $title = if ($link) { [string]$link.Current.Name } else { $shownTitle }
  $shown = Shown-ConversationId
  $current = if ($shown) { $shown -eq $ConversationId } else { $title.Length -gt 0 -and ([string]$win.Current.Name).StartsWith("$title - ", [System.StringComparison]::Ordinal) }
  $active = $false
  $buttonCondition = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)
  foreach ($button in $win.FindAll($scope, $buttonCondition)) {
    if ($button.Current.IsEnabled -and [string]$button.Current.Name -match '^(?i)(stop task|(stop|cancel)( generation| response)?( \(ctrl\+\w\))?)$') { $active = $true; break }
  }
  $qItems = @(if ($current) { Read-QueuedItems })
  Out-Result $true 'probe' @{ link = [bool]$link; box = [bool]$box; send = [bool]($send -and $send.Current.IsEnabled); title = $title; current = $current; active = $active; queued = ($qItems.Count -gt 0 -or (Has-QueuedMessages)); queuedItems = $qItems; backgroundTask = (Has-BackgroundTask); foreground = ([KhAgWin]::GetForegroundWindow() -eq $hwnd -and -not [KhAgWin]::IsIconic($hwnd)); observedAt = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() }
}

$targetTitle = if ($link) { [string]$link.Current.Name } else { $shownTitle }
if ($link -and (Shown-ConversationId) -ne $ConversationId) {
  $link.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
}
function Is-TargetOpen {
  # 2.32 shortens a long title in the window's name; its page address is exact.
  $shown = Shown-ConversationId
  if ($shown) { return $shown -eq $ConversationId }
  $name = [string]$win.Current.Name
  return $targetTitle.Length -gt 0 -and ($name -eq $targetTitle -or $name.StartsWith("$targetTitle - ", [System.StringComparison]::Ordinal))
}
$box = $null
$opened = $false
for ($i = 0; $i -lt 30; $i++) {
  Start-Sleep -Milliseconds 150
  Nudge-Tree $link
  # While a question is showing, its panel takes the message box's place.
  $opened = Is-TargetOpen
  if ($Mode -in @('answer', 'open', 'stop', 'settings', 'set', 'queue', 'steer', 'cancel_queued')) { if ($opened) { break } else { continue } }
  $box = Find-MessageBox
  if ($box -and $opened) { break }
}
if (-not $opened) { Out-Result $false 'conversation_not_opened' }
Write-ProgressState 'opened' @{}
if (-not $box -and $Mode -in @('send', 'check')) { Out-Result $false 'no_message_box' }
if ($Mode -eq 'open') { Out-Result $true 'opened' @{ title = $targetTitle } }

# The model and permission selectors under the message box are menu buttons
# (ExpandCollapse): "Select model, current: Gemini 3.8 Flash High" and
# "Agent permissions preset selector, current: Auto". Their menus list the
# choices as menu items; a model item may end in " Notice" or " Unavailable".
if ($Mode -in @('settings', 'set')) {
  $modelButton = Selector 'Select model'
  $presetButton = Selector 'Agent permissions preset'
  if (-not $modelButton -and -not $presetButton) { Out-Result $false 'no_settings' }
  if ($Mode -eq 'settings') {
    $models = @(); $permissions = @()
    if ($modelButton) {
      # Closing a level submenu replaces the parent menu's UIA elements in 2.34.
      # Snapshot their labels, then resolve each row in the currently open menu.
      $labels = @(Menu-Items $modelButton | Where-Object { -not (Is-Preset $_) } | ForEach-Object { [string]$_.Current.Name })
      $models = @(foreach ($label in $labels) {
        $item = Menu-Items $modelButton | Where-Object { $_.Current.Name -ceq $label } | Select-Object -First 1
        if (-not $item) { Close-Menu $modelButton; Out-Result $false 'model_list_changed' }
        # In 2.34 Orchestrator is a group of models, each with its own effort submenu.
        if ($label -like 'Orchestrator *' -and (Has-Levels $item)) {
          $childLabels = @(Group-Items $item | ForEach-Object { [string]$_.Current.Name })
          Back-FromChoices
          foreach ($childLabel in $childLabels) {
            $group = Menu-Items $modelButton | Where-Object { $_.Current.Name -ceq $label } | Select-Object -First 1
            $child = Group-Items $group | Where-Object { $_.Current.Name -ceq $childLabel } | Select-Object -First 1
            if ($child) {
              $option = Model-Option $child $true
              if ($option) { $option.name = 'Orchestrator ' + $option.name; $option }
            }
            Back-FromChoices
          }
        } else { Model-Option $item $true }
      })
      Close-Menu $modelButton
      if (-not $models.Count) { Out-Result $false 'model_list_changed' }
    }
    if ($presetButton) { $permissions = @(Menu-Items $presetButton | Where-Object { Is-Preset $_ } | ForEach-Object { Preset-Option $_ }); Close-Menu $presetButton }
    Confirm-SettingsTarget
    Out-Result $true 'settings' @{ model = (Current-Of (Selector 'Select model')); permission = (Current-Of (Selector 'Agent permissions preset')); models = $models; permissions = $permissions }
  }
  $request = $null
  try { $request = ([System.IO.File]::ReadAllText($TextFile, [System.Text.Encoding]::UTF8) | ConvertFrom-Json) } catch {}
  if (-not $request -or (-not $request.model -and -not $request.permission)) { Out-Result $false 'bad_settings' }
  if ($request.model) {
    if (-not $modelButton) { Out-Result $false 'no_settings' }
    $outcome = Choose-Model $modelButton ([string]$request.model) ([string]$request.level)
    if ($outcome -ne 'ok') { Out-Result $false $outcome @{ model = (Current-Of $modelButton) } }
  }
  if ($request.permission) {
    if (-not $presetButton) { Out-Result $false 'no_settings' }
    if (-not (Choose-Preset $presetButton ([string]$request.permission))) { Out-Result $false 'permission_not_set' @{ permission = (Current-Of $presetButton) } }
  }
  Confirm-SettingsTarget
  Out-Result $true 'set' @{ model = (Current-Of (Selector 'Select model')); permission = (Current-Of (Selector 'Agent permissions preset')) }
}

if ($Mode -eq 'answer') {
  $request = $null
  try { $request = ([System.IO.File]::ReadAllText($TextFile, [System.Text.Encoding]::UTF8) | ConvertFrom-Json) } catch {}
  if (-not $request -or -not $request.answers) { Out-Result $false 'bad_answer' }
  $choiceTypes = @([System.Windows.Automation.ControlType]::RadioButton, [System.Windows.Automation.ControlType]::CheckBox)
  function Choices {
    $found = @()
    foreach ($t in $choiceTypes) {
      $c = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, $t)
      foreach ($e in $win.FindAll($scope, $c)) { if ([string]$e.Current.Name -match '^\d+\s') { $found += $e } }
    }
    return $found
  }
  function Pick($el) {
    try { $el.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Select(); return } catch {}
    try { $el.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern).Toggle(); return } catch {}
    $el.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
  }
  # "Submit" / "Continue" (2.32 adds a hidden " ?" glyph), or an older UI's
  # "Next"; never 2.32's "Next question", which only turns the page.
  function Find-Submit {
    $c = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)
    foreach ($b in $win.FindAll($scope, $c)) {
      $name = [string]$b.Current.Name
      if ($name -match '^(?i)(submit|continue|next)\b' -and $name -notmatch '^(?i)next question$' -and $b.Current.IsEnabled) { return $b }
    }
    return $null
  }
  function Find-Button($name) {
    $c = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)
    foreach ($b in $win.FindAll($scope, $c)) { if ([string]$b.Current.Name -eq $name) { return $b } }
    return $null
  }
  # The page a choice belongs to: its id is "ask-opt-<page>-<n>".
  function Page-Of($choice) { if ([string]$choice.Current.AutomationId -match '^(ask-opt-.+)-[^-]+$') { return $Matches[1] } return '' }
  function Nudge-Choices { $anchor = Find-Button 'Cancel questionnaire'; if ($anchor) { Nudge-Tree $anchor } }
  # Antigravity 2.32 shows several questions one page at a time ("1 / 3",
  # Previous / Next question). Choosing an option of a single-choice question
  # turns the page by itself; the last page has the Submit button.
  $paged = [bool](Find-Button 'Next question')
  $norm = { param($t) (([string]$t) -replace '^\d+\s+', '' -replace '\s+', ' ').Trim() }
  $index = 0
  $page = ''
  $total = @($request.answers).Count
  foreach ($answer in $request.answers) {
    $choices = @()
    for ($i = 0; $i -lt 20 -and -not $choices.Count; $i++) {
      if ($i) { Start-Sleep -Milliseconds 200 }
      Nudge-Choices
      $choices = @(Choices)
      # Paged: wait until the page has turned (the previous one can linger).
      if ($paged -and $page) { $choices = @($choices | Where-Object { (Page-Of $_) -and (Page-Of $_) -ne $page }) }
    }
    if (-not $choices.Count) { Out-Result $false 'no_question' @{ question = $index } }
    if ($paged) { $here = Page-Of $choices[0]; $choices = @($choices | Where-Object { (Page-Of $_) -eq $here }) }
    foreach ($label in @($answer.labels)) {
      $want = & $norm $label
      $hit = $choices | Where-Object { (& $norm $_.Current.Name) -eq $want } | Select-Object -First 1
      if (-not $hit) { Out-Result $false 'option_not_found' @{ question = $index; label = $label } }
      Pick $hit
    }
    if ($answer.other) {
      $other = $choices | Where-Object { $_.Current.Name -match '(?i)^\d+\s+other' } | Select-Object -First 1
      if (-not $other) { Out-Result $false 'option_not_found' @{ question = $index; label = 'Other' } }
      Pick $other; Start-Sleep -Milliseconds 200
      $ec = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Edit)
      $edit = $null; foreach ($e in $win.FindAll($scope, $ec)) { if ([string]$e.Current.Name -match '(?i)^other') { $edit = $e; break } }
      if (-not $edit) { Out-Result $false 'other_not_taken' }
      try { $edit.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue([string]$answer.other) } catch { Out-Result $false 'other_not_taken' }
      Start-Sleep -Milliseconds 200
      $got = try { $edit.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value } catch { '' }
      if ((& $norm $got) -ne (& $norm $answer.other)) { Out-Result $false 'other_not_taken' }
    }
    Start-Sleep -Milliseconds 200
    if ($paged -and $index -lt $total - 1) {
      # Not the last page: it turns by itself after a single choice; after a
      # multiple choice or a written answer, turn it with Next question.
      $page = $here
      $turned = $false
      for ($i = 0; $i -lt 8 -and -not $turned; $i++) {
        Nudge-Choices
        $turned = [bool](@(Choices) | Where-Object { (Page-Of $_) -and (Page-Of $_) -ne $page } | Select-Object -First 1)
        if (-not $turned) { Start-Sleep -Milliseconds 150 }
      }
      if (-not $turned) {
        $next = Find-Button 'Next question'
        if (-not $next -or -not $next.Current.IsEnabled) { Out-Result $false 'submit_unavailable' @{ question = $index } }
        $next.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
      }
      $index++
      continue
    }
    $submit = $null
    for ($i = 0; $i -lt 15 -and -not $submit; $i++) { Nudge-Choices; $submit = Find-Submit; if (-not $submit) { Start-Sleep -Milliseconds 150 } }
    if (-not $submit) { Out-Result $false 'submit_unavailable' @{ question = $index } }
    $submit.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
    Start-Sleep -Milliseconds 600
    $index++
  }
  Out-Result $true 'answered' @{ questions = $index; left = @(Choices).Count }
}

if ($Mode -eq 'queue') {
  $qItems = @(Read-QueuedItems)
  Out-Result $true 'queue' @{
    queued = ($qItems.Count -gt 0 -or (Has-QueuedMessages))
    queuedItems = $qItems
    backgroundTask = (Has-BackgroundTask)
    observedAt = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
  }
}

if ($Mode -in @('steer', 'cancel_queued')) {
  $targetText = if ($TextFile -and (Test-Path $TextFile)) { [System.IO.File]::ReadAllText($TextFile, [System.Text.Encoding]::UTF8) } else { '' }
  $actionKind = if ($Mode -eq 'steer') { 'steer' } else { 'delete' }
  $res = Invoke-QueuedAction $targetText $actionKind
  Out-Result $res.ok $res.reason @{
    queuedItems = $res.queuedItems
    matchedText = $res.matchedText
    observedAt = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
  }
}

if ($Mode -eq 'stop') {
  $c = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)
  $buttons = @($win.FindAll($scope, $c) | Where-Object { $_.Current.IsEnabled })
  # ask_question replaces the composer and its generation Cancel button.
  # Cancel only this conversation's questionnaire; "Stop execution" in the
  # sidebar belongs to a separate task and must never match this path.
  $question = $buttons | Where-Object { $_.Current.Name -match '^(?i)cancel questionnaire$' } | Select-Object -First 1
  if ($question) {
    $question.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
    Start-Sleep -Milliseconds 600
    $buttons = @($win.FindAll($scope, $c) | Where-Object { $_.Current.IsEnabled })
  }
  # A reply being written: "Cancel (Ctrl+D)" ends the turn.
  foreach ($b in $buttons) {
    if ($b.Current.Name -match '^(?i)(stop|cancel)( generation| response)?( \(ctrl\+\w\))?$') {
      $b.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke(); Out-Result $true 'stopped'
    }
  }
  # Commands left running in the background ("1 task running"): each has "Stop Task".
  $tasks = @($buttons | Where-Object { $_.Current.Name -match '^(?i)stop task$' })
  foreach ($b in $tasks) { $b.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke(); Start-Sleep -Milliseconds 200 }
  if ($tasks.Count) { Out-Result $true 'stopped' @{ tasks = $tasks.Count } }
  if ($question) { Out-Result $true 'stopped' @{ questionCancelled = $true } }
  Out-Result $false 'no_stop_button'
}

$images = @()
if ($ImageFiles) {
  foreach ($part in ($ImageFiles -split '\|')) {
    $trimmed = $part.Trim()
    if ($trimmed) {
      if (-not (Test-Path -LiteralPath $trimmed)) { Out-Result $false 'image_missing' }
      $images += $trimmed
    }
  }
}
$text = if ($TextFile -and (Test-Path $TextFile)) { [System.IO.File]::ReadAllText($TextFile, [System.Text.Encoding]::UTF8) } else { '' }
$hasText = -not [string]::IsNullOrWhiteSpace($text)
if (-not $hasText -and $images.Count -eq 0) { Out-Result $false 'empty_message' }
if (Box-Text $box) { Out-Result $false 'draft_in_box' }
$norm = { param($t) ($t -replace "`r", '' -replace '\s+', ' ').Trim() }
# The new user message appears in the window before the SQLite checkpoint.
# Count exact matching text nodes before pasting; an older identical message
# cannot acknowledge this send. The editor must also clear after invocation.
function Matching-MessageCount {
  $condition = New-Object System.Windows.Automation.PropertyCondition($ae::ControlTypeProperty, [System.Windows.Automation.ControlType]::Text)
  $count = 0
  foreach ($element in $win.FindAll($scope, $condition)) {
    if ((& $norm ([string]$element.Current.Name)) -eq (& $norm $text)) { $count++ }
  }
  return $count
}
$beforeMatches = if ($hasText) { Matching-MessageCount } else { 0 }
$beforeQueuedCount = @(Read-QueuedItems).Count
if ($images.Count -gt 0) {
  $imgOutcome = Paste-Images $box $images
  if ($imgOutcome -ne 'ok') { Out-Result $false $imgOutcome @{ focusIssue = $script:focusIssue } }
}
if ($hasText) {
  if (-not (Is-TargetOpen)) { Out-Result $false 'conversation_not_opened' }
  if (-not (Paste-Into $box $text)) { Out-Result $false 'needs_foreground' @{ focusIssue = $script:focusIssue } }
  # The pasted text can take a moment to show in the tree (2.32); look again before giving up.
  $taken = $false
  for ($try = 0; $try -lt 6 -and -not $taken; $try++) {
    if ($try) { Start-Sleep -Milliseconds 200; Nudge-Tree $box }
    $taken = (& $norm (Box-Text $box)) -eq (& $norm $text)
  }
  if (-not $taken) { Clear-Box $box; Out-Result $false 'text_not_taken' }
}
if ($Mode -eq 'check') {
  $send = $null
  $checkTries = if ($images.Count -gt 0) { 10 } else { 1 }
  for ($i = 0; $i -lt $checkTries; $i++) {
    $send = Find-SendButton $box
    if ($send -and $send.Current.IsEnabled) { break }
    if ($i -lt $checkTries - 1) { Start-Sleep -Milliseconds 150 }
  }
  $enabled = [bool]($send -and $send.Current.IsEnabled)
  if ($hasText) { Clear-Box $box; Start-Sleep -Milliseconds 200 }
  Out-Result $true 'checked' @{ sendEnabled = $enabled; imageCount = $images.Count; clearedTo = (Box-Text $box) }
}
$send = $null
$sendTries = if ($images.Count -gt 0) { 20 } else { 10 }
$woke = $false
for ($i = 0; $i -lt $sendTries; $i++) {
  $send = Find-SendButton $box
  if ($send -and $send.Current.IsEnabled) { break }
  # Found but still disabled halfway through: the editor may have missed the paste.
  if ($hasText -and -not $woke -and $send -and $i -ge [int]($sendTries / 2)) {
    $woke = $true
    Wake-Editor $box
    if ((& $norm (Box-Text $box)) -ne (& $norm $text)) { Clear-Box $box; Out-Result $false 'text_not_taken' }
  }
  Start-Sleep -Milliseconds 150
}
if (-not $send -or -not $send.Current.IsEnabled) {
  $diag = Send-Diagnostics $box $send
  if ($hasText) { Clear-Box $box; Out-Result $false 'send_unavailable' @{ sendDiag = $diag } }
  Out-Result $false 'image_paste_failed' @{ sendDiag = $diag }
}
if (-not (Is-TargetOpen)) { Out-Result $false 'conversation_not_opened' }
$invoke = $send.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
$script:sendAttempted = $true
Write-ProgressState 'clicking' @{}
$invoke.Invoke()
Write-ProgressState 'clicked' @{}
for ($i = 0; $i -lt 15; $i++) {
  Start-Sleep -Milliseconds 200
  if (-not (Is-TargetOpen)) { break }
  $currentBox = Find-MessageBox
  $confirmed = $false
  if ($hasText) {
    $curQueued = @(Read-QueuedItems)
    $confirmed = [bool]($currentBox -and -not (Box-Text $currentBox) -and ((Matching-MessageCount) -gt $beforeMatches -or $curQueued.Count -gt $beforeQueuedCount))
  } else {
    $sendNow = Find-SendButton $currentBox
    $confirmed = [bool]($currentBox -and -not (Box-Text $currentBox) -and (-not $sendNow -or -not $sendNow.Current.IsEnabled -or (Has-QueuedMessages)))
  }
  if ($confirmed) {
    $qItems = @(Read-QueuedItems)
    $normSent = if ($hasText) { Normalize-QueuedText $text } else { '' }
    $sentInQueue = $false
    if ($normSent) {
      foreach ($qi in $qItems) {
        $nqi = Normalize-QueuedText $qi
        if ($nqi -eq $normSent -or $nqi.StartsWith($normSent, [System.StringComparison]::OrdinalIgnoreCase) -or $normSent.StartsWith($nqi, [System.StringComparison]::OrdinalIgnoreCase)) {
          $sentInQueue = $true; break
        }
      }
    }
    $queuedNow = if ($hasText) {
      ($qItems.Count -gt $beforeQueuedCount -or $sentInQueue)
    } else {
      ($qItems.Count -gt $beforeQueuedCount -or ($beforeQueuedCount -eq 0 -and (Has-QueuedMessages)))
    }
    $steered = $false
    if ($SteerNow -and $queuedNow) {
      $steerRes = Invoke-QueuedAction $text 'steer'
      if ($steerRes.ok) {
        $steered = $true
        $qItems = @($steerRes.queuedItems)
        $queuedNow = $false
      }
    }
    $receipt = @{
      receiptSource = 'window'
      confirmedAt = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
      queuedInWindow = $queuedNow
      queuedItems = $qItems
      steered = $steered
      backgroundTask = (Has-BackgroundTask)
    }
    Write-ProgressState 'confirmed' $receipt
    Out-Result $true 'confirmed' $receipt
  }
}
Out-Result $true 'clicked' @{ mayHaveSent = $true }
