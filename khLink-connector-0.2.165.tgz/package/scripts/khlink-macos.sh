#!/bin/bash
# khLink connector for macOS: install, log in, run as a LaunchAgent.
#
#   ./khlink-macos.sh install   copy the connector package this script is in into
#                               ~/Library/Application Support/khLink/connector/app
#                               and install its Node dependencies
#   ./khlink-macos.sh login     log this Mac in to a khLink account (browser)
#   ./khlink-macos.sh start     run the connector now and at every login
#   ./khlink-macos.sh stop      stop it and remove it from login items
#   ./khlink-macos.sh status    show whether it is running and its last log lines
#   ./khlink-macos.sh uninstall stop it and delete the program (keeps account data)
#
# The connector stores its secrets sealed with a key in the login Keychain, so
# login and the connector itself run in the user's GUI session (a LaunchAgent),
# also when this script is started over SSH.
set -euo pipefail

LABEL=com.khlink.connector
LOGIN_LABEL=com.khlink.login
BASE="$HOME/Library/Application Support/khLink/connector"
APP="$BASE/app"
LOGS="$BASE/logs"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
DOMAIN="gui/$(id -u)"
HERE="$(cd "$(dirname "$0")" && pwd)"

die() { echo "khLink: $*" >&2; exit 1; }

# bootout returns before the job is gone; bootstrapping right after fails
# with "5: Input/output error".
unload() {
  launchctl bootout "$DOMAIN/$1" 2>/dev/null || return 0
  local i; for i in $(seq 1 30); do launchctl print "$DOMAIN/$1" >/dev/null 2>&1 || return 0; sleep 0.5; done
}
load() {
  local i; for i in 1 2 3 4 5; do launchctl bootstrap "$DOMAIN" "$1" 2>/dev/null && return 0; sleep 1; done
  launchctl bootstrap "$DOMAIN" "$1"
}

find_node() {
  local candidates=() n
  command -v node >/dev/null 2>&1 && candidates+=("$(command -v node)")
  for n in /opt/homebrew/bin/node /usr/local/bin/node "$HOME"/.local/node-*/bin/node "$HOME"/.nvm/versions/node/*/bin/node "$HOME"/.volta/bin/node; do
    [ -x "$n" ] && candidates+=("$n")
  done
  for n in "${candidates[@]}"; do
    local major; major="$("$n" -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)"
    if [ "$major" -ge 22 ]; then echo "$n"; return 0; fi
  done
  return 1
}

agent_path() {
  # Where agent CLIs are usually installed; a LaunchAgent gets only /usr/bin:/bin.
  local node_dir; node_dir="$(dirname "$1")"
  local npm_prefix; npm_prefix="$("$node_dir/npm" prefix -g 2>/dev/null || true)"
  local p="$node_dir"
  for d in "$HOME/.local/bin" "$HOME/.claude/local" "$HOME/.local/npm/bin" "$HOME/.npm-global/bin" "${npm_prefix:+$npm_prefix/bin}" /opt/homebrew/bin /usr/local/bin /usr/bin /bin /usr/sbin /sbin; do
    [ -n "$d" ] && [ -d "$d" ] && case ":$p:" in *":$d:"*) ;; *) p="$p:$d" ;; esac
  done
  echo "$p"
}

write_plist() { # label, plist path, keepalive(true/false), args...
  local label="$1" file="$2" keep="$3"; shift 3
  local node; node="$(find_node)" || die "需要 Node.js 22 或更新版本"
  local args="" a
  for a in "$node" "$@"; do args="$args<string>$(printf '%s' "$a" | sed 's/&/\&amp;/g; s/</\&lt;/g')</string>"; done
  mkdir -p "$(dirname "$file")" "$LOGS"
  cat > "$file" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$label</string>
  <key>ProgramArguments</key><array>$args</array>
  <key>WorkingDirectory</key><string>$APP</string>
  <key>EnvironmentVariables</key><dict><key>PATH</key><string>$(agent_path "$node")</string><key>NODE_NO_WARNINGS</key><string>1</string></dict>
  <key>RunAtLoad</key><true/>
  $( [ "$keep" = true ] && echo '<key>KeepAlive</key><true/><key>ThrottleInterval</key><integer>20</integer><key>ProcessType</key><string>Interactive</string>' )
  <key>StandardOutPath</key><string>$LOGS/$label.log</string>
  <key>StandardErrorPath</key><string>$LOGS/$label.log</string>
</dict></plist>
EOF
}

cmd_install() {
  local src="${1:-$(dirname "$HERE")}"
  [ -f "$src/package.json" ] && [ -d "$src/src" ] || die "找不到连接器程序：$src"
  local node; node="$(find_node)" || die "需要 Node.js 22 或更新版本（https://nodejs.org）"
  mkdir -p "$APP"
  rm -rf "$APP/src" "$APP/scripts"
  (cd "$src" && tar cf - package.json src scripts $( [ -d native ] && echo native ) $( [ -d dsh-bridge ] && echo dsh-bridge )) | (cd "$APP" && tar xf -)
  (cd "$APP" && PATH="$(dirname "$node"):$PATH" npm install --omit=dev --no-audit --no-fund >/dev/null)
  echo "已安装 khLink 连接器 $(cd "$APP" && "$node" -p 'require("./package.json").version') 到 $APP"
}

cmd_login() {
  [ -f "$APP/src/cli.js" ] || die "请先运行 install"
  local file="$BASE/$LOGIN_LABEL.plist" log="$LOGS/$LOGIN_LABEL.log"
  write_plist "$LOGIN_LABEL" "$file" false src/cli.js login "$@"
  rm -f "$log"; : > "$log"
  unload "$LOGIN_LABEL"
  load "$file"
  # Follow the login until it ends.
  tail -n +1 -f "$log" &
  local tailer=$!
  while launchctl print "$DOMAIN/$LOGIN_LABEL" 2>/dev/null | grep -q 'state = running'; do sleep 1; done
  sleep 1; kill "$tailer" 2>/dev/null || true
  launchctl bootout "$DOMAIN/$LOGIN_LABEL" 2>/dev/null || true
  rm -f "$file"
  grep -q '连接器已配置' "$log" || die "登录没有完成"
  if launchctl print "$DOMAIN/$LABEL" >/dev/null 2>&1; then launchctl kickstart -k "$DOMAIN/$LABEL"; echo "已重启连接器"; fi
}

cmd_start() {
  [ -f "$APP/src/cli.js" ] || die "请先运行 install"
  [ -f "$HOME/Library/Application Support/FengzhuAgentBridge/config.json" ] || die "请先运行 login"
  write_plist "$LABEL" "$PLIST" true src/cli.js start
  unload "$LABEL"
  load "$PLIST"
  echo "khLink 连接器已启动，并会在登录 Mac 时自动运行"
}

cmd_stop() {
  if launchctl print "$DOMAIN/$LABEL" >/dev/null 2>&1; then unload "$LABEL"; echo "已停止 khLink 连接器"; else echo "khLink 连接器没有在运行"; fi
  rm -f "$PLIST"
}

cmd_status() {
  if launchctl print "$DOMAIN/$LABEL" 2>/dev/null | grep -E 'state = |pid = ' | head -2; then :; else echo "未运行"; fi
  local log; log="$(ls -t "$HOME/Library/Application Support/FengzhuAgentBridge/logs"/connector-*.log 2>/dev/null | head -1 || true)"
  [ -n "$log" ] && tail -n 8 "$log"
}

cmd_uninstall() { cmd_stop; rm -rf "$APP"; echo "已删除程序；账号数据保留在 ~/Library/Application Support/FengzhuAgentBridge"; }

case "${1:-}" in
  install) shift; cmd_install "$@" ;;
  login) shift; cmd_login "$@" ;;
  start) cmd_start ;;
  stop) cmd_stop ;;
  restart) cmd_start ;;
  status) cmd_status ;;
  uninstall) cmd_uninstall ;;
  *) sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//'; exit 1 ;;
esac
