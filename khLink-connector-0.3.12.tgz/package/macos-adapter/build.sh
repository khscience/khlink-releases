#!/bin/bash
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
OUT_DIR="${1:-$HOME/Library/Application Support/khLink}"
APP_DIR="$OUT_DIR/khLinkHelper.app"
BIN="$APP_DIR/Contents/MacOS/khLinkHelper"
SIGN_ID="${KHLINK_MACOS_SIGN_IDENTITY:--}"

mkdir -p "$APP_DIR/Contents/MacOS" "$APP_DIR/Contents/Resources"
cp "$HERE/Info.plist" "$APP_DIR/Contents/Info.plist"

echo "Compiling khLinkHelper ($(uname -m))..."
swiftc -O \
  -framework Foundation \
  -framework AppKit \
  -framework ApplicationServices \
  -framework CoreGraphics \
  -framework IOKit \
  -framework Carbon \
  "$HERE/Sources/main.swift" \
  -o "$BIN.tmp"

mv -f "$BIN.tmp" "$BIN"
chmod 755 "$BIN"

codesign --force --sign "$SIGN_ID" --identifier "vip.fengzhu.khlink.helper" "$APP_DIR"
echo "Installed: $APP_DIR"
codesign -dv --verbose=2 "$APP_DIR" 2>&1 | grep -E 'Identifier=|Signature=|CDHash=' || true
