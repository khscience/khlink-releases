﻿# Open the official Claude notification icon's context menu on the interactive
# Windows desktop. Left-click opens the quick composer. No pointer movement.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
Add-Type @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class ClaudeUsageTray {
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hwnd);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("user32.dll")] public static extern IntPtr GetShellWindow();
    [DllImport("user32.dll")] static extern IntPtr OpenInputDesktop(uint flags, bool inherit, uint access);
    [DllImport("user32.dll")] static extern bool CloseDesktop(IntPtr desktop);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern bool GetUserObjectInformation(IntPtr obj, int index, StringBuilder name, int length, out int needed);
    public static bool Interactive() {
        IntPtr desktop = OpenInputDesktop(0, false, 1);
        if (desktop == IntPtr.Zero) return false;
        try {
            var name = new StringBuilder(128); int needed;
            return GetUserObjectInformation(desktop, 2, name, name.Capacity * 2, out needed) && name.ToString() == "Default";
        } finally { CloseDesktop(desktop); }
    }
    public static uint Owner(IntPtr hwnd) {
        uint pid; GetWindowThreadProcessId(hwnd, out pid); return pid;
    }
    [StructLayout(LayoutKind.Sequential)] struct Mouse { public int x,y; public uint data,flags,time; public UIntPtr extra; }
    [StructLayout(LayoutKind.Sequential)] struct Key { public ushort vk,scan; public uint flags,time; public UIntPtr extra; }
    [StructLayout(LayoutKind.Explicit)] struct Payload { [FieldOffset(0)] public Key key; [FieldOffset(0)] public Mouse mouse; }
    [StructLayout(LayoutKind.Sequential)] struct Input { public uint type; public Payload data; }
    [DllImport("user32.dll")] static extern uint SendInput(uint count, Input[] inputs, int size);
    public static bool OpenContextMenu() {
        Input down = new Input(); down.type = 1; down.data.key.vk = 0x5d; down.data.key.flags = 1;
        Input up = down; up.data.key.flags |= 2;
        return SendInput(2, new Input[]{down, up}, Marshal.SizeOf(typeof(Input))) == 2;
    }
    [StructLayout(LayoutKind.Sequential)] struct GuiThread {
        public uint size,flags; public IntPtr active,focus,capture,menuOwner,moveSize,caret; public int left,top,right,bottom;
    }
    [DllImport("user32.dll")] static extern bool GetGUIThreadInfo(uint threadId, ref GuiThread info);
    [DllImport("user32.dll")] static extern bool PostMessage(IntPtr hwnd, uint msg, IntPtr w, IntPtr l);
    public static IntPtr MenuOwner() {
        var info = new GuiThread(); info.size = (uint)Marshal.SizeOf(typeof(GuiThread));
        return GetGUIThreadInfo(0, ref info) ? info.menuOwner : IntPtr.Zero;
    }
    public static void DismissMenu(IntPtr owner) {
        if (owner != IntPtr.Zero && MenuOwner() == owner) PostMessage(owner, 0x001f, IntPtr.Zero, IntPtr.Zero);
    }
}
'@
$ui = [System.Windows.Automation.AutomationElement]
$scope = [System.Windows.Automation.TreeScope]
$condition = [System.Windows.Automation.PropertyCondition]
$invoke = [System.Windows.Automation.InvokePattern]::Pattern
function ShellWindow($class) {
    $node = $ui::RootElement.FindFirst($scope::Children, $condition::new($ui::ClassNameProperty, $class))
    if ($node -and $node.Current.ProcessId -eq $shellPid -and !$node.Current.IsOffscreen) { $node }
}
function VisibleButtons($window) {
    if ($window) {
        $window.FindAll($scope::Descendants, $condition::new($ui::ClassNameProperty, 'SystemTray.NormalButton')) |
            Where-Object { !$_.Current.IsOffscreen -and $_.Current.ControlType -eq [System.Windows.Automation.ControlType]::Button }
    }
}
function ClaudeIcons($window) {
    VisibleButtons $window | Where-Object { $_.Current.Name.Trim() -ceq 'Claude' }
}
if (![ClaudeUsageTray]::Interactive() -or [ClaudeUsageTray]::MenuOwner() -ne [IntPtr]::Zero) { exit 1 }
$shellPid = [ClaudeUsageTray]::Owner([ClaudeUsageTray]::GetShellWindow())
$previous = [ClaudeUsageTray]::GetForegroundWindow()
$expanded = $false
$focused = $false
try {
    $tray = ShellWindow 'Shell_TrayWnd'
    if (!$tray) { throw 'Notification area unavailable' }
    $icons = @(ClaudeIcons $tray)
    if (!$icons.Count) {
        if (!(ShellWindow 'TopLevelWindowForOverflowXamlIsland')) {
            $expand = @(VisibleButtons $tray | Where-Object {
                $_.Current.AutomationId -eq 'SystemTrayIcon' -and $_.Current.Name -in 'Show hidden icons','显示隐藏的图标'
            })
            if ($expand.Count -ne 1) { throw 'Hidden icons control unavailable' }
            $expand[0].GetCurrentPattern($invoke).Invoke()
            $expanded = $true
        }
        for ($i = 0; $i -lt 12 -and !$icons.Count; $i++) {
            Start-Sleep -Milliseconds 100
            $icons = @(ClaudeIcons (ShellWindow 'TopLevelWindowForOverflowXamlIsland'))
        }
    }
    if ($icons.Count -ne 1) { throw 'Claude tray icon unavailable' }
    $icon = $icons[0]
    $icon.SetFocus()
    $focused = $true
    Start-Sleep -Milliseconds 140
    if (![ClaudeUsageTray]::Interactive() -or [ClaudeUsageTray]::Owner([ClaudeUsageTray]::GetForegroundWindow()) -ne $shellPid -or
        ![System.Windows.Automation.Automation]::Compare($ui::FocusedElement, $icon)) { throw 'Icon lost focus' }
    if (![ClaudeUsageTray]::OpenContextMenu()) { throw 'Menu unavailable' }
    Start-Sleep -Milliseconds 420
    $menu = [ClaudeUsageTray]::MenuOwner()
    if ($menu -ne [IntPtr]::Zero) {
        $owner = Get-Process -Id ([ClaudeUsageTray]::Owner($menu)) -ErrorAction SilentlyContinue
        if ($owner.ProcessName -eq 'Claude') { [ClaudeUsageTray]::DismissMenu($menu) }
    }
} finally {
    if ($expanded -and (ShellWindow 'TopLevelWindowForOverflowXamlIsland')) { $expand[0].GetCurrentPattern($invoke).Invoke() }
    if (($expanded -or $focused) -and $previous -ne [IntPtr]::Zero -and
        [ClaudeUsageTray]::Owner([ClaudeUsageTray]::GetForegroundWindow()) -eq $shellPid) {
        [void][ClaudeUsageTray]::SetForegroundWindow($previous)
    }
}
