const path = require('node:path');
const { execFile } = require('node:child_process');
const { setTimeout: delay } = require('node:timers/promises');
const desktopSources = new Set(['official-desktop-cached-response', 'official-desktop-history', 'desktop_sample']);

function openClaudeTrayMenu() {
  const file = path.join(__dirname, '../../scripts/claude-tray-usage.ps1');
  return new Promise(resolve => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-STA', '-ExecutionPolicy', 'Bypass', '-File', file],
      { windowsHide: true, timeout: 6500 }, error => resolve(!error));
  });
}

// The context menu only asks Claude Desktop to sample. Even when the percentages
// don't change, each window must acquire its own new desktop observation.
async function refreshFromTray({ open, read, before, startedAt, sleep = delay }) {
  if (before.accountState === 'switching') return 'account_unconfirmed';
  if (!await open()) return 'desktop_tray_unavailable';
  for (const pause of [400, 1200, 2400, 3500]) {
    await sleep(pause);
    const state = read(pause === 400 || pause === 3500);
    if (state.accountState === 'switching' || (before.accountFingerprint && state.accountFingerprint !== before.accountFingerprint)) return 'account_unconfirmed';
    if (state.accountFingerprint && ['fiveHour', 'sevenDay'].every(key => {
      const row = state[key];
      return row?.remainingPercent != null && row.observedAt >= startedAt && row.observedAt > (before[key]?.observedAt || 0) &&
        desktopSources.has(row.source);
    })) return null;
  }
  return 'desktop_no_new_observation';
}

module.exports = { openClaudeTrayMenu, refreshFromTray };
