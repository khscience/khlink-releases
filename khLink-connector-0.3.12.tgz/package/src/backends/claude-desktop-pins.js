const path = require('node:path');

const UNKNOWN_PIN_ORDER = 10_000;
const script = path.join(__dirname, '../../scripts/claude-desktop-pins.ps1');
const titleKey = title => String(title || '').replace(/\s+/g, ' ').trim();

function readPinLabels(execFile) {
  if (process.platform !== 'win32') return null;
  return new Promise(resolve => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script],
      { windowsHide: true, encoding: 'utf8', timeout: 4_000 }, (error, stdout) => {
        try { resolve(error ? null : JSON.parse(stdout)); } catch { resolve(null); }
      });
  });
}

function sidebarPinOrder(labels, sessions, complete) {
  if (!Array.isArray(labels) || !labels.every(label => typeof label === 'string')) return null;
  const rows = sessions.filter(s => !s.archived && titleKey(s.title)).map(session => ({ session, title: titleKey(session.title) }));
  const ordered = new Set();
  for (const raw of labels) {
    const name = titleKey(raw);
    // Electron appends status / parent information to some button names.
    // Include non-starred child sessions in matching so their rows are never
    // mistaken for a pinned parent with a shorter title.
    const exact = rows.filter(row => name === row.title);
    const matches = exact.length ? exact : rows.filter(row => name.startsWith(row.title + ' '));
    if (!complete && !matches.length) return null; // a temporarily unreadable row could be a pin
    if (!matches.some(row => row.session.pinned)) continue;
    if (matches.length !== 1) return null;
    const id = matches[0].session.desktopId;
    if (ordered.has(id)) return null;
    ordered.add(id);
  }
  return ordered.size === sessions.filter(s => s.pinned && !s.archived).length ? [...ordered] : null;
}

class ClaudeSidebarPins {
  constructor(readLabels) { this.readLabels = readLabels; }

  async apply(sessions, previousThreads, source, complete, now = Date.now()) {
    const pins = sessions.filter(s => s.pinned && !s.archived);
    if (!pins.length) { if (complete) this.probe = null; return; }
    const hasDiskRank = s => Number.isInteger(s.pinOrder) && s.pinOrder >= 0 && s.pinOrder < UNKNOWN_PIN_ORDER;
    if (pins.every(hasDiskRank)) {
      this.probe = null;
      for (const s of pins) s.pinOrderSource = source;
      return;
    }

    // A slow or hidden window must not launch a process at every sync tick.
    const key = JSON.stringify([source, pins.map(s => s.desktopId).sort()]);
    if (this.probe?.key !== key || now >= this.probe.nextRead || now < this.probe.at) {
      const labels = await this.readLabels();
      const order = sidebarPinOrder(labels, sessions, complete);
      this.probe = { key, at: now, nextRead: now + 30_000, order };
    }
    const live = this.probe?.key === key ? this.probe.order : null;
    const rank = new Map();
    if (live) {
      live.forEach((id, i) => rank.set(id, i));
    } else {
      // These ranks are already saved in claude-threads.json. They survive a
      // connector restart or a collapsed sidebar and belong to just this account.
      for (const row of previousThreads.values()) {
        if (row.pinned && row.pinOrderSource === source && hasDiskRank(row)) rank.set(row.desktopId, row.pinOrder);
      }
    }
    pins.sort((a, b) => (rank.get(a.desktopId) ?? Infinity) - (rank.get(b.desktopId) ?? Infinity)
      || a.pinOrder - b.pinOrder || titleKey(a.title).localeCompare(titleKey(b.title), undefined, { numeric: true })
      || a.desktopId.localeCompare(b.desktopId));
    let nextRank = 0;
    for (const value of rank.values()) nextRank = Math.max(nextRank, value + 1);
    pins.forEach(s => {
      if (rank.has(s.desktopId) || hasDiskRank(s)) s.pinOrderSource = source;
      s.pinOrder = rank.get(s.desktopId) ?? nextRank++;
    });
  }
}

module.exports = { ClaudeSidebarPins, readPinLabels, sidebarPinOrder, UNKNOWN_PIN_ORDER };
