'use strict';

// Hourly totals of what phones fetched from this computer, written to the
// connector log.
//
// The relay counts these replies as `ws.file.result`. On 2026-11-19 that was
// 444 MB for one account (222 MB up, 222 MB down, 388 replies), more than any
// other kind, and neither the relay nor the connector could say which files or
// which phone. Each report names the biggest files and conversation details,
// the phone that asked, how many times each was started from the beginning
// (a second start means the phone fetched the same thing again), and the
// one-byte freshness checks separately.

const path = require('node:path');

class FileReadStats {
  constructor(log, options = {}) {
    this.log = log;
    this.now = options.now || Date.now;
    this.intervalMs = options.intervalMs ?? 3_600_000;
    this.reset();
  }

  reset() {
    this.since = this.now(); this.targets = new Map(); this.kinds = new Map(); this.requests = 0; this.checks = 0;
  }

  /**
   * One successful reply. `action` is file.read or file.historyDetailPart;
   * `args` the phone's request; `bytes` what the reply carried.
   */
  add(action, args = {}, result = {}, bytes = 0, device = null) {
    const detail = action === 'file.historyDetailPart';
    const offset = Number(detail ? args.offset : result.offset ?? args.offset) || 0;
    const size = Number(args.size) || 0;
    if (!detail && size === 1) { this.checks += 1; this.tick(); return; }
    const name = detail ? `detail ${String(args.threadId || '').slice(0, 16)}/${String(args.id || '').slice(0, 24)}`
      : path.basename(String(result.path || args.path || '')) || 'file';
    const key = `${action}\0${detail ? `${args.threadId}/${args.id}` : String(result.path || args.path || '')}\0${device || ''}`;
    const entry = this.targets.get(key) || { name, device: device ? String(device).slice(0, 8) : '-', bytes: 0, requests: 0, starts: 0, total: 0 };
    entry.bytes += bytes; entry.requests += 1;
    if (offset === 0) entry.starts += 1;
    const total = Number(result.total);
    if (Number.isFinite(total) && total > entry.total) entry.total = total;
    this.targets.set(key, entry);
    const kind = this.kinds.get(action) || { bytes: 0, requests: 0 };
    kind.bytes += bytes; kind.requests += 1; this.kinds.set(action, kind);
    this.requests += 1;
    this.tick();
  }

  tick() { if (this.now() - this.since >= this.intervalMs) this.report(); }

  report() {
    if (this.requests || this.checks) {
      const total = [...this.kinds.values()].reduce((sum, kind) => sum + kind.bytes, 0);
      const kinds = [...this.kinds].sort((a, b) => b[1].bytes - a[1].bytes)
        .map(([name, kind]) => `${name.replace(/^file\./, '')} ${mb(kind.bytes)} (${kind.requests})`).join(', ');
      const top = [...this.targets.values()].sort((a, b) => b.bytes - a.bytes).slice(0, 5)
        .map((t) => `${t.name} ${mb(t.bytes)}${t.total ? ` of ${mb(t.total)}` : ''} x${t.starts} by ${t.device}`).join(', ');
      const repeated = [...this.targets.values()].filter((t) => t.starts > 1).length;
      this.log(`[fengzhu-connect] phone file reads since ${new Date(this.since).toISOString()}: sent ${mb(total)} in ${this.requests} requests [${kinds || 'none'}]; ${this.checks} freshness checks; ${repeated} fetched more than once; top ${top || 'none'}`);
    }
    this.reset();
  }
}

/** Bytes a file.read or file.historyDetailPart reply carries. */
function replyBytes(result) {
  if (!result || typeof result !== 'object') return 0;
  for (const value of Object.getOwnPropertySymbols(result).map((key) => result[key])) if (Buffer.isBuffer(value)) return value.length;
  for (const value of Object.values(result)) if (Buffer.isBuffer(value)) return value.length;
  if (typeof result.data === 'string') return Math.floor(result.data.length * 3 / 4);
  if (typeof result.chunk === 'string') return result.chunk.length;
  return 0;
}

function mb(bytes) { return `${(bytes / 1048576).toFixed(2)} MB`; }

module.exports = { FileReadStats, replyBytes };
