'use strict';
// Light mode (轻量模式): the phone turns it on to keep the relay small. Tool
// activity (commands, tool input and output, file changes, screenshots and
// images) then goes up as a placeholder of the same id, order and type, so the
// phone still shows "执行了 N 项操作" with its counts; the full encrypted row
// stays here, and the phone fetches it on request (history.details) and keeps
// it. Thinking, replies, cards and statuses are unchanged.
const fs = require('node:fs');
const path = require('node:path');

const LIGHT_TYPES = new Set(['commandExecution', 'fileChange', 'mcpToolCall', 'webSearch', 'imageView', 'imageGeneration', 'collabAgentToolCall', 'toolImages']);
const KEEP_DAYS = 90;

class LightMode {
  constructor(home) {
    this.file = path.join(home, 'light-mode.json');
    this.dir = path.join(home, 'light-details');
    try { const saved = JSON.parse(fs.readFileSync(this.file, 'utf8')); this.on = saved.enabled === true; this.at = Number(saved.changedAt) || 0; } catch { this.on = false; this.at = 0; }
  }

  enabled() { return this.on; }
  changedAt() { return this.at; }

  // The newest change wins: with several phones on one account, an older
  // choice arriving late does not undo a newer one. False when ignored.
  set(enabled, changedAt = Date.now()) {
    if (changedAt < this.at) return false;
    this.on = enabled === true; this.at = changedAt;
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    fs.writeFileSync(this.file, JSON.stringify({ enabled: this.on, changedAt: this.at }) + '\n');
    return true;
  }

  // The placeholder for a tool row, or null when the row goes up whole.
  placeholder(value) {
    if (!this.on || !value || !LIGHT_TYPES.has(value.type)) return null;
    return { type: value.type, text: '', light: true,
      ...(value.tool ? { tool: value.tool } : {}), ...(value.status ? { status: value.status } : {}), ...(value.createdAt ? { createdAt: value.createdAt } : {}) };
  }

  threadFile(threadId) { return path.join(this.dir, `${String(threadId).replace(/[^\w.-]/g, '_')}.jsonl`); }

  // Keep the full encrypted row ({id, nonce, ciphertext}) for history.details.
  save(threadId, row) {
    fs.mkdirSync(this.dir, { recursive: true });
    fs.appendFileSync(this.threadFile(threadId), JSON.stringify({ id: row.id, nonce: row.nonce, ciphertext: row.ciphertext }) + '\n');
  }

  details(threadId, ids) {
    const wanted = new Set(ids); const found = new Map();
    let text = ''; try { text = fs.readFileSync(this.threadFile(threadId), 'utf8'); } catch { return []; }
    for (const line of text.split('\n')) {
      if (!line) continue;
      try { const row = JSON.parse(line); if (wanted.has(row.id)) found.set(row.id, row); } catch { /* a partly written last line */ }
    }
    return [...found.values()];
  }

  // Details of conversations quiet for KEEP_DAYS go (the phone keeps what it fetched).
  prune(now = Date.now()) {
    let names = []; try { names = fs.readdirSync(this.dir); } catch { return; }
    for (const name of names) {
      const file = path.join(this.dir, name);
      try { if (now - fs.statSync(file).mtimeMs > KEEP_DAYS * 86_400_000) fs.rmSync(file, { force: true }); } catch { /* gone already */ }
    }
  }
}

module.exports = { LightMode, LIGHT_TYPES };
