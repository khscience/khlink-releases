﻿# Pure checks shared by the window driver and its regression tests.
function Plain([string]$value) { ($value -replace '[\u200B-\u200D\u2060\u2063\uFEFF]', '').Trim() }

function Get-CodexQueueButtonNames { @('Queue', '加入队列', '排队') }
function Get-CodexSteerButtonNames { @('Steer', '引导', '调整方向') }

function Get-CodexComposerIndex([string[]]$names) {
  $mainNames = @('和 Codex 一起工作', '可向 Codex 询问任何问题', 'Ask Codex anything', 'Work with Codex', 'Message Codex', '描述你的任务以生成计划…', 'Describe your task to generate a plan...', 'Describe your task to generate a plan…')
  $preferred = @(); $other = @()
  for ($i = 0; $i -lt $names.Count; $i++) {
    $name = $names[$i].Trim()
    if ($mainNames -contains $name) { $preferred += $i; continue }
    if ($name -like '*自行撰写回复*' -or $name -like '*自行填写*' -or $name -like '*write your own answer*' -or $name -like '*type your own answer*') { continue }
    $other += $i
  }
  if ($preferred.Count -eq 1) { return $preferred[0] }
  if ($preferred.Count -gt 1) { return -1 }
  if ($other.Count -eq 1) { return $other[0] }
  return -1
}

function Test-CodexQueueSendDialog([string[]]$names) {
  ($names -contains '发送消息？') -and
    [bool]($names | Where-Object { $_ -like '*要清除之前已排队*消息*' } | Select-Object -First 1) -and
    ($names -contains '清空队列') -and ($names -contains '发送消息')
}

function Test-CodexQueuePaused([string[]]$names) {
  [bool]($names | Where-Object { $_ -like '*中断了当前响应*队列已暂停*' -or $_ -like '*queue*paused*interrupted*' } | Select-Object -First 1)
}

function Test-CodexQueueRow([string[]]$names, [string]$firstLine) {
  $expected = Plain $firstLine
  if (-not $expected) { return $false }
  foreach ($name in $names) {
    $candidate = Plain (($name -split "\r?\n")[0])
    if ($candidate -eq $expected -or $candidate.EndsWith(": $expected") -or $candidate.EndsWith("：$expected")) { return $true }
  }
  return $false
}

function Test-CodexComposerEmpty([bool]$readable, [string]$value, [string]$name) {
  if (-not $readable) { return $false }
  $value = Plain $value
  return (-not $value) -or ($value -eq (Plain $name))
}
