'use strict';
// Light mode (轻量模式): the phone turns it on to keep the relay small. Tool
// activity (commands, tool input and output, file changes, screenshots and
// images) then goes up as a placeholder of the same id, order and type, so the
// phone still shows "执行了 N 项操作" with its counts; the full encrypted row
// stays here, and the phone fetches it on request (history.details) and keeps
// it. Thinking, replies, cards and statuses are unchanged.
const fs = require('node:fs');
const path = require('node:path');

const LIGHT_TYPES = new Set(['commandExecution', 'fileChange', 'mcpToolCall', 'webSearch', 'imageView', 'imageGeneration', 'collabAgentToolCall', 'toolImages']);
const KEEP_DAYS = 90;
const READ_CHUNK = 256 * 1024;
const MAX_DETAIL_LINE = 64 * 1024 * 1024;
const DETAIL_SCAN_TIMEOUT_MS = 30_000;
const MAX_RECENT_DETAILS = 4096;

// Only trust the in-memory duplicate cache while the file still has the
// identity and metadata observed after our last append. A removed, replaced,
// truncated or externally modified detail file must be written again.
function detailFileSignature(stat) {
  if (!stat?.isFile?.() || !Number.isFinite(stat.ino) || !stat.ino || !Number.isFinite(stat.size)) return null;
  return [stat.dev, stat.ino, stat.birthtimeMs, stat.mtimeMs, stat.ctimeMs, stat.size].join(':');
}

class LightMode {
  constructor(home, { io = fs.promises, now = Date.now, scanTimeoutMs = DETAIL_SCAN_TIMEOUT_MS, maxRecentDetails = MAX_RECENT_DETAILS } = {}) {
    this.file = path.join(home, 'light-mode.json');
    this.dir = path.join(home, 'light-details');
    this.io = io;
    this.now = now;
    this.scanTimeoutMs = scanTimeoutMs;
    this.writes = new Map();
    this.directoryReady = null;
    this.recentDetails = new Map();
    this.detailFiles = new Map();
    this.maxRecentDetails = Math.max(0, Math.min(MAX_RECENT_DETAILS, Number(maxRecentDetails) || 0));
    try { const saved = JSON.parse(fs.readFileSync(this.file, 'utf8')); this.on = saved.enabled === true; this.at = Number(saved.changedAt) || 0; } catch { this.on = false; this.at = 0; }
  }

  enabled() { return this.on; }
  changedAt() { return this.at; }

  // The newest change wins: with several phones on one account, an older
  // choice arriving late does not undo a newer one. False when ignored.
  set(enabled, changedAt = Date.now()) {
    if (changedAt < this.at) return false;
    this.on = enabled === true; this.at = changedAt;
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    fs.writeFileSync(this.file, JSON.stringify({ enabled: this.on, changedAt: this.at }) + '\n');
    return true;
  }

  // The placeholder for a tool row, or null when the row goes up whole.
  placeholder(value) {
    if (!this.on || !value || !LIGHT_TYPES.has(value.type)) return null;
    return { type: value.type, text: '', light: true,
      ...(value.tool ? { tool: value.tool } : {}), ...(value.status ? { status: value.status } : {}), ...(value.createdAt ? { createdAt: value.createdAt } : {}) };
  }

  threadFile(threadId) { return path.join(this.dir, `${String(threadId).replace(/[^\w.-]/g, '_')}.jsonl`); }

  forgetRecentDetails(file) {
    this.detailFiles.delete(file);
    for (const [key, entry] of this.recentDetails) if (entry.file === file) this.recentDetails.delete(key);
  }

  // Keep the full encrypted row ({id, nonce, ciphertext}) for history.details.
  save(threadId, row, contentHash = null) {
    const file = this.threadFile(threadId);
    const line = JSON.stringify({ id: row.id, nonce: row.nonce, ciphertext: row.ciphertext }) + '\n';
    // Serialize per file so updates to the same id remain in order. Different
    // threads can write concurrently without blocking heartbeats or RPCs.
    const previous = this.writes.get(file) || Promise.resolve();
    const write = previous.catch(() => {}).then(async () => {
      if (!this.directoryReady) {
        this.directoryReady = this.io.mkdir(this.dir, { recursive: true }).catch((error) => {
          this.directoryReady = null;
          throw error;
        });
      }
      await this.directoryReady;
      const key = JSON.stringify([file, row.id]);
      const expected = this.detailFiles.get(file);
      if (expected) {
        let observed = null;
        try { observed = detailFileSignature(await this.io.stat(file)); } catch { /* replaced or removed */ }
        if (!observed || observed !== expected) this.forgetRecentDetails(file);
      }
      const cached = contentHash && this.detailFiles.has(file) ? this.recentDetails.get(key) : null;
      if (cached?.hash === contentHash) {
        this.recentDetails.delete(key);
        this.recentDetails.set(key, cached);
        return;
      }
      try { await this.io.appendFile(file, line); }
      catch (error) {
        this.forgetRecentDetails(file);
        if (error.code === 'ENOENT') this.directoryReady = null;
        throw error;
      }
      // Without a digest the caller may have written a newer version of any
      // row, so conservatively forget the file's cached contents.
      if (!contentHash || !this.maxRecentDetails) { this.forgetRecentDetails(file); return; }
      let signature = null;
      try { signature = detailFileSignature(await this.io.stat(file)); } catch { /* a later write will retry */ }
      if (!signature) { this.forgetRecentDetails(file); return; }
      this.detailFiles.set(file, signature);
      this.recentDetails.delete(key);
      this.recentDetails.set(key, { file, hash: contentHash });
      while (this.recentDetails.size > this.maxRecentDetails) {
        const oldest = this.recentDetails.keys().next().value;
        const evicted = this.recentDetails.get(oldest);
        this.recentDetails.delete(oldest);
        // Entries for a file may only be used together with its signature.
        // Dropping all of them avoids trusting stale entries if that file is
        // replaced while its signature is absent.
        if (evicted) this.forgetRecentDetails(evicted.file);
      }
    });
    this.writes.set(file, write);
    const forget = () => { if (this.writes.get(file) === write) this.writes.delete(file); };
    write.then(forget, forget);
    return write;
  }

  async details(threadId, ids) {
    const wanted = new Set(ids); const found = new Map();
    if (!wanted.size) return [];
    const file = this.threadFile(threadId);
    // A placeholder is not published until its write completes, but wait for
    // any same-thread update already in progress before taking the snapshot.
    const pending = this.writes.get(file);
    if (pending) await pending.catch(() => {});
    let handle;
    try { handle = await this.io.open(file, 'r'); }
    catch (error) { if (error.code === 'ENOENT') return []; throw error; }
    try {
      let position = (await handle.stat()).size;
      let fragments = []; let fragmentSize = 0;
      const deadline = this.now() + this.scanTimeoutMs;
      const consume = (head) => {
        const total = fragmentSize + head.length;
        if (total > MAX_DETAIL_LINE) throw new Error('历史详情中的单条记录过大，无法安全读取');
        if (total) {
          const line = Buffer.concat([head, ...fragments.reverse()], total).toString('utf8').replace(/\r$/, '');
          try {
            const row = JSON.parse(line);
            if (wanted.has(row.id) && !found.has(row.id)) found.set(row.id, row);
          } catch { /* a partly written or malformed line */ }
        }
        fragments = []; fragmentSize = 0;
      };
      // Read backwards: the last copy of an id wins, and recent items don't
      // require loading an old multi-gigabyte JSONL file into memory.
      while (position > 0 && found.size < wanted.size) {
        if (this.now() >= deadline) throw new Error('历史详情文件较大，查找超时；请分批取回或稍后重试');
        const size = Math.min(READ_CHUNK, position);
        const start = position - size;
        const buffer = Buffer.allocUnsafe(size);
        const { bytesRead } = await handle.read(buffer, 0, size, start);
        if (bytesRead !== size) throw new Error('历史详情读取中断，请重试');
        let end = bytesRead;
        for (let i = bytesRead - 1; i >= 0; i--) {
          if (buffer[i] !== 10) continue;
          consume(buffer.subarray(i + 1, end));
          end = i;
          if (found.size === wanted.size) break;
        }
        if (found.size === wanted.size) break;
        if (end) { fragments.push(buffer.subarray(0, end)); fragmentSize += end; }
        if (fragmentSize > MAX_DETAIL_LINE) throw new Error('历史详情中的单条记录过大，无法安全读取');
        position = start;
      }
      if (position === 0 && fragments.length && found.size < wanted.size) consume(Buffer.alloc(0));
      return [...found.values()];
    } finally {
      await handle.close();
    }
  }

  // Details of conversations quiet for KEEP_DAYS go (the phone keeps what it fetched).
  prune(now = Date.now()) {
    let names = []; try { names = fs.readdirSync(this.dir); } catch { return; }
    for (const name of names) {
      const file = path.join(this.dir, name);
      try {
        if (now - fs.statSync(file).mtimeMs > KEEP_DAYS * 86_400_000) {
          this.forgetRecentDetails(file);
          fs.rmSync(file, { force: true });
        }
      } catch { /* gone already */ }
    }
  }
}

module.exports = { LightMode, LIGHT_TYPES };
