const fs = require('node:fs/promises');

// Diagnostic snapshots change every second. Keep only the newest pending
// snapshot and perform disk IO outside the event loop, including Windows'
// rename/copy fallback. One writer also prevents older writes winning races.
class LatestFileWriter {
  constructor(target, { io = fs, onError = () => {} } = {}) {
    this.target = target; this.io = io; this.onError = onError;
    this.pending = null; this.running = null;
  }

  write(text) {
    this.pending = text;
    if (!this.running) this.running = this.drain().finally(() => { this.running = null; });
    return this.running;
  }

  async drain() {
    const temporary = `${this.target}.${process.pid}.tmp`;
    while (this.pending !== null) {
      const text = this.pending; this.pending = null;
      try {
        await this.io.writeFile(temporary, text, { mode: 0o600 });
        try { await this.io.rename(temporary, this.target); }
        catch (error) {
          if (!['EPERM', 'EACCES', 'EBUSY'].includes(error.code)) throw error;
          await this.io.copyFile(temporary, this.target);
        }
      } catch (error) { this.onError(error); }
      finally { await this.io.rm(temporary, { force: true }).catch(() => {}); }
    }
  }
}

module.exports = { LatestFileWriter };
