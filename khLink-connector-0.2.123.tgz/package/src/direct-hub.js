const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const crypto = require('node:crypto');
const { RTCPeerConnection } = require('werift');
const { protect } = require('./config');
const { encryptJson, decryptJson, blobFields } = require('./crypto');
const { encodeQr, decodeQr, verifyAnswer, FramedChannel, STUN_URL } = require('./direct-protocol');
const { DirectSignaling } = require('./direct-signaling');

class DirectHub {
  constructor(connector, options = {}) {
    this.connector = connector; this.options = options; this.session = null;
    this.generation = 0;
    this.controlSecret = crypto.randomBytes(32).toString('base64url');
    this.controlFile = path.join(path.dirname(connector.config.configFile), 'direct-control.json');
  }
  get connected() { return this.session?.authenticated === true && this.session.channel?.readyState === 'open'; }
  status() {
    const session = this.session;
    return { mode: this.connector.config.directOnly ? 'direct' : 'server', connected: this.connected,
      id: session?.id, status: session?.status || 'idle', expiresAt: session?.expiresAt,
      payload: session?.payload, phoneName: session?.name, stun: session?.stun, singleScan: Boolean(session?.signaling), error: session?.error };
  }
  async start() {
    this.server = http.createServer((req, res) => this.control(req, res));
    await new Promise((resolve, reject) => { this.server.once('error', reject); this.server.listen(0, '127.0.0.1', resolve); });
    const port = this.server.address().port;
    fs.writeFileSync(this.controlFile, JSON.stringify({ port, pid: process.pid, protected: protect(this.controlSecret) }));
    this.timer = setInterval(() => {
      const session = this.session;
      if (session && !session.authenticated && Date.now() > session.expiresAt) this.end('expired', '二维码已过期，请重新生成');
      if (this.connected) {
        if (Date.now() - (session.lastReceived || 0) > 30_000) { this.fail(session, new Error('手机直连心跳超时，请重新扫码')); return; }
        this.send('connector.presence', null, this.connector.presencePayload());
        if (this.connector.ws?.readyState !== 1) this.connector.republishActiveThreadStatuses();
      }
      this.connector.writeStatus(this.connector.isConnected());
    }, 1000);
    this.timer.unref();
  }
  async control(req, res) {
    res.setHeader('content-type', 'application/json; charset=utf-8');
    res.setHeader('cache-control', 'no-store');
    const token = String(req.headers.authorization || '').replace(/^Bearer /, '');
    const expected = Buffer.from(this.controlSecret); const actual = Buffer.from(token);
    if (actual.length !== expected.length || !crypto.timingSafeEqual(actual, expected) || req.headers.origin) {
      res.writeHead(403); res.end(JSON.stringify({ error: '本机控制认证失败' })); return;
    }
    try {
      let body = ''; for await (const chunk of req) { body += chunk; if (Buffer.byteLength(body) > 16000) throw new Error('请求过大'); }
      const args = body ? JSON.parse(body) : {};
      let value;
      if (req.method === 'GET' && req.url === '/status') value = this.status();
      else if (req.method === 'POST' && req.url === '/offer') value = await this.offer(args.stun !== false);
      else if (req.method === 'POST' && req.url === '/answer') value = await this.answer(args.payload);
      else if (req.method === 'POST' && req.url === '/cancel') { await this.end('idle'); value = this.status(); }
      else if (req.method === 'POST' && req.url === '/server') { await this.connector.setDirectMode(false); await this.end('idle'); value = this.status(); }
      else { res.writeHead(404); value = { error: '未知的控制请求' }; }
      res.end(JSON.stringify(value));
    } catch (error) { res.writeHead(400); res.end(JSON.stringify({ error: error.message })); }
  }
  async offer(stun) {
    if (this.creating) throw new Error('正在生成连接码，请稍候');
    this.creating = true;
    const generation = ++this.generation;
    try {
      // Preparing an offer must not take an existing account connection offline.
      // A scanned phone returns its authenticated answer automatically.
      await this.end('idle', undefined, false);
      if (generation !== this.generation) throw new Error('配对已取消');
      const peer = this.options.createPeer?.(stun) || new RTCPeerConnection({ iceServers: stun ? [{ urls: STUN_URL }] : [], iceUseIpv6: false, maxMessageSize: 16384 });
      const session = { id: crypto.randomUUID(), key: crypto.randomBytes(32).toString('base64'),
        expiresAt: Date.now() + 5 * 60_000, status: 'gathering', stun, peer, seen: new Set(), sequence: 0 };
      this.session = session;
      const channel = peer.createDataChannel('khlink-direct-v1', { ordered: true }); session.channel = channel;
      session.framed = new FramedChannel(channel, (raw) => this.receive(session, raw).catch((error) => this.fail(session, error)), (error) => this.fail(session, error));
      channel.stateChange.subscribe((state) => { if (state === 'closed' && this.session === session) this.fail(session, new Error('直连已断开，请重新扫码')); });
      peer.connectionStateChange.subscribe((state) => {
        const connection = peer.iceTransports?.[0]?.connection; const pair = connection?.nominated;
        console.log(`[fengzhu-connect] direct transport ${state}: receivedAgo=${session.lastReceived ? Date.now() - session.lastReceived : '-'}ms, consent=${connection?.consentFresh}, requests=${pair?.requestsSent}, responses=${pair?.responsesReceived}`);
        if (state === 'failed' && this.session === session) this.fail(session, new Error('网络不支持直连，请换用同一 Wi-Fi／热点或服务器模式'));
      });
      await peer.setLocalDescription(await peer.createOffer());
      if (this.session !== session) throw new Error('配对已取消');
      session.signaling = new DirectSignaling(session, (payload) => this.answer(payload), this.options.signaling);
      const signaling = await session.signaling.start(stun);
      if (this.session !== session) throw new Error('配对已取消');
      session.payload = encodeQr('offer', { v: 2, id: session.id, expiresAt: session.expiresAt,
        pcId: this.connector.config.deviceId, pcName: this.connector.config.deviceName, key: session.key,
        stun, signaling, sdp: peer.localDescription.sdp });
      session.status = 'waiting'; return this.status();
    } catch (error) { if (generation === this.generation) await this.end('failed', error.message); throw error; }
    finally { this.creating = false; }
  }
  async answer(payload) {
    const session = this.session;
    if (!session || session.status !== 'waiting' || Date.now() > session.expiresAt) throw new Error('电脑连接码已过期，请重新生成');
    const answer = decodeQr(payload, 'answer');
    if (answer.id !== session.id || !verifyAnswer(session.key, answer)) throw new Error('手机确认码与本次电脑连接码不匹配');
    session.status = 'connecting';
    try {
      await this.connector.setDirectMode(true);
      if (this.session !== session) throw new Error('配对已取消，请重新生成连接码');
      session.deviceId = answer.deviceId; session.name = answer.name;
      await session.peer.setRemoteDescription({ type: 'answer', sdp: answer.sdp });
    } catch (error) { if (this.session === session) this.fail(session, error); throw error; }
    return this.status();
  }
  async receive(session, raw) {
    if (this.session !== session || !session.deviceId) return;
    const frame = JSON.parse(raw);
    if (typeof frame.id !== 'string' || frame.id.length > 100 || !frame.kind || session.seen.has(frame.id)) return;
    if (session.seen.size >= 10000) { const oldest = session.seen.values().next().value; session.seen.delete(oldest); }
    const payload = decryptJson(session.key, frame); session.seen.add(frame.id);
    if (!session.authenticated) {
      if (Date.now() > session.expiresAt || frame.kind !== 'direct.hello' || payload.id !== session.id || payload.deviceId !== session.deviceId) throw new Error('直连配对认证失败');
      session.authenticated = true; session.status = 'connected'; session.payload = undefined; session.lastReceived = Date.now();
      this.send('direct.welcome', null, { pcId: this.connector.config.deviceId, pcName: this.connector.config.deviceName });
      await this.connector.onFrame(JSON.stringify({ type: 'ready' }), { direct: true });
      this.connector.pushCodexUsage(true).catch((e) => this.connector.log(e));
      this.connector.syncHistory().catch((e) => this.connector.log(e));
      return;
    }
    session.lastReceived = Date.now();
    if (frame.kind === 'direct.ping') { this.send('direct.pong', null, { sentAt: payload.sentAt }); return; }
    if (frame.kind === 'direct.request') {
      let result;
      try {
        if (payload.path === '/api/v2/account') result = { profile: { displayName: `${this.connector.config.deviceName} · 直连` },
          entitlements: [], effectiveEntitlement: { source: 'direct', canWrite: true }, devices: [
            { id: this.connector.config.deviceId, name: this.connector.config.deviceName, type: 'connector', revokedAt: null },
            { id: session.deviceId, name: session.name, type: 'android', revokedAt: null }] };
        else if (payload.path.startsWith('/api/v2/events?')) result = { items: [] };
        else result = await this.connector.directHistory.get(payload.path, session.key);
        this.send('direct.response', null, { requestId: payload.requestId, ok: true, result });
      } catch (error) { this.send('direct.response', null, { requestId: payload.requestId, ok: false, error: error.message }); }
      return;
    }
    if (!['command', 'command.control', 'file.command', 'approval.resolve'].includes(frame.kind)) return;
    // Bind the sender to the QR-confirmed device; never trust an incoming source id.
    await this.connector.onFrame(JSON.stringify({ ...frame, sourceDeviceId: session.deviceId, sequence: undefined }), { direct: true, key: session.key });
  }
  send(kind, threadId, value, targetDeviceId = null) {
    const session = this.session;
    if (!this.connected || (targetDeviceId && targetDeviceId !== session.deviceId)) return false;
    const id = crypto.randomUUID();
    return session.framed.send(JSON.stringify({ id, kind, threadId: threadId || null, sourceDeviceId: this.connector.config.deviceId,
      targetDeviceId: session.deviceId, createdAt: Date.now(), sequence: ++session.sequence, ...encryptJson(session.key, kind, threadId, id, value),
      ...blobFields(session.key, id, value) }),
      { priority: ['connector.presence', 'direct.welcome', 'direct.pong', 'command.result'].includes(kind) });
  }
  fail(session, error) { if (this.session === session) this.end('failed', error.message).catch((e) => this.connector.log(e)); }
  async end(status, error, invalidate = true) {
    if (invalidate) this.generation++;
    const session = this.session; this.session = null;
    if (session) { session.authenticated = false; session.signaling?.close(); await session.peer?.close().catch(() => {}); }
    if (status !== 'idle') this.session = { status, error, expiresAt: Infinity };
  }
  async close() {
    clearInterval(this.timer); await this.end('idle');
    if (this.server) await new Promise((resolve) => this.server.close(resolve));
    try { fs.unlinkSync(this.controlFile); } catch {}
  }
}
module.exports = { DirectHub };
