const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { spawn } = require('node:child_process');
const { WebSocketServer } = require('ws');
const { Event } = require('werift');

// Cross-network direct connections. Phones on mobile data sit behind a
// carrier NAT that gives every peer a new port, and home routers only accept
// replies from the exact port they sent to, so WebRTC cannot get through
// without a third party. Like khQuant's web workbench, the connector then
// opens a Cloudflare quick tunnel (no account, no khLink server): cloudflared
// dials out to Cloudflare and forwards one public https URL to a WebSocket on
// 127.0.0.1. Frames stay sealed with the pairing key end to end; the first
// frame on a connection must open with that key or the connection is closed.
const TUNNEL_URL = /https:\/\/([a-z0-9-]+)\.trycloudflare\.com/i;
const READY = /Registered tunnel connection/i;
const MAX_PENDING = 4;
const HELLO_TIMEOUT_MS = 15_000;

function findCloudflared(env = process.env) {
  const names = process.platform === 'win32' ? ['cloudflared.exe'] : ['cloudflared'];
  const roots = [
    env.KHLINK_CLOUDFLARED && path.dirname(env.KHLINK_CLOUDFLARED),
    // The combined installer puts it next to the connector.
    path.join(__dirname, '..', 'tools'),
    path.join(__dirname, '..', '..', 'tools'),
    ...String(env.PATH || '').split(path.delimiter),
    env['ProgramFiles(x86)'] && path.join(env['ProgramFiles(x86)'], 'cloudflared'),
    env.ProgramFiles && path.join(env.ProgramFiles, 'cloudflared'),
  ].filter(Boolean);
  if (env.KHLINK_CLOUDFLARED && fs.existsSync(env.KHLINK_CLOUDFLARED)) return env.KHLINK_CLOUDFLARED;
  for (const root of roots) for (const name of names) {
    const candidate = path.join(root, name);
    try { if (fs.statSync(candidate).isFile()) return candidate; } catch {}
  }
  return null;
}

/** A WebSocket dressed as the data channel FramedChannel expects. */
function socketChannel(socket) {
  const onMessage = new Event(); const stateChange = new Event();
  socket.on('message', (data) => onMessage.execute(data.toString()));
  socket.on('close', () => stateChange.execute('closed'));
  socket.on('error', () => {});
  return {
    get readyState() { return socket.readyState === 1 ? 'open' : socket.readyState === 0 ? 'connecting' : 'closed'; },
    get bufferedAmount() { return socket.bufferedAmount; },
    send: (raw) => socket.send(raw),
    close: () => { try { socket.close(); } catch {} },
    onMessage, stateChange, transport: 'tunnel',
  };
}

class DirectTunnel {
  constructor({ accept, log = () => {}, binary = findCloudflared(), spawnProcess = spawn } = {}) {
    this.accept = accept; this.log = log; this.binary = binary; this.spawnProcess = spawnProcess;
    this.host = null; this.server = null; this.child = null; this.pending = 0; this.starting = null;
  }
  get available() { return Boolean(this.binary); }
  get running() { return Boolean(this.host && this.child && this.child.exitCode === null); }

  /** Starts once and returns the quick tunnel's subdomain (xxx of xxx.trycloudflare.com). */
  async start(timeoutMs = 45_000) {
    if (this.running) return this.host;
    if (this.starting) return this.starting;
    if (!this.binary) throw new Error('缺少跨网络直连组件，请重新安装 khLink 桌面端');
    this.starting = this.open(timeoutMs).finally(() => { this.starting = null; });
    return this.starting;
  }

  async open(timeoutMs) {
    await this.listen();
    const port = this.server.address().port;
    const child = this.spawnProcess(this.binary, ['tunnel', '--no-autoupdate', '--url', `http://127.0.0.1:${port}`],
      { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    this.child = child;
    const host = await new Promise((resolve, reject) => {
      let found = null; let text = '';
      const timer = setTimeout(() => { finish(); reject(new Error('跨网络通道启动超时，请检查电脑网络后重试')); }, timeoutMs);
      const onData = (chunk) => {
        text = (text + chunk.toString()).slice(-8000);
        found = found || (text.match(TUNNEL_URL) || [])[1];
        if (found && READY.test(text)) { finish(); resolve(found.toLowerCase()); }
      };
      const onExit = (code) => { finish(); reject(new Error(`跨网络通道没有启动（${code}）`)); };
      const finish = () => { clearTimeout(timer); child.stdout?.off('data', onData); child.stderr?.off('data', onData); child.off('exit', onExit); };
      child.stdout?.on('data', onData); child.stderr?.on('data', onData); child.once('exit', onExit);
      child.once('error', (error) => { finish(); reject(new Error(`跨网络通道没有启动：${error.message}`)); });
    }).catch((error) => { this.stop(); throw error; });
    child.once('exit', () => { if (this.child === child) { this.log(`direct tunnel exited (${child.exitCode})`); this.host = null; this.child = null; } });
    // Drain the pipes so a chatty cloudflared never blocks on a full buffer.
    child.stdout?.resume(); child.stderr?.resume();
    this.host = host;
    console.log('[fengzhu-connect] direct tunnel ready');
    return host;
  }

  async listen() {
    if (this.server) return;
    this.wss = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024 });
    this.server = http.createServer((req, res) => { res.writeHead(404); res.end(); });
    this.server.on('upgrade', (req, socket, head) => {
      const match = /^\/khlink\/(resume|[a-f0-9-]{36})$/i.exec(String(req.url || '').split('?')[0]);
      if (!match || this.pending >= MAX_PENDING) { socket.destroy(); return; }
      this.wss.handleUpgrade(req, socket, head, (ws) => this.connection(ws, match[1].toLowerCase()));
    });
    await new Promise((resolve, reject) => { this.server.once('error', reject); this.server.listen(0, '127.0.0.1', resolve); });
  }

  connection(ws, target) {
    console.log(`[fengzhu-connect] direct tunnel connection (${target === 'resume' ? 'resume' : 'pairing'})`);
    this.pending++;
    let settled = false;
    const channel = socketChannel(ws);
    const settle = () => { if (!settled) { settled = true; this.pending--; clearTimeout(timer); } };
    const timer = setTimeout(() => { settle(); channel.close(); }, HELLO_TIMEOUT_MS);
    ws.once('close', settle);
    // The hub calls `authenticated` once the first frame opened with the key.
    try { this.accept(target, channel, { authenticated: settle, reject: () => { settle(); channel.close(); } }); }
    catch { settle(); channel.close(); }
  }

  stop() {
    const child = this.child; this.child = null; this.host = null;
    try { child?.kill(); } catch {}
    for (const client of this.wss?.clients || []) try { client.terminate(); } catch {}
    try { this.server?.close(); } catch {}
    this.server = null; this.wss = null; this.pending = 0;
  }
}

module.exports = { DirectTunnel, findCloudflared, socketChannel, TUNNEL_URL };
