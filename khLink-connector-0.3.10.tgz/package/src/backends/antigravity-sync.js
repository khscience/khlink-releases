// Mirrors Google Antigravity conversations to the phone: list, history and a
// coarse running state come from ~/.gemini/antigravity (see antigravity.js).
// Messages and Stop from the phone go through Antigravity's own window
// (scripts/antigravity-send.ps1: its sidebar link, message box and buttons),
// never its local server, debugging port or sign-in token. Approvals and
// anything else stay in the desktop app.
// Installed onto Connector.prototype by install().

const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFile } = require('node:child_process');
const { writeFileAtomic } = require('../atomic-file');
const { detectImageMime, isImageAttachment, MAX_IMAGE_BYTES } = require('../attachment-store');
const { publicAttachments, sanitizeUploadReferences } = require('../attachment-privacy');
const { encryptJson } = require('../crypto');
const { clip } = require('../history');
const { isPinAlreadyInPosition, pinReorderApplied, pinOrderMap } = require('../desktop-sidebar');
const ag = require('./antigravity');

const POLL_MS = 4_000;
const INDEX_VERSION = 7;
const ITEMS_VERSION = 3; // Aggregate update_steps into live per-turn task list cards.
// The conversation file is written as the agent works; quiet this long = idle.
const RUNNING_QUIET_MS = 90_000;
// After a finished reply or an error step the turn is over; this short quiet
// only covers the next step being written right after it.
const TURN_END_QUIET_MS = 25_000;
// A step left "in progress" (waiting for approval, a long command) counts as
// busy, but not for ever: the app may have been closed mid-step.
const OPEN_STEP_STALE_MS = 30 * 60_000;
// A send waits until the keyboard and mouse have been still this long, so the
// window does not jump in front of someone at the computer; after waiting
// MAX_IDLE_WAIT_MS it goes anyway.
const IDLE_BEFORE_SEND_S = 15;
const MAX_IDLE_WAIT_MS = 3 * 60_000;
const IDLE_RETRY_MS = 8_000;
const SEND_CONFIRM_MS = 15_000;
const WINDOW_QUEUE_CHECK_MS = 2_500;
const USAGE_STALE_MS = 30 * 60_000;
const USAGE_AUTO_RETRY_MS = 60_000;
const DESKTOP_QUEUED_REASON = '已进入反重力等待队列，当前任务完成后自动发送';
const SEND_UNCERTAIN = '已尝试发送，但还没有确认到新消息。请检查电脑上的对话；系统不会自动重发。';

// The relay takes at most 100 items per request; keep requests small too.
const UPLOAD_BATCH = 100;
const UPLOAD_BATCH_BYTES = 1_500_000;
// First sight of a conversation: only its most recent items (old ones are
// long tool logs nobody scrolls back to from a phone).
const FIRST_SYNC_ITEMS = 600;
const ANTIGRAVITY_ACTIONS_UNSUPPORTED = '这个操作请在电脑上的反重力里完成。';
const SEND_SCRIPT = path.join(__dirname, '..', '..', 'scripts', 'antigravity-send.ps1');
const SEND_ERRORS = {
  not_running: '电脑上的反重力没有打开。',
  row_control_unavailable: '电脑端反重力没有显示这个对话的管理按钮，请确认桌面窗口已打开。',
  title_edit_in_progress: '电脑上正在编辑这个对话的标题，请先结束编辑。',
  title_edit_unavailable: '未能在电脑端确认标题输入框，请检查反重力窗口。',
  conversation_not_in_sidebar: '在反重力的对话列表和历史记录里都没找到这个对话（可能已被删除），请在电脑上打开它一次。',
  conversation_not_opened: '电脑上的反重力未能切换到这个对话，已取消发送。',
  no_message_box: '反重力里没找到这个对话的输入框。',
  draft_in_box: '电脑上反重力的输入框里有还没发出的草稿，已取消，免得覆盖它。',
  needs_foreground: '要把文字填进反重力，需要它的窗口能切到前台（电脑可能锁屏了），已取消发送。',
  text_not_taken: '文字没能填进反重力的输入框，已取消发送。',
  image_missing: '手机上传的图片已不在电脑临时目录中，请重新选择后再发送。',
  image_needs_foreground: '要把图片粘贴进反重力，需要它的窗口能切到前台（电脑可能锁屏了），已取消发送。',
  image_paste_failed: '图片没能粘贴进反重力的输入框，已取消发送。',
  send_unavailable: '反重力的发送按钮当前不可用（可能还在运行），已取消。',
  no_stop_button: '反重力里没有找到停止按钮（可能已经停了）。',
  no_question: '反重力里没有正在等待回答的问题（可能已经在电脑上答过了）。',
  option_not_found: '反重力里没找到这个选项，请在电脑上回答。',
  other_not_taken: '自己写的答案没能填进反重力，已取消。',
  submit_unavailable: '反重力的提交按钮当前不可用，请在电脑上回答。',
  bad_answer: '回答内容不完整。',
  empty_message: '消息是空的。',
  no_settings: '反重力里没找到模型和权限的选择按钮。',
  model_list_changed: '电脑上的反重力模型菜单已变化，请重新打开模型设置。',
  bad_settings: '没有要切换的模型或权限。',
  model_not_set: '反重力没能切换到这个模型（可能当前不可用），请在电脑上选择。',
  level_not_set: '反重力没能切换到这个思考强度，请在电脑上选择。',
  permission_not_set: '反重力没能切换到这个权限模式，请在电脑上选择。',
  no_usage_entry: '反重力里没找到用量入口（请先打开任意对话）。',
  usage_unreadable: '没能从反重力窗口读到用量数据（电脑可能已锁屏，或菜单未展开）。',
  no_queue: '反重力里目前没有等待发送的消息。',
  queued_item_not_found: '反重力等待队列里没找到这条消息（可能已经发出或被删除）。',
  steer_button_not_found: '在反重力等待队列里没找到立即发送按钮，请在电脑上操作。',
  steer_invoke_failed: '没能触发反重力里的立即发送按钮，请在电脑上重试。',
  delete_button_not_found: '在反重力等待队列里没找到删除按钮，请在电脑上操作。',
  delete_invoke_failed: '没能触发反重力里的删除按钮，请在电脑上重试。',
  new_conversation_unavailable: '未能在电脑端反重力打开新建对话页面，请确认反重力窗口已打开。',
  project_not_found: '电脑端反重力里没有找到对应的项目，请先在反重力中添加该项目，或选择其他项目。',
  project_not_selected: '未能切换到指定的反重力项目，为避免发错工作区已取消发送。',
  new_conversation_unconfirmed: '已尝试在反重力中发送，但暂未确认新对话创建结果，请检查电脑端反重力。',
  not_pinned: '只有电脑端已置顶的反重力对话才能同步拖拽排序。',
  drag_failed: '未能在电脑端反重力侧边栏完成拖拽排序，请确认窗口可见且未锁屏。',
};

// Antigravity's permission presets (this conversation only), in its own order.
const PRESETS = [
  { value: 'Request Review', name: '逐条审批', description: '每条命令都要你批准' },
  { value: 'Default', name: '默认', description: '敏感操作前先问你' },
  { value: 'Auto', name: '自动', description: '由反重力判断命令能否直接执行' },
  { value: 'Turbo', name: '全自动', description: '所有命令直接执行，不做限制' },
];
const LEVEL_NAMES = { Minimal: '最低', Low: '低', Medium: '中', High: '高', 'Extra High': '超高', Max: '最高' };

/** Splits a selector label such as "Gemini 3.8 Flash High" into a listed model and its thinking level. */
function antigravityModelOf(models, label) {
  const text = String(label || '').trim();
  for (const model of models || []) {
    if (text === model.name) return { model: model.name, effort: model.level || '' };
    if (model.levels?.length && text.startsWith(`${model.name} `)) {
      const level = text.slice(model.name.length + 1);
      if (model.levels.includes(level)) return { model: model.name, effort: level };
    }
  }
  return { model: text, effort: '' };
}

/** The script's menus in the catalogue shape the phone already reads for DeepSeek and Hermes. */
function antigravityCatalog(read) {
  const models = (read.models || []).filter((model) => model.available !== false && model.name).map((model) => ({
    id: model.name,
    name: model.name,
    ...(model.levels?.length ? { reasoning: { efforts: model.levels.map((level) => ({ id: level, name: LEVEL_NAMES[level] || level })), defaultEffort: model.level || '' } } : {}),
  }));
  const current = antigravityModelOf(read.models, read.model);
  const listed = new Set((read.permissions || []).map((option) => option.name));
  const fallback = (read.permissions || []).find((option) => option.isDefault)?.name;
  return {
    catalog: models.length ? { groups: [{ id: 'antigravity', name: '反重力', models }], default: current.model ? { provider: 'antigravity', model: current.model } : null } : null,
    permissionCatalog: { options: PRESETS.filter((preset) => !listed.size || listed.has(preset.value)), ...(fallback ? { defaultPreset: fallback } : {}) },
    settings: { model: current.model ? `antigravity/${current.model}` : '', effort: current.effort, permissionMode: read.permission || '' },
  };
}

const methods = {
  startAntigravitySync() {
    if (this._antigravityTimer || !this.config?.configFile) return;
    const home = ag.antigravityHome();
    if (!fs.existsSync(path.join(home, 'conversations'))) return;
    this.antigravityHomeDir = home;
    this.antigravityStorageFile = ag.antigravityStorageFile();
    this.antigravityFile = path.join(path.dirname(this.config.configFile), 'antigravity-threads.json');
    this.antigravityUsageFile = path.join(path.dirname(this.config.configFile), 'antigravity-usage.json');
    this.antigravityCatalogFile = path.join(path.dirname(this.config.configFile), 'antigravity-catalog.json');
    this.antigravityUsageCache = this.readAntigravityUsage();
    this.antigravityCatalogCache = this.readAntigravityCatalogCache();
    this.antigravityThreads = this.readAntigravityThreads();
    this.recoverAntigravityDeliveries();
    // A question still waiting is read again, so its card reflects this version.
    for (const meta of this.antigravityThreads.values()) {
      meta.windowProbePending = false;
      if (meta.waiting) meta.mtimeMs = 0;
    }
    console.log(`[fengzhu-connect] antigravity sync on (${this.antigravityThreads.size} known)`);
    this._antigravityTimer = setInterval(() => this.pollAntigravity().catch((error) => this.log(error)), POLL_MS);
    this._antigravityTimer.unref?.();
    this.pollAntigravity().catch((error) => this.log(error));
  },

  readAntigravityThreads() {
    try { return new Map(Object.entries(JSON.parse(fs.readFileSync(this.antigravityFile, 'utf8')))); } catch { return new Map(); }
  },

  saveAntigravityThreads({ required = false } = {}) {
    try { writeFileAtomic(this.antigravityFile, JSON.stringify(Object.fromEntries(this.antigravityThreads))); }
    catch (error) { if (required) throw error; this.log(error); }
  },

  readAntigravityUsage() {
    if (!this.antigravityUsageFile) return null;
    try { return JSON.parse(fs.readFileSync(this.antigravityUsageFile, 'utf8')); } catch { return null; }
  },

  saveAntigravityUsage(value) {
    this.antigravityUsageCache = value;
    if (!this.antigravityUsageFile) return;
    try { writeFileAtomic(this.antigravityUsageFile, JSON.stringify(value)); } catch (error) { this.log(error); }
  },

  readAntigravityCatalogCache() {
    if (!this.antigravityCatalogFile) return null;
    try { return JSON.parse(fs.readFileSync(this.antigravityCatalogFile, 'utf8')); } catch { return null; }
  },

  saveAntigravityCatalogCache(value) {
    this.antigravityCatalogCache = value;
    if (!this.antigravityCatalogFile) return;
    try { writeFileAtomic(this.antigravityCatalogFile, JSON.stringify(value)); } catch (error) { this.log(error); }
  },

  antigravityProjectsList() {
    const projects = ag.readProjects(this.antigravityHomeDir);
    return { projects, allowStandalone: true, backend: 'antigravity' };
  },

  antigravityModelsListPayload() {
    const cached = this.antigravityCatalogCache || null;
    const rawModels = cached?.catalog?.groups?.[0]?.models || [];
    const models = rawModels.map((model) => ({
      id: `antigravity/${model.id}`,
      label: model.name || model.id,
      efforts: (model.reasoning?.efforts || []).map((effort) => ({ id: effort.id, name: effort.name || LEVEL_NAMES[effort.id] || effort.id })),
      defaultEffort: model.reasoning?.defaultEffort || '',
    }));
    const permissionCatalog = cached?.permissionCatalog || { options: PRESETS };
    return {
      models,
      catalog: cached?.catalog || null,
      permissionCatalog,
      cached: Boolean(models.length),
      backend: 'antigravity',
    };
  },

  findNewAntigravityConversationId(beforeIds, prompt, startedAt) {
    const home = this.antigravityHomeDir;
    if (!home) return '';
    const wanted = ag.normalizeSendText(prompt);
    const candidates = ag.listConversationIds(home).filter((cid) => !beforeIds.has(cid));
    let fallback = '';
    for (const cid of candidates) {
      const dbFile = path.join(home, 'conversations', `${cid}.db`);
      try {
        const conv = ag.readConversation(dbFile, -1, null);
        if (conv.isSubagent) continue;
        if (wanted && ag.normalizeSendText(conv.firstText) === wanted) return cid;
        if (!fallback && ((conv.createdAt && conv.createdAt >= startedAt - 15_000) || (conv.lastAt && conv.lastAt >= startedAt - 15_000))) {
          fallback = cid;
        }
      } catch { /* db may still be initializing */ }
    }
    return fallback;
  },

  formatAntigravityUsageState(raw, now = Date.now()) {
    const cached = raw || {};
    const observedAt = Number(cached.observedAt) || 0;
    const groups = (Array.isArray(cached.groups) ? cached.groups : []).map((group) => {
      const shapeWindow = (win) => {
        if (!win) return null;
        const winObservedAt = Number(win.observedAt) || observedAt || 0;
        const resetsAt = Number(win.resetsAt) > 0 ? Number(win.resetsAt) : null;
        const remaining = Number.isFinite(win.remainingPercent) ? Math.max(0, Math.min(100, Math.round(win.remainingPercent))) : null;
        const crossedReset = Boolean(resetsAt && winObservedAt && winObservedAt < resetsAt && now >= resetsAt);
        const stale = Boolean(winObservedAt && (now - winObservedAt > USAGE_STALE_MS || crossedReset));
        return {
          remainingPercent: stale ? null : remaining,
          lastKnownRemainingPercent: stale ? remaining : null,
          resetsAt: resetsAt && resetsAt > now ? resetsAt : null,
          observedAt: winObservedAt || null,
          stale,
        };
      };
      return {
        id: String(group.id || ''),
        name: String(group.name || group.id || ''),
        fiveHour: shapeWindow(group.fiveHour),
        sevenDay: shapeWindow(group.sevenDay),
      };
    }).filter((g) => g.id && (g.fiveHour || g.sevenDay));
    return {
      backend: 'antigravity',
      groups,
      plan: cached.plan || null,
      credits: Number.isFinite(cached.credits) ? cached.credits : null,
      observedAt: observedAt || null,
      updatedAt: observedAt || 0,
      refreshResultAt: Number(cached.refreshResultAt) || 0,
      refreshUnavailableReason: cached.refreshUnavailableReason || null,
    };
  },

  antigravityUsageState(now = Date.now()) {
    return this.formatAntigravityUsageState(this.antigravityUsageCache, now);
  },

  async refreshAntigravityUsage({ idleSeconds = 0 } = {}) {
    if (this._antigravityUsageRefresh) return this._antigravityUsageRefresh;
    const run = (async () => {
      const result = await this.runAntigravitySend('', 'usage', '', { idleSeconds })
        .catch(() => ({ ok: false, reason: 'automation_error' }));
      const now = Date.now();
      if (!result.ok) {
        console.log(`[fengzhu-connect] antigravity usage refresh failed: reason=${result.reason || 'unknown'} elapsed=${result.elapsedMs || 0}ms`);
        const reason = SEND_ERRORS[result.reason] || '暂时无法从反重力窗口读取剩余用量，请确认反重力已打开且电脑未锁屏。';
        const next = { ...(this.antigravityUsageCache || {}), refreshResultAt: now, refreshUnavailableReason: reason };
        this.saveAntigravityUsage(next);
        const state = this.formatAntigravityUsageState(next, now);
        this.emit('antigravity.usage', null, state);
        return state;
      }
      const parsed = ag.parseAntigravityUsage(result.lines, result.observedAt || now);
      if (!parsed) {
        console.log(`[fengzhu-connect] antigravity usage parse failed: source=${result.source || ''} lines=${JSON.stringify(result.lines || []).slice(0, 800)}`);
        const next = { ...(this.antigravityUsageCache || {}), refreshResultAt: now, refreshUnavailableReason: SEND_ERRORS.usage_unreadable };
        this.saveAntigravityUsage(next);
        const state = this.formatAntigravityUsageState(next, now);
        this.emit('antigravity.usage', null, state);
        return state;
      }
      console.log(`[fengzhu-connect] antigravity usage refreshed: source=${result.source || ''} groups=${parsed.groups.length} elapsed=${result.elapsedMs || 0}ms`);
      const next = {
        ...parsed,
        plan: parsed.plan ?? this.antigravityUsageCache?.plan ?? null,
        credits: parsed.credits ?? this.antigravityUsageCache?.credits ?? null,
        refreshResultAt: now,
        refreshUnavailableReason: null,
      };
      this.saveAntigravityUsage(next);
      const state = this.formatAntigravityUsageState(next, now);
      this.emit('antigravity.usage', null, state);
      return state;
    })();
    let wrapped;
    wrapped = run.finally(() => { if (this._antigravityUsageRefresh === wrapped) this._antigravityUsageRefresh = null; });
    this._antigravityUsageRefresh = wrapped;
    return wrapped;
  },

  antigravityMidRunRecoverableError(meta) {
    if (!meta) return false;
    // A failed tool call (invalid args / non-zero command / missing file) or a
    // retryable API error is handled by the agent in the next step; the turn is
    // still alive until it genuinely goes quiet or hits a terminal error.
    if (meta.lastType === ag.STEP_TOOL && ag.STATUS_FAILED.has(meta.lastStatus)) return true;
    if (meta.lastType === ag.STEP_ERROR && meta.lastErrorRetryable) return true;
    return false;
  },

  antigravityBackgroundRunning(meta) {
    if (!meta || meta.waiting || meta.running) return false;
    return Boolean(meta.notFullyIdle);
  },

  antigravityThreadStatus(meta) {
    if (meta.waiting) return 'desktop_waiting';
    if (meta.running) return 'desktop_running';
    if (this.antigravityBackgroundRunning(meta)) return 'desktop_background';
    if (this.antigravityStopped(meta) || ag.STATUS_STOPPED.has(meta.lastStatus)) return 'interrupted';
    return meta.lastType === ag.STEP_ERROR || ag.STATUS_FAILED.has(meta.lastStatus) ? 'failed' : 'completed';
  },

  antigravityStopped(meta) {
    return Boolean(meta.stoppedAt && meta.stoppedAt >= (meta.lastAt || 0) && meta.stoppedAt >= (meta.sentAt || 0));
  },

  antigravityRunning(meta, stat) {
    const now = Date.now(); const quiet = now - (meta.lastAt || stat.mtimeMs);
    if (this.antigravityStopped(meta)) return false;
    if (meta.waiting) return false;
    const window = meta.windowState;
    // Only a foreground observation is authoritative. An occluded Electron
    // window can retain its old Cancel button after the reply has finished.
    if (window?.foreground && window.at >= (meta.lastAt || 0) && window.at >= (meta.sentAt || 0) &&
      (!window.active || now - window.at < 10_000)) return window.active;
    // Sent from the phone and nothing written yet: the agent may be thinking.
    if (meta.sentAt && now - meta.sentAt < RUNNING_QUIET_MS && (meta.lastAt || stat.mtimeMs) < meta.sentAt &&
      (!Number.isInteger(meta.sentReceiptIdx) || meta.sentReceiptIdx > (meta.lastIdx ?? -1))) return true;
    if (ag.STATUS_STOPPED.has(meta.lastStatus)) return false;
    if ((ag.STATUS_FAILED.has(meta.lastStatus) || meta.lastType === ag.STEP_ERROR) && !this.antigravityMidRunRecoverableError(meta)) return false;
    if (ag.STATUS_ACTIVE.has(meta.lastStatus)) return quiet < OPEN_STEP_STALE_MS;
    // Stopped from the phone: whatever the last step is, the turn is over.
    const ended = meta.lastType === ag.STEP_MODEL;
    return quiet < (ended ? TURN_END_QUIET_MS : RUNNING_QUIET_MS);
  },

  // The turn went quiet and was taken as over (see antigravityRunning): an open
  // step left for OPEN_STEP_STALE_MS, or no step written for RUNNING_QUIET_MS
  // after a tool step. A stop, a terminal failure, a finished model reply and a
  // foreground window that says the turn is over are explicit ends, not silence.
  antigravityEndedBySilence(meta, stat) {
    if (this.antigravityRunning(meta, stat)) return false;
    if (this.antigravityStopped(meta) || meta.waiting) return false;
    const window = meta.windowState;
    if (window?.foreground && window.at >= (meta.lastAt || 0)) return false;
    if (ag.STATUS_STOPPED.has(meta.lastStatus)) return false;
    if ((ag.STATUS_FAILED.has(meta.lastStatus) || meta.lastType === ag.STEP_ERROR) && !this.antigravityMidRunRecoverableError(meta)) return false;
    if (meta.lastType === ag.STEP_MODEL && !ag.STATUS_ACTIVE.has(meta.lastStatus)) return false;
    return true;
  },

  antigravityIndexValue(id, meta) {
    const status = this.antigravityThreadStatus(meta);
    const pinned = Boolean(meta.pinned);
    const pinOrder = pinned && Number.isInteger(meta.pinOrder) && meta.pinOrder >= 0 ? meta.pinOrder : -1;
    return {
      id, title: meta.title || meta.firstText?.slice(0, 40) || '反重力对话', cwd: meta.cwd || '', status,
      note: meta.waiting?.summary || '', waiting: meta.waiting || null, model: meta.model || '',
      updatedAt: meta.updatedAt || Date.now(), activityAt: meta.lastAt || meta.createdAt || 0, backend: 'antigravity', archived: false, pinned, pinOrder,
      unread: !meta.running && !this.antigravityBackgroundRunning(meta) && (meta.lastAt || 0) > (meta.viewedAt || 0) + 1_000, origin: 'desktop',
    };
  },

  // The desktop sidebar's Antigravity pins in order, for the phone to
  // reconcile cached rows against. null until the first full scan finishes.
  antigravityPinSnapshot() {
    if (!this._antigravityPinsPublished || !this.antigravityThreads) return null;
    return [...this.antigravityThreads.entries()]
      .filter(([, meta]) => Boolean(meta?.pinned) && !meta?.deletedSynced)
      .sort(([idA, a], [idB, b]) => {
        const orderA = Number.isInteger(a.pinOrder) && a.pinOrder >= 0 ? a.pinOrder : Infinity;
        const orderB = Number.isInteger(b.pinOrder) && b.pinOrder >= 0 ? b.pinOrder : Infinity;
        if (orderA !== orderB) return orderA - orderB;
        const timeA = a.lastAt || a.updatedAt || 0;
        const timeB = b.lastAt || b.updatedAt || 0;
        return (timeB - timeA) || String(idA).localeCompare(String(idB));
      })
      .map(([id]) => id);
  },

  async uploadAntigravityIndex(id, meta, { archived = false, indexChanged = false } = {}) {
    const value = { ...this.antigravityIndexValue(id, meta), archived };
    const encrypted = encryptJson(this.config.accountKey, 'history.thread', id, id, value);
    // Keep the conversation's real activity time inside encrypted metadata,
    // while bumping the relay row timestamp on pin/archive changes so older
    // pinned or unpinned threads reach the phone's newest page.
    const indexUpdatedAt = indexChanged ? Date.now() : value.updatedAt;
    await this.api.request(this.api.path('/history/threads'), { method: 'PUT', body: { id, archived, updatedAt: indexUpdatedAt, ...encrypted } });
  },

  async uploadAntigravityItems(id, items) {
    const rows = await Promise.all(items.map(async (item) => {
      // Steps are ordered by index; a step's thinking comes before its reply.
      // Per-turn task list cards carry an explicit order advancing with each update_steps call.
      const order = ag.itemOrderOf(item);
      const createdAt = item.at || Date.now();
      const value = { ...item.value, ...clip(item.value.text || '', 32 * 1024) };
      return { id: item.id, order, createdAt, ...await this.historyItemFrame(id, item.id, value) };
    }));
    let batch = []; let bytes = 0;
    const flush = async () => {
      if (!batch.length) return;
      await this.api.request(this.api.path(`/history/threads/${encodeURIComponent(id)}/items`), { method: 'PUT', body: { items: batch } });
      batch = []; bytes = 0;
    };
    for (const row of rows) {
      const size = row.ciphertext.length + 200;
      if (batch.length >= UPLOAD_BATCH || (batch.length && bytes + size > UPLOAD_BATCH_BYTES)) await flush();
      batch.push(row); bytes += size;
    }
    await flush();
  },

  async pollAntigravity() {
    if (this._antigravityPolling || this.stopping || !this.config.accountKey) return;
    this._antigravityPolling = true;
    try {
      const dir = path.join(this.antigravityHomeDir, 'conversations');
      let changed = false;
      let allScanned = true;
      const pinOrderIds = ag.readPinnedOrder(this.antigravityStorageFile);
      const pinOrderMap = new Map(pinOrderIds.map((cid, index) => [cid, index]));
      const summaries = ag.readConversationSummaries(this.antigravityHomeDir);
      // Most recently active first, so the conversations that matter show up first.
      // Asynchronous: on a busy disk this listing once took 24 s and, done
      // synchronously, stalled the whole connector (2026-10-09 05:18).
      const listed = await fs.promises.readdir(dir);
      const names = (await Promise.all(listed.map(async (name) => {
        try { return [name, (await fs.promises.stat(path.join(dir, name))).mtimeMs]; } catch { return [name, 0]; }
      }))).sort((a, b) => b[1] - a[1]).map(([name]) => name);
      const hiddenSubagents = new Set();
      for (const name of names) {
        const match = name.match(/^([0-9a-f-]{36})\.db$/i); if (!match) continue;
        const id = match[1];
        const summary = summaries.get(id) || null;
        if (summary?.isSubagent) {
          hiddenSubagents.add(id);
          continue;
        }
        try { if (await this.syncAntigravityConversation(dir, name, id, pinOrderMap, summary, summaries.size > 0)) changed = true; }
        catch (error) { allScanned = false; this.log(new Error(`antigravity ${id}: ${error.message}`)); }
      }
      // A conversation deleted in Antigravity (or an internal subagent child
      // conversation hidden from the desktop sidebar) cannot stay visible or
      // keep announcing "running" on the phone. Archive it once on the relay.
      for (const [id, meta] of this.antigravityThreads) {
        const isHidden = !names.includes(`${id}.db`) || hiddenSubagents.has(id) || Boolean(meta.hiddenSubagent);
        if (!isHidden) { if (meta.deletedSynced) Object.assign(meta, { deletedSynced: false, indexVersion: 0 }); continue; }
        if (hiddenSubagents.has(id)) meta.hiddenSubagent = true;
        if (meta.running || meta.waiting || meta.notFullyIdle) {
          // A conversation deleted mid-turn or mid-background-task is not a live task: no reminder.
          Object.assign(meta, { running: false, waiting: null, notFullyIdle: false, summaryStatus: '', quietEnd: true });
          this.announceAntigravityStatus(id, meta); changed = true;
        }
        // The relay keeps the row as last uploaded, possibly "running" from
        // before the conversation was deleted (seen: a deleted conversation
        // shown running for 10 days). Archive it there once.
        if (!meta.deletedSynced) {
          try {
            Object.assign(meta, { pinned: false, pinOrder: -1 });
            await this.uploadAntigravityIndex(id, meta, { archived: true, indexChanged: true });
            meta.deletedSynced = true; changed = true;
          }
          catch (error) { allScanned = false; this.log(new Error(`antigravity ${id}: ${error.message}`)); }
        }
      }
      if (allScanned) this._antigravityPinsPublished = true;
      if (changed) { this.saveAntigravityThreads(); this.emit('threads.updated', null, { updatedAt: Date.now() }); }
      // A running turn or background task is re-announced every 15 s, as for the other agents.
      for (const [id, meta] of this.antigravityThreads) if ((meta.running || this.antigravityBackgroundRunning(meta)) && Date.now() - (meta.announcedAt || 0) > 15_000) this.announceAntigravityStatus(id, meta);
    } finally { this._antigravityPolling = false; }
    await this.drainAntigravityQueues();
  },

  // Reconcile Antigravity's native queued user steps (CortexStepStatus = 11)
  // with both phone-originated deliveries and desktop-originated queued items.
  syncAntigravityDesktopQueue(id, meta, dbFile, queuedSteps = [], items = []) {
    const queued = Array.isArray(queuedSteps) ? queuedSteps : [];
    const queuedByIdx = new Map(queued.map((step) => [step.idx, step]));
    const claimedIdxs = new Set();
    let changed = false;

    const matchesQueuedStep = (entry, step) => {
      if (entry.text) return ag.normalizeSendText(step.text) === ag.normalizeSendText(entry.text);
      return Boolean(entry.imagePaths?.length) && !ag.normalizeSendText(step.text) && Number(step.mediaCount) > 0;
    };
    const matchesHistoryItem = (entry, item) => {
      if (item.value.type !== 'userMessage' || Number(item.id.slice(3)) <= entry.afterIdx) return false;
      if (entry.text) return ag.normalizeSendText(item.value.text) === ag.normalizeSendText(entry.text);
      return Boolean(entry.imagePaths?.length) && !ag.normalizeSendText(item.value.text) && Array.isArray(item.value.images) && item.value.images.length > 0;
    };

    // 1. Reconcile phone deliveries waiting in Antigravity's native queue (or uncertain).
    for (const entry of meta.deliveries || []) {
      if (entry.state === 'desktop_queued' && entry.queuedAtDesktop) {
        let matched = Number.isInteger(entry.receiptIdx) ? queuedByIdx.get(entry.receiptIdx) : null;
        if (!matched && !Number.isInteger(entry.receiptIdx)) {
          const after = Number.isInteger(entry.afterIdx) ? entry.afterIdx : -1;
          matched = queued.find((step) => !claimedIdxs.has(step.idx) && step.idx > after && matchesQueuedStep(entry, step)) || null;
          if (matched) { entry.receiptIdx = matched.idx; changed = true; }
        }
        if (matched) {
          claimedIdxs.add(matched.idx);
          continue;
        }
        // Step left the queued state: check whether it started or was deleted/cancelled.
        let startedAt = null;
        let resolved = false;
        let cancelled = false;
        if (Number.isInteger(entry.receiptIdx)) {
          let statuses = new Map();
          try { statuses = ag.readStepStatuses(dbFile, [entry.receiptIdx]); } catch {}
          const status = statuses.get(entry.receiptIdx);
          if (status === undefined || ag.STATUS_STOPPED.has(status) || ag.STATUS_FAILED.has(status)) {
            cancelled = true; resolved = true;
          } else if (status !== ag.STATUS_QUEUED) {
            const item = items.find((row) => row.id === `ag-${entry.receiptIdx}`);
            startedAt = item?.at || Date.now(); resolved = true;
          }
        } else if (Number.isInteger(entry.afterIdx)) {
          const item = items.find((row) => matchesHistoryItem(entry, row));
          if (item) {
            entry.receiptIdx = Number(item.id.slice(3));
            startedAt = item.at || Date.now(); resolved = true;
          }
          // Note: when Antigravity queues messages during a background task
          // (not_fully_idle = 1), they live in its in-memory/UI Queued Messages
          // panel without a SQLite status=11 step. Never auto-cancel them after
          // a short timeout; reconcile them against history or a live window queue scan.
        }
        if (resolved) {
          changed = true;
          this.releaseFollowupAttachments?.(entry);
          if (cancelled) {
            Object.assign(entry, { state: 'cancelled', queuedAtDesktop: false, reason: null, stateVersion: Math.max(Date.now(), (entry.stateVersion || 0) + 1) });
            this.emit('followup.cancelled', id, { id: entry.id, threadId: id });
          } else {
            Object.assign(entry, { state: 'started', queuedAtDesktop: false, startedAt, reason: null, stateVersion: Math.max(Date.now(), (entry.stateVersion || 0) + 1) });
            this.emit('followup.started', id, this.antigravityQueueItem(id, entry));
          }
        }
      } else if (entry.state === 'uncertain' && Number.isInteger(entry.afterIdx)) {
        const queuedMatch = queued.find((step) => !claimedIdxs.has(step.idx) && step.idx > entry.afterIdx && matchesQueuedStep(entry, step));
        if (queuedMatch) {
          claimedIdxs.add(queuedMatch.idx);
          Object.assign(entry, { state: 'desktop_queued', queuedAtDesktop: true, receiptIdx: queuedMatch.idx, reason: DESKTOP_QUEUED_REASON, stateVersion: Math.max(Date.now(), (entry.stateVersion || 0) + 1) });
          this.emit('followup.queued', id, this.antigravityQueueItem(id, entry));
          changed = true;
          continue;
        }
        const receipt = items.find((item) => matchesHistoryItem(entry, item));
        if (receipt) {
          this.releaseFollowupAttachments?.(entry);
          Object.assign(entry, { state: 'started', receiptIdx: Number(receipt.id.slice(3)), startedAt: receipt.at || Date.now(), reason: null, stateVersion: Math.max(Date.now(), (entry.stateVersion || 0) + 1) });
          this.emit('followup.started', id, this.antigravityQueueItem(id, entry));
          changed = true;
        }
      }
    }

    // 2. Reconcile desktop-originated queued user steps not claimed by phone deliveries.
    const prevDesktop = Array.isArray(meta.desktopQueued) ? meta.desktopQueued : [];
    const prevStepEntries = prevDesktop.filter((entry) => entry.source !== 'window');
    const prevWindowEntries = prevDesktop.filter((entry) => entry.source === 'window');
    const prevByIdx = new Map(prevStepEntries.map((entry) => [entry.idx, entry]));
    const nextDesktop = [];
    for (const step of queued) {
      if (claimedIdxs.has(step.idx)) continue;
      const label = step.text || (step.mediaCount > 1 ? `[图片] ×${step.mediaCount}` : (step.mediaCount > 0 ? '[图片]' : ''));
      const existing = prevByIdx.get(step.idx);
      const entry = existing && existing.text === label
        ? existing
        : { id: `ag-step-${step.idx}`, idx: step.idx, text: label, createdAt: step.at || Date.now(), state: 'desktop_queued', origin: 'desktop', queuedAtDesktop: true, reason: DESKTOP_QUEUED_REASON, stateVersion: Date.now() };
      nextDesktop.push(entry);
      if (!existing) {
        this.emit('followup.queued', id, this.antigravityQueueItem(id, entry));
        changed = true;
      }
    }
    // Keep window-observed desktop queued entries unless a newer matching user step already started.
    for (const winEntry of prevWindowEntries) {
      const normText = ag.normalizeSendText(winEntry.text);
      const duplicateStep = nextDesktop.some((e) => ag.normalizeSendText(e.text) === normText);
      if (duplicateStep) {
        this.emit('followup.cancelled', id, { id: winEntry.id, threadId: id });
        changed = true;
        continue;
      }
      const after = Number.isInteger(winEntry.afterIdx) ? winEntry.afterIdx : -1;
      const startedItem = normText
        ? items.find((row) => row.value.type === 'userMessage' && Number(row.id.slice(3)) > after && ag.normalizeSendText(row.value.text) === normText)
        : null;
      if (startedItem) {
        this.emit('followup.started', id, { ...this.antigravityQueueItem(id, winEntry), state: 'started', blocking: false, reason: null, startedAt: startedItem.at || Date.now(), stateVersion: Math.max(Date.now(), (winEntry.stateVersion || 0) + 1) });
        changed = true;
      } else {
        nextDesktop.push(winEntry);
      }
    }
    const nextIdxs = new Set(nextDesktop.filter((entry) => entry.source !== 'window').map((entry) => entry.idx));
    const removed = prevStepEntries.filter((entry) => !nextIdxs.has(entry.idx) && !claimedIdxs.has(entry.idx));
    if (removed.length) {
      changed = true;
      let statuses = new Map();
      try { statuses = ag.readStepStatuses(dbFile, removed.map((entry) => entry.idx)); } catch {}
      for (const prev of removed) {
        const status = statuses.get(prev.idx);
        if (status !== undefined && status !== ag.STATUS_QUEUED && !ag.STATUS_STOPPED.has(status) && !ag.STATUS_FAILED.has(status)) {
          this.emit('followup.started', id, { ...this.antigravityQueueItem(id, prev), state: 'started', blocking: false, reason: null, startedAt: Date.now(), stateVersion: Math.max(Date.now(), (prev.stateVersion || 0) + 1) });
        } else {
          this.emit('followup.cancelled', id, { id: prev.id, threadId: id });
        }
      }
    }
    meta.desktopQueued = nextDesktop;
    return changed;
  },

  // Reconcile the live Queued Messages list observed directly in Antigravity's
  // window (covers both desktop-typed and phone-sent messages queued during a
  // background task when SQLite has no status=11 step).
  applyAntigravityWindowQueue(id, meta, rawQueuedItems = []) {
    if (!meta || !Array.isArray(rawQueuedItems)) return false;
    const normalizedList = rawQueuedItems
      .map((text) => String(text || '').trim())
      .filter(Boolean);
    const remaining = normalizedList.map((text, index) => ({ text, norm: ag.normalizeSendText(text), used: false, index }));
    let changed = false;

    const claimMatching = (text) => {
      const norm = ag.normalizeSendText(text);
      if (!norm) return null;
      const lower = norm.toLowerCase();
      const hit = remaining.find((slot) => {
        if (slot.used) return false;
        const slotLower = slot.norm.toLowerCase();
        const trimmed = slotLower.replace(/[.…]+$/, '').trim();
        return slotLower === lower ||
          slotLower.startsWith(lower) ||
          lower.startsWith(slotLower) ||
          (trimmed.length >= 4 && lower.startsWith(trimmed));
      });
      if (hit) hit.used = true;
      return hit || null;
    };

    // 1. Reconcile phone deliveries waiting in Antigravity's window queue (or uncertain).
    for (const entry of meta.deliveries || []) {
      if (entry.state === 'uncertain') {
        if (claimMatching(entry.text)) {
          Object.assign(entry, {
            state: 'desktop_queued',
            queuedAtDesktop: true,
            reason: DESKTOP_QUEUED_REASON,
            startedAt: null,
            stateVersion: Math.max(Date.now(), (entry.stateVersion || 0) + 1),
          });
          this.emit('followup.queued', id, this.antigravityQueueItem(id, entry));
          changed = true;
        }
        continue;
      }
      if (entry.state !== 'desktop_queued' || !entry.queuedAtDesktop) continue;
      const hasText = Boolean(ag.normalizeSendText(entry.text));
      if (hasText && claimMatching(entry.text)) continue;
      // Image-only messages have no text row in UI Automation; keep them queued while
      // the window still has queued items unless SQLite already recorded a receipt.
      if (!hasText && entry.imagePaths?.length && normalizedList.length > 0 && !Number.isInteger(entry.receiptIdx)) {
        continue;
      }
      // Only retire window-only entries here; SQLite-backed entries are retired by step status.
      if (!Number.isInteger(entry.receiptIdx)) {
        let receipt = null;
        try {
          receipt = this.readAntigravitySendState(id, entry.text, entry.afterIdx ?? -1, { expectMedia: Boolean(entry.imagePaths?.length) }).receipt;
        } catch {}
        changed = true;
        this.releaseFollowupAttachments?.(entry);
        if (receipt && !receipt.queued) {
          Object.assign(entry, { state: 'started', queuedAtDesktop: false, startedAt: receipt.at || Date.now(), receiptIdx: receipt.idx, reason: null, stateVersion: Math.max(Date.now(), (entry.stateVersion || 0) + 1) });
          this.emit('followup.started', id, this.antigravityQueueItem(id, entry));
        } else {
          Object.assign(entry, { state: 'cancelled', queuedAtDesktop: false, reason: null, stateVersion: Math.max(Date.now(), (entry.stateVersion || 0) + 1) });
          this.emit('followup.cancelled', id, { id: entry.id, threadId: id });
        }
      }
    }

    // 2. Claim any SQLite-backed desktopQueued steps first so we don't duplicate them.
    const prevDesktop = Array.isArray(meta.desktopQueued) ? meta.desktopQueued : [];
    const stepDesktop = prevDesktop.filter((entry) => entry.source !== 'window');
    for (const entry of stepDesktop) claimMatching(entry.text);

    // 3. Match remaining window-observed items against previous window desktopQueued entries.
    const prevWin = prevDesktop.filter((entry) => entry.source === 'window');
    const prevWinUsed = new Set();
    const nextWin = [];
    const seenCounts = new Map();
    for (const slot of remaining) {
      if (slot.used) continue;
      const existing = prevWin.find((entry) => !prevWinUsed.has(entry.id) && ag.normalizeSendText(entry.text) === slot.norm);
      if (existing) {
        prevWinUsed.add(existing.id);
        nextWin.push(existing);
      } else {
        const occ = (seenCounts.get(slot.norm) || 0) + 1;
        seenCounts.set(slot.norm, occ);
        const hash = crypto.createHash('sha1').update(slot.norm).digest('hex').slice(0, 10);
        const entry = {
          id: `ag-winq-${hash}-${occ}`,
          text: slot.text,
          createdAt: Date.now(),
          afterIdx: Number.isInteger(meta.lastIdx) ? meta.lastIdx : -1,
          state: 'desktop_queued',
          origin: 'desktop',
          queuedAtDesktop: true,
          source: 'window',
          reason: DESKTOP_QUEUED_REASON,
          stateVersion: Date.now(),
        };
        nextWin.push(entry);
        this.emit('followup.queued', id, this.antigravityQueueItem(id, entry));
        changed = true;
      }
    }
    for (const stale of prevWin) {
      if (prevWinUsed.has(stale.id)) continue;
      changed = true;
      let receipt = null;
      try { receipt = this.readAntigravitySendState(id, stale.text, stale.afterIdx ?? -1).receipt; } catch {}
      if (receipt && !receipt.queued) {
        this.emit('followup.started', id, { ...this.antigravityQueueItem(id, stale), state: 'started', blocking: false, reason: null, startedAt: receipt.at || Date.now(), stateVersion: Math.max(Date.now(), (stale.stateVersion || 0) + 1) });
      } else {
        this.emit('followup.cancelled', id, { id: stale.id, threadId: id });
      }
    }
    meta.desktopQueued = [...stepDesktop, ...nextWin];
    if (changed) this.saveAntigravityThreads();
    return changed;
  },

  async refreshAntigravityWindowQueue(id, meta, { force = false } = {}) {
    if (!meta) return false;
    if (!force && (meta.windowQueuePending || Date.now() - (meta.windowQueueCheckedAt || 0) < 4_000)) return false;
    meta.windowQueuePending = true;
    meta.windowQueueCheckedAt = Date.now();
    try {
      const result = await this.runAntigravitySend(id, 'queue').catch(() => ({ ok: false }));
      if (result.ok && Array.isArray(result.queuedItems)) {
        return this.applyAntigravityWindowQueue(id, meta, result.queuedItems);
      }
      return false;
    } finally {
      meta.windowQueuePending = false;
    }
  },

  // One conversation; returns whether anything was uploaded.
  async syncAntigravityConversation(dir, name, id, pinOrderMap = null, summary = null, hasSummaryIndex = false) {
    const dbFile = path.join(dir, name);
    let stat; try { stat = fs.statSync(dbFile); } catch { return false; }
    // Antigravity writes through SQLite's WAL; the .db itself only moves at a
    // checkpoint, so a long turn would otherwise look idle until it ends.
    try {
      const wal = fs.statSync(path.join(dir, `${name}-wal`));
      stat = { mtimeMs: Math.max(stat.mtimeMs, wal.mtimeMs), size: stat.size + wal.size };
    } catch {}
    const annotation = ag.readAnnotation(this.antigravityHomeDir, id);
    const pinned = Boolean(annotation.pinned);
    const pinOrder = pinned && pinOrderMap?.has(id) ? pinOrderMap.get(id) : -1;
    const meta = this.antigravityThreads.get(id) || { lastIdx: -1 };
    const prevNotFullyIdle = Boolean(meta.notFullyIdle);
    const prevStatus = this.antigravityThreadStatus(meta);
    if (summary) {
      meta.summaryStatus = summary.status || '';
      meta.notFullyIdle = Boolean(summary.notFullyIdle);
    } else if (hasSummaryIndex) {
      meta.summaryStatus = '';
      meta.notFullyIdle = false;
    }
    const rebuilt = meta.itemsVersion !== ITEMS_VERSION;
    const fileChanged = rebuilt || meta.mtimeMs !== stat.mtimeMs || meta.size !== stat.size;
    let conversation = null;
    let queueChanged = false;
    if (fileChanged) {
      conversation = ag.readConversation(dbFile, rebuilt ? -1 : meta.lastIdx, rebuilt ? null : meta.openIdx);
      if (conversation.isSubagent) {
        if (this.antigravityThreads.has(id)) meta.hiddenSubagent = true;
        return false;
      }
      if (conversation.lastIdx !== meta.lastIdx || conversation.lastStatus !== meta.lastStatus || conversation.lastType !== meta.lastType) meta.windowState = null;
      queueChanged = this.syncAntigravityDesktopQueue(id, meta, dbFile, conversation.queuedSteps, conversation.items);
      Object.assign(meta, { cwd: conversation.cwd, lastAt: conversation.lastAt || meta.lastAt,
        createdAt: conversation.createdAt, firstText: conversation.firstText,
        lastType: conversation.lastType, lastStatus: conversation.lastStatus,
        lastErrorRetryable: Boolean(conversation.lastErrorRetryable), waiting: conversation.waiting,
        model: conversation.model || meta.model || '' });
      // SQLite may still contain the unanswered question immediately after
      // its native panel was cancelled. A later native turn supersedes stop.
      if (this.antigravityStopped(meta)) meta.waiting = null;
      if (meta.waiting && meta.waitingId !== meta.waiting.requestId) { meta.waitingId = meta.waiting.requestId; meta.waitingAt = Date.now(); }
      if (!meta.waiting) meta.waitingId = null;
    }
    // Busy while the last step is open or the file keeps moving (see antigravityRunning).
    const running = this.antigravityRunning(meta, stat);
    if (running && meta.lastType === ag.STEP_MODEL && !ag.STATUS_ACTIVE.has(meta.lastStatus) && this.config?.configFile) this.refreshAntigravityWindowState(id, meta);
    const prevPinOrder = Number.isInteger(meta.pinOrder) && meta.pinOrder >= 0 ? meta.pinOrder : -1;
    const pinChanged = Boolean(meta.pinned) !== pinned || prevPinOrder !== pinOrder;
    const nextStatus = this.antigravityThreadStatus({ ...meta, running });
    const statusChanged = prevNotFullyIdle !== Boolean(meta.notFullyIdle) || prevStatus !== nextStatus || Boolean(meta.announcedStatus && meta.announcedStatus !== nextStatus);
    // 2: re-sent once after the integration came back (its rows had been
    // archived on the relay when it was removed). 3: rows gained the model.
    const titleChanged = meta.title !== annotation.title;
    const labelChanged = titleChanged || meta.viewedAt !== annotation.viewedAt || Boolean(meta.running) !== running || statusChanged || pinChanged || meta.indexVersion !== INDEX_VERSION;
    if (!fileChanged && !labelChanged && !queueChanged) return false;
    if (meta.model === undefined) meta.model = ag.readModel(dbFile);
    Object.assign(meta, { title: annotation.title, viewedAt: annotation.viewedAt, running, pinned, pinOrder,
      quietEnd: !running && this.antigravityEndedBySilence(meta, stat),
      updatedAt: meta.lastAt || stat.mtimeMs });
    // The relay stores items only for a thread it already has.
    await this.uploadAntigravityIndex(id, meta, { indexChanged: pinChanged || Boolean(meta.indexVersion && titleChanged) });
    meta.indexVersion = INDEX_VERSION;
    if (conversation) {
      const items = rebuilt || meta.lastIdx < 0 ? conversation.items.slice(-FIRST_SYNC_ITEMS) : conversation.items;
      if (items.length) await this.uploadAntigravityItems(id, items);
      Object.assign(meta, { lastIdx: conversation.lastIdx, openIdx: conversation.openIdx, mtimeMs: stat.mtimeMs, size: stat.size, itemsVersion: ITEMS_VERSION });
      if (conversation.items.length) this.emit('history.updated', id, { threadId: id, itemCount: conversation.items.length, updatedAt: conversation.lastAt || stat.mtimeMs, backend: 'antigravity', ...(rebuilt ? { fullHistory: true } : {}) });
    }
    this.antigravityThreads.set(id, meta);
    this.saveAntigravityThreads();
    if (meta.announcedStatus !== this.antigravityThreadStatus(meta)) this.announceAntigravityStatus(id, meta);
    return true;
  },

  announceAntigravityStatus(id, meta) {
    const status = this.antigravityThreadStatus(meta);
    // The list row on the relay carries a status too; re-upload it on the next
    // scan whenever the status changes outside a file change.
    if (meta.announcedStatus !== undefined && meta.announcedStatus !== status) meta.indexVersion = 0;
    meta.announcedRunning = Boolean(meta.running); meta.announcedStatus = status; meta.announcedAt = Date.now();
    this.emit('thread.status', id, { threadId: id, status, backend: 'antigravity', updatedAt: Date.now(), ...(status === 'completed' && meta.quietEnd ? { quiet: true } : {}) });
  },

  // For the connector's live-task snapshot: without these rows the phone
  // clears a running badge on every heartbeat.
  antigravityActiveThreadRows() {
    const rows = [];
    for (const [threadId, meta] of this.antigravityThreads || []) {
      if (meta.deletedSynced || meta.hiddenSubagent) continue;
      if (meta.waiting) rows.push({ threadId, status: 'desktop_waiting', updatedAt: meta.waitingAt || Date.now() });
      else if (meta.running) rows.push({ threadId, status: 'desktop_running', updatedAt: meta.announcedAt || meta.updatedAt || Date.now() });
      else if (this.antigravityBackgroundRunning(meta)) rows.push({ threadId, status: 'desktop_background', updatedAt: meta.announcedAt || meta.updatedAt || Date.now() });
    }
    return rows;
  },

  // Phone uploads arrive as files. Images are pasted natively into Antigravity's
  // composer; other files are referenced by path so Antigravity can read them.
  antigravityAttachmentParts(args) {
    const raw = Array.isArray(args.attachments) ? args.attachments : [];
    const attachments = raw.length && typeof this.resolveAttachments === 'function'
      ? this.resolveAttachments(args.threadId, raw)
      : raw;
    const imagePaths = [];
    const notes = [];
    const kept = [];
    try {
      for (const item of attachments) {
        if (!item?.path) continue;
        let bytes = null;
        let size = 0;
        try {
          size = fs.statSync(item.path).size;
          if (size <= MAX_IMAGE_BYTES) bytes = fs.readFileSync(item.path);
        } catch {
          const message = isImageAttachment(item)
            ? '图片无法读取，请重新选择后再发送。'
            : '附件文件无法读取，请重新选择后再发送。';
          throw Object.assign(new Error(message), { delivery: 'not_sent' });
        }
        const mime = bytes ? detectImageMime(bytes) : null;
        if (isImageAttachment(item) && !mime) {
          const reason = size > MAX_IMAGE_BYTES ? '图片超过 25 MB，请压缩后重新选择。' : '图片格式不受支持或文件已损坏，请重新选择。';
          throw Object.assign(new Error(reason), { delivery: 'not_sent' });
        }
        if (item.attachmentId) {
          try { this.attachmentStore?.retain?.(item.attachmentId); } catch {}
        }
        kept.push(item);
        if (mime) {
          imagePaths.push(item.path);
        } else {
          notes.push(`[附件] ${item.name || path.basename(item.path)}\n路径：${item.path}`);
        }
      }
    } catch (error) {
      if (kept.length) this.releaseFollowupAttachments?.({ attachments: kept });
      throw error;
    }
    const base = String(args.text || '').trim();
    const text = notes.length ? [base, ...notes].filter(Boolean).join('\n\n') : base;
    return { text, imagePaths, attachments: kept };
  },

  // Messages waiting for the running turn to end (Antigravity's Send button is
  // not available meanwhile) or mirrored from Antigravity's own Queued Messages.
  antigravityQueueItem(threadId, entry) {
    const state = entry.state || 'desktop_queued';
    const attachments = publicAttachments(entry.attachments);
    const displayText = sanitizeUploadReferences(entry.text || '');
    return {
      id: entry.id, requestId: entry.id, threadId,
      text: displayText || (attachments.length ? '图片附件' : ''),
      createdAt: entry.createdAt, state, reason: entry.reason || null,
      startedAt: entry.startedAt || null, stateVersion: entry.stateVersion || 0,
      origin: entry.origin || 'mobile', blocking: state === 'desktop_queued',
      backend: 'antigravity',
      ...(attachments.length ? { attachments } : {}),
    };
  },

  antigravityQueueItems(threadId = null) {
    const rows = [];
    for (const [id, meta] of this.antigravityThreads || []) {
      if (threadId && id !== threadId) continue;
      for (const entry of meta.queue || []) rows.push(this.antigravityQueueItem(id, entry));
      for (const entry of meta.desktopQueued || []) rows.push(this.antigravityQueueItem(id, entry));
      for (const entry of meta.deliveries || []) if (['dispatching', 'desktop_queued', 'uncertain', 'failed'].includes(entry.state)) rows.push(this.antigravityQueueItem(id, entry));
    }
    return rows;
  },

  refreshAntigravityWindowState(id, meta) {
    if (meta.windowProbePending || Date.now() - (meta.windowProbedAt || 0) < 5_000) return;
    meta.windowProbePending = true; meta.windowProbedAt = Date.now();
    this.runAntigravitySend(id, 'probe').then((result) => {
      if (result.ok && result.current && Array.isArray(result.queuedItems)) {
        this.applyAntigravityWindowQueue(id, meta, result.queuedItems);
      }
      if (!result.ok || !result.current || !result.foreground || !result.box || !result.send || result.active) return;
      if (meta.deliveries?.some((entry) => entry.state === 'dispatching')) return;
      const observedAt = result.observedAt || Date.now();
      if (observedAt < Math.max(meta.lastAt || 0, meta.sentAt || 0)) return;
      meta.windowState = { at: observedAt, active: false, foreground: true };
      if (!result.active && meta.running && !meta.waiting) {
        meta.running = false; this.announceAntigravityStatus(id, meta);
        this.saveAntigravityThreads(); this.uploadAntigravityIndex(id, meta).catch((error) => this.log(error));
      }
    }).catch((error) => this.log(error)).finally(() => { meta.windowProbePending = false; });
  },

  readAntigravitySendState(id, text = '', afterIdx = -1, options = {}) {
    return ag.readSendState(path.join(this.antigravityHomeDir, 'conversations', `${id}.db`), text, afterIdx, options);
  },

  recoverAntigravityDeliveries() {
    for (const [id, meta] of this.antigravityThreads) for (const entry of meta.deliveries || []) {
      if (entry.state !== 'dispatching') continue;
      let receipt = null;
      try { receipt = this.readAntigravitySendState(id, entry.text, entry.afterIdx, { expectMedia: Boolean(entry.imagePaths?.length) }).receipt; } catch {}
      if (receipt?.queued) {
        Object.assign(entry, { state: 'desktop_queued', queuedAtDesktop: true, reason: DESKTOP_QUEUED_REASON, receiptIdx: receipt.idx, startedAt: null, stateVersion: Math.max(Date.now(), (entry.stateVersion || 0) + 1) });
      } else {
        if (receipt) this.releaseFollowupAttachments?.(entry);
        Object.assign(entry, { state: receipt ? 'started' : 'uncertain', reason: receipt ? null : SEND_UNCERTAIN, receiptIdx: receipt?.idx, startedAt: receipt?.at || null, stateVersion: Math.max(Date.now(), (entry.stateVersion || 0) + 1) });
      }
      meta.queue = (meta.queue || []).filter((queued) => queued.id !== entry.id);
    }
    this.saveAntigravityThreads();
  },

  serializeAntigravityDelivery(run) {
    const next = (this._antigravityDeliveryChain || Promise.resolve()).then(run, run);
    this._antigravityDeliveryChain = next.catch(() => {});
    return next;
  },

  antigravityDeliveryResult(id, entry) {
    const item = this.antigravityQueueItem(id, entry);
    return { accepted: entry.state === 'started', queued: !entry.state || entry.state === 'desktop_queued', uncertain: entry.state === 'uncertain', failed: entry.state === 'failed', cancelled: entry.state === 'cancelled', item, deliveredTo: entry.state === 'started' ? 'desktop' : (entry.queuedAtDesktop ? 'desktop_queue' : null), backend: 'antigravity' };
  },

  runAntigravitySend(conversationId, mode, text = '', { idleSeconds = 0, imagePaths = [], steerNow = false } = {}) {
    const file = path.join(os.tmpdir(), `kh-link-antigravity-${crypto.randomUUID()}.txt`);
    const progressFile = `${file}.progress.json`;
    fs.writeFileSync(file, text || '', { encoding: 'utf8', mode: 0o600 });
    fs.writeFileSync(progressFile, JSON.stringify({ phase: 'starting', mayHaveSent: false }), { mode: 0o600 });
    // Row management uses UI Automation with no clipboard. Its Chromium menu
    // can stay stale on an STA thread while the actual desktop has changed.
    const apartment = ['rename', 'pin', 'unpin'].includes(mode) ? '-MTA' : '-STA';
    const args = ['-NoProfile', '-NonInteractive', apartment, '-ExecutionPolicy', 'Bypass', '-File', SEND_SCRIPT, '-TextFile', file, '-ProgressFile', progressFile, '-Mode', mode];
    if (conversationId) args.push('-ConversationId', conversationId);
    if (idleSeconds > 0) args.push('-IdleSeconds', String(idleSeconds));
    if (steerNow) args.push('-SteerNow');
    const images = Array.isArray(imagePaths) ? imagePaths.filter(Boolean) : [];
    if (images.length) args.push('-ImageFiles', images.join('|'));
    const exec = this.execFileFn || execFile;
    const timeout = images.length || mode === 'new' ? 60_000 : 45_000;
    // One at a time: two scripts driving the same window would trip over each other.
    const run = () => new Promise((resolve) => {
      exec('powershell.exe', args, { windowsHide: true, timeout }, (error, stdout) => {
        let progress = {};
        try { progress = JSON.parse(fs.readFileSync(progressFile, 'utf8')); } catch {}
        if (progress.phase === 'confirmed') return resolve({ ...progress, ok: true, reason: 'confirmed' });
        if (error && !stdout) return resolve({ ...progress, ok: false, reason: 'automation_timeout' });
        try { resolve(JSON.parse(String(stdout).trim().split(/\r?\n/).pop())); } catch { resolve({ ...progress, ok: false, reason: 'bad_output' }); }
      });
    });
    const runRetrying = async () => {
      const result = await run();
      if (result.ok) return result;
      const refreshRename = mode === 'rename' && ['row_control_unavailable', 'title_edit_unavailable'].includes(result.reason);
      if (!refreshRename && !/TypeInitializationException/i.test(String(result.reason || ''))) return result;
      await new Promise(resolve => setTimeout(resolve, 800));
      // A fresh UIA client can see a menu the first client missed. Skip the
      // replay if the target title already reached the desktop's metadata.
      if (refreshRename && ag.readAnnotation(this.antigravityHomeDir, conversationId).title === text) return result;
      return run();
    };
    const next = (this._antigravitySendChain || Promise.resolve()).then(runRetrying, runRetrying);
    next.finally(() => { for (const temporary of [file, progressFile]) fs.rm(temporary, { force: true }, () => {}); }).catch(() => {});
    this._antigravitySendChain = next.catch(() => {});
    return next;
  },

  async deliverAntigravity(id, meta, entry, { waitForIdle = false, steerNow = false } = {}) {
    const boundary = this.readAntigravitySendState(id).lastIdx;
    Object.assign(entry, { state: 'dispatching', afterIdx: boundary, attemptedAt: Date.now(), stateVersion: Date.now() });
    const previous = (meta.deliveries || []).filter((row) => row.id !== entry.id);
    meta.deliveries = [...previous.filter((row) => ['uncertain', 'dispatching', 'desktop_queued'].includes(row.state)),
      ...previous.filter((row) => !['uncertain', 'dispatching', 'desktop_queued'].includes(row.state) && Date.now() - row.createdAt < 7 * 86400_000).slice(-99), entry];
    // Save before touching the Send button. After a restart this request is
    // checked against history, never blindly driven through the window again.
    this.saveAntigravityThreads({ required: true });
    // This acknowledges durable processing, not delivery to Antigravity.
    // The phone keeps showing "sending" until the history receipt arrives.
    this.emit('followup.queued', id, this.antigravityQueueItem(id, entry));
    const result = await this.runAntigravitySend(id, 'send', entry.text, { idleSeconds: waitForIdle ? IDLE_BEFORE_SEND_S : 0, imagePaths: entry.imagePaths || [], steerNow: Boolean(steerNow || entry.steerNow) })
      .catch(() => ({ ok: false, reason: 'automation_error' }));
    if (!result.ok && result.reason === 'user_active') {
      meta.deliveries = meta.deliveries.filter((row) => row.id !== entry.id); delete entry.state; this.saveAntigravityThreads();
      const error = new Error('电脑正在使用，等空闲后再发'); error.code = 'USER_ACTIVE'; throw error;
    }
    if (!result.ok && (SEND_ERRORS[result.reason] || result.mayHaveSent === false)) {
      Object.assign(entry, { state: 'failed', reason: SEND_ERRORS[result.reason] || '反重力窗口操作失败，消息没有发出。', stateVersion: Date.now() });
      this.releaseFollowupAttachments?.(entry);
      this.saveAntigravityThreads();
      return this.antigravityDeliveryResult(id, entry);
    }
    const windowConfirmed = Boolean(result.ok && result.receiptSource === 'window' && Number.isFinite(result.confirmedAt));
    const windowQueued = Boolean(result.queuedInWindow && !result.steered);
    const confirmBudget = this.antigravitySendConfirmMs ?? SEND_CONFIRM_MS;
    const deadline = Date.now() + (windowConfirmed ? Math.min(WINDOW_QUEUE_CHECK_MS, confirmBudget) : confirmBudget);
    const expectMedia = Boolean(entry.imagePaths?.length);
    let receipt = null;
    do {
      try { receipt = this.readAntigravitySendState(id, entry.text, boundary, { expectMedia }).receipt; } catch {}
      if (receipt || Date.now() >= deadline) break;
      await new Promise((resolve) => setTimeout(resolve, 400));
    } while (true);
    if (!receipt && windowConfirmed) {
      receipt = { at: result.confirmedAt, source: 'window', queued: windowQueued };
    }
    const isQueued = Boolean((receipt?.queued || windowQueued) && !result.steered);
    if (isQueued) {
      Object.assign(entry, {
        state: 'desktop_queued',
        queuedAtDesktop: true,
        reason: DESKTOP_QUEUED_REASON,
        startedAt: null,
        receiptIdx: receipt?.idx ?? null,
        receiptSource: receipt?.source || 'history',
        stateVersion: Math.max(Date.now(), entry.stateVersion + 1),
      });
      if (Array.isArray(result.queuedItems)) this.applyAntigravityWindowQueue(id, meta, result.queuedItems);
      this.saveAntigravityThreads();
      this.emit('followup.queued', id, this.antigravityQueueItem(id, entry));
      setTimeout(() => this.pollAntigravity().catch((error) => this.log(error)), 2_000).unref?.();
      return this.antigravityDeliveryResult(id, entry);
    }
    Object.assign(entry, { state: receipt ? 'started' : 'uncertain', queuedAtDesktop: false, reason: receipt ? null : SEND_UNCERTAIN, startedAt: receipt?.at || null, receiptIdx: receipt?.idx, receiptSource: receipt?.source || 'history', stateVersion: Math.max(Date.now(), entry.stateVersion + 1) });
    if (receipt) this.releaseFollowupAttachments?.(entry);
    if (Array.isArray(result.queuedItems)) this.applyAntigravityWindowQueue(id, meta, result.queuedItems);
    this.saveAntigravityThreads();
    if (!receipt) return this.antigravityDeliveryResult(id, entry);
    // Receipt observation happens after native history timestamps. Using that
    // later time would make a finished reply look like a pending new send.
    Object.assign(meta, { running: true, sentAt: entry.attemptedAt, sentReceiptIdx: receipt.idx, stoppedAt: 0, windowState: null });
    this.announceAntigravityStatus(id, meta);
    this.saveAntigravityThreads();
    setTimeout(() => this.pollAntigravity().catch((error) => this.log(error)), 2_000).unref?.();
    return this.antigravityDeliveryResult(id, entry);
  },

  async drainAntigravityQueues() {
    for (const [id, meta] of this.antigravityThreads || []) {
      if (!meta.queue?.length || meta.running || meta.waiting || this._antigravityDraining) continue;
      const entry = meta.queue[0];
      if (entry.retryAt && Date.now() < entry.retryAt) continue;
      this._antigravityDraining = true;
      try {
        await this.serializeAntigravityDelivery(async () => {
          if (meta.running || meta.waiting || meta.queue?.[0]?.id !== entry.id) return;
          const result = await this.deliverAntigravity(id, meta, entry, { waitForIdle: Date.now() - entry.createdAt < MAX_IDLE_WAIT_MS });
          meta.queue = meta.queue.filter((row) => row.id !== entry.id); this.saveAntigravityThreads();
          const event = result.accepted ? 'followup.started' : (result.queued ? 'followup.queued' : 'followup.failed');
          this.emit(event, id, { ...result.item, needsConfirmation: result.uncertain });
        });
      } catch (error) {
        // Someone is at the computer or SQLite is momentarily locked: keep it first in line and retry shortly.
        if (error.code === 'USER_ACTIVE' || /SQLITE_BUSY|database is locked/i.test(String(error?.message || ''))) {
          entry.retryAt = Date.now() + IDLE_RETRY_MS;
          continue;
        }
        meta.queue.shift(); this.releaseFollowupAttachments?.(entry); this.saveAntigravityThreads();
        this.emit('followup.failed', id, { ...this.antigravityQueueItem(id, entry), state: 'failed', reason: error.message });
      } finally { this._antigravityDraining = false; }
    }
  },

  async steerAntigravityQueuedItem(threadId, meta, id) {
    const queued = meta.queue?.find((entry) => entry.id === id);
    if (queued) {
      meta.queue = (meta.queue || []).filter((entry) => entry.id !== id);
      this.saveAntigravityThreads();
      const result = await this.deliverAntigravity(threadId, meta, queued, { waitForIdle: false, steerNow: true });
      const event = result.accepted ? 'followup.started' : (result.queued ? 'followup.queued' : 'followup.failed');
      this.emit(event, threadId, { ...result.item, needsConfirmation: result.uncertain });
      return { ...result, steered: result.accepted };
    }
    const delivery = meta.deliveries?.find((entry) => entry.id === id && entry.state === 'desktop_queued');
    const desktopQueued = meta.desktopQueued?.find((entry) => entry.id === id);
    const target = delivery || desktopQueued;
    if (!target) throw new Error(SEND_ERRORS.queued_item_not_found);
    const result = await this.runAntigravitySend(threadId, 'steer', target.text || '');
    if (!result.ok) {
      if (Array.isArray(result.queuedItems) && ['no_queue', 'queued_item_not_found'].includes(result.reason)) {
        this.applyAntigravityWindowQueue(threadId, meta, result.queuedItems);
        setTimeout(() => this.pollAntigravity().catch((error) => this.log(error)), 500).unref?.();
      }
      throw new Error(SEND_ERRORS[result.reason] || `立即发送失败：${result.reason}`);
    }
    const now = Date.now();
    if (delivery) {
      Object.assign(delivery, { state: 'started', queuedAtDesktop: false, startedAt: now, reason: null, stateVersion: Math.max(now, (delivery.stateVersion || 0) + 1) });
      this.releaseFollowupAttachments?.(delivery);
    } else if (desktopQueued) {
      meta.desktopQueued = (meta.desktopQueued || []).filter((entry) => entry.id !== id);
    }
    if (Array.isArray(result.queuedItems)) this.applyAntigravityWindowQueue(threadId, meta, result.queuedItems);
    const item = { ...this.antigravityQueueItem(threadId, target), state: 'started', blocking: false, reason: null, startedAt: now, stateVersion: Math.max(now, (target.stateVersion || 0) + 1) };
    Object.assign(meta, { running: true, sentAt: now, stoppedAt: 0, windowState: null });
    this.announceAntigravityStatus(threadId, meta);
    this.saveAntigravityThreads();
    this.emit('followup.started', threadId, item);
    setTimeout(() => this.pollAntigravity().catch((error) => this.log(error)), 1_500).unref?.();
    return { steered: true, accepted: true, item, backend: 'antigravity' };
  },

  // Phone commands for an Antigravity thread.
  async antigravityCommand(payload) {
    const threadId = payload.args?.threadId;
    if (payload.action === 'history.sync') {
      const meta = this.antigravityThreads.get(threadId);
      if (meta) {
        meta.mtimeMs = 0;
        await this.pollAntigravity();
        if (this.config?.configFile || this.antigravityWindowQueueEnabled) {
          await this.refreshAntigravityWindowQueue(threadId, meta, { force: true });
        }
      }
      return { synced: true, threadId, backend: 'antigravity' };
    }
    const meta = this.antigravityThreads.get(threadId);
    const args = payload.args || {};
    switch (payload.action) {
      case 'antigravity.projects.list': {
        return this.antigravityProjectsList();
      }
      case 'antigravity.models.list': {
        if (args.refresh) {
          const sampleId = [...(this.antigravityThreads?.entries?.() || [])]
            .filter(([, m]) => m && !m.hiddenSubagent && !m.deletedSynced)
            .sort((a, b) => (b[1].lastAt || b[1].updatedAt || 0) - (a[1].lastAt || a[1].updatedAt || 0))[0]?.[0];
          if (sampleId) {
            const read = await this.runAntigravitySend(sampleId, 'settings');
            if (!read.ok) throw new Error(SEND_ERRORS[read.reason] || `读取反重力设置失败：${read.reason}`);
            const shaped = antigravityCatalog(read);
            if (!shaped.catalog) throw new Error('暂时无法读取反重力的可用模型，请重新打开模型设置。');
            this.saveAntigravityCatalogCache({ catalog: shaped.catalog, permissionCatalog: shaped.permissionCatalog });
          }
        }
        return this.antigravityModelsListPayload();
      }
      case 'thread.new':
      case 'thread.newWithTurn': {
        return this.serializeAntigravityDelivery(async () => {
          const requestId = String(payload.requestId || args.requestId || '').trim();
          this._antigravityCreatedTasks ||= new Map();
          if (requestId && this._antigravityCreatedTasks.has(requestId)) {
            return { ...this._antigravityCreatedTasks.get(requestId), duplicate: true };
          }
          const prompt = String(args.text || '').trim();
          if (!prompt) throw new Error(SEND_ERRORS.empty_message);

          const rawProjectId = String(args.projectId || '').trim();
          const rawCwd = String(args.cwd || '').trim();
          let targetProjectId = '';
          let targetProjectName = '';
          let resolvedCwd = '';
          if (rawProjectId === 'outside-of-project' || (!rawProjectId && !rawCwd)) {
            targetProjectId = 'outside-of-project';
            targetProjectName = 'No Project';
            resolvedCwd = '';
          } else {
            const projects = ag.readProjects(this.antigravityHomeDir);
            const matched = ag.findProject(projects, { projectId: rawProjectId, cwd: rawCwd });
            if (!matched) throw new Error(SEND_ERRORS.project_not_found);
            targetProjectId = matched.id;
            targetProjectName = matched.name;
            resolvedCwd = matched.cwd;
          }

          const rawModel = String(args.model || '').trim();
          const model = rawModel.startsWith('antigravity/') ? rawModel.slice('antigravity/'.length) : rawModel;
          const level = String(args.effort || '').trim();
          const rawPermission = String(args.permissionMode || args.mode || '').trim();
          const permission = rawPermission && PRESETS.some((preset) => preset.value === rawPermission) ? rawPermission : '';
          if (rawPermission && !permission && !['manual', 'default', 'auto', 'yolo'].includes(rawPermission.toLowerCase())) {
            throw new Error('反重力没有这个权限模式');
          }

          const beforeIds = new Set(ag.listConversationIds(this.antigravityHomeDir));
          const startedAt = Date.now();
          const scriptPayload = {
            prompt,
            projectId: targetProjectId,
            projectName: targetProjectName,
            ...(model ? { model, level } : {}),
            ...(permission ? { permission } : {}),
          };
          const result = await this.runAntigravitySend('', 'new', JSON.stringify(scriptPayload))
            .catch(() => ({ ok: false, reason: 'automation_error', mayHaveSent: false }));

          if (!result.ok && (SEND_ERRORS[result.reason] || result.mayHaveSent === false)) {
            throw new Error(SEND_ERRORS[result.reason] || '反重力新建任务失败，请检查电脑端反重力窗口。');
          }

          let newId = /^[0-9a-f-]{36}$/i.test(String(result.conversationId || '')) ? String(result.conversationId) : '';
          if (!newId) {
            const confirmMs = this.antigravityNewConfirmMs ?? 10_000;
            const deadline = Date.now() + confirmMs;
            while (!newId && Date.now() <= deadline) {
              newId = this.findNewAntigravityConversationId(beforeIds, prompt, startedAt);
              if (newId || Date.now() >= deadline) break;
              await new Promise((resolve) => setTimeout(resolve, 350));
            }
          }
          if (!newId) throw new Error(SEND_ERRORS.new_conversation_unconfirmed);

          const dir = path.join(this.antigravityHomeDir || '', 'conversations');
          const dbName = `${newId}.db`;
          const dbFile = path.join(dir, dbName);
          const dbWaitMs = this.antigravityNewDbWaitMs ?? 3_000;
          const dbDeadline = Date.now() + dbWaitMs;
          while (this.antigravityHomeDir && !fs.existsSync(dbFile) && Date.now() < dbDeadline) {
            await new Promise((resolve) => setTimeout(resolve, 200));
          }
          if (this.antigravityHomeDir && fs.existsSync(dbFile) && typeof this.syncAntigravityConversation === 'function') {
            try { await this.syncAntigravityConversation(dir, dbName, newId); } catch (error) { this.log?.(error); }
          }

          const newMeta = this.antigravityThreads.get(newId) || { lastIdx: -1 };
          Object.assign(newMeta, {
            cwd: resolvedCwd || newMeta.cwd || '',
            firstText: newMeta.firstText || prompt,
            running: true,
            sentAt: startedAt,
            stoppedAt: 0,
            windowState: null,
            lastAt: newMeta.lastAt || startedAt,
            createdAt: newMeta.createdAt || startedAt,
            updatedAt: newMeta.updatedAt || Date.now(),
          });
          this.antigravityThreads.set(newId, newMeta);
          try { await this.uploadAntigravityIndex(newId, newMeta, { indexChanged: true }); } catch (error) { this.log?.(error); }
          this.announceAntigravityStatus(newId, newMeta);
          this.saveAntigravityThreads();
          this.emit?.('threads.updated', null, { updatedAt: Date.now() });
          setTimeout(() => this.pollAntigravity().catch((error) => this.log?.(error)), 1_500).unref?.();

          const created = {
            thread: { id: newId },
            threadId: newId,
            accepted: true,
            deliveredTo: 'desktop',
            backend: 'antigravity',
            cwd: resolvedCwd,
            projectId: targetProjectId,
          };
          if (requestId) {
            this._antigravityCreatedTasks.set(requestId, created);
            if (this._antigravityCreatedTasks.size > 100) {
              const oldest = this._antigravityCreatedTasks.keys().next().value;
              if (oldest) this._antigravityCreatedTasks.delete(oldest);
            }
          }
          return created;
        });
      }
      case 'thread.rename':
      case 'thread.pin': {
        if (!meta || meta.hiddenSubagent || !/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(threadId)) throw new Error('找不到这个反重力对话。');
        const rename = payload.action === 'thread.rename';
        const title = typeof args.name === 'string' ? args.name.trim() : '';
        if (rename && (!title || /[\r\n\0]/.test(title))) throw new Error('请输入单行对话标题。');
        if (!rename && typeof args.pinned !== 'boolean') throw new Error('缺少置顶状态。');
        const mode = rename ? 'rename' : args.pinned ? 'pin' : 'unpin';
        const result = await this.runAntigravitySend(threadId, mode, title);
        // Some desktop versions save as the editor closes, before UI Automation
        // can verify focus. The annotation is the receipt in either case.
        for (let attempt = 0; attempt < 20; attempt++) {
          const annotation = ag.readAnnotation(this.antigravityHomeDir, threadId);
          if (rename ? annotation.title === title : annotation.pinned === args.pinned) {
            this.pollAntigravity().catch(error => this.log(error));
            if (rename) return { backend: 'antigravity', threadId, title };
            const order = ag.readPinnedOrder(this.antigravityStorageFile) || [];
            return { backend: 'antigravity', threadId, pinned: args.pinned, pinOrder: args.pinned ? order.indexOf(threadId) : -1 };
          }
          await new Promise(resolve => setTimeout(resolve, 150));
        }
        if (!result.ok) throw new Error(SEND_ERRORS[result.reason] || '反重力未能修改这个对话，请检查电脑端。');
        throw new Error('反重力尚未确认保存，列表会在电脑状态同步后更新。');
      }
      case 'thread.pin.reorder': {
        const targetId = String(args.targetId || '').trim();
        const position = args.position === 'after' ? 'after' : 'before';
        const uuidRe = /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
        if (!meta || meta.hiddenSubagent || !uuidRe.test(threadId) || !uuidRe.test(targetId) || threadId === targetId) {
          throw new Error('找不到对应的反重力置顶对话。');
        }
        const targetMeta = this.antigravityThreads.get(targetId);
        if (!targetMeta || targetMeta.hiddenSubagent) throw new Error('找不到目标反重力置顶对话。');
        const beforeOrder = ag.readPinnedOrder(this.antigravityStorageFile) || [];
        const srcPinned = Boolean(meta.pinned || beforeOrder.includes(threadId));
        const dstPinned = Boolean(targetMeta.pinned || beforeOrder.includes(targetId));
        if (!srcPinned || !dstPinned) throw new Error(SEND_ERRORS.not_pinned);
        if (isPinAlreadyInPosition(beforeOrder, threadId, targetId, position)) {
          return { synced: true, changed: false, backend: 'antigravity', orderedIds: beforeOrder, pinOrderById: pinOrderMap(beforeOrder) };
        }
        const result = await this.runAntigravitySend(threadId, 'reorder_pin', JSON.stringify({ targetId, position }));
        let afterOrder = beforeOrder;
        for (let attempt = 0; attempt < 25; attempt++) {
          afterOrder = ag.readPinnedOrder(this.antigravityStorageFile) || [];
          if (pinReorderApplied(beforeOrder, afterOrder, threadId, targetId, position)) {
            const rankMap = pinOrderMap(afterOrder);
            for (const [id, m] of this.antigravityThreads) {
              if (m.pinned && rankMap[id] !== undefined) m.pinOrder = rankMap[id];
            }
            this.saveAntigravityThreads?.();
            this.pollAntigravity?.().catch?.((error) => this.log?.(error));
            return { synced: true, changed: true, backend: 'antigravity', orderedIds: afterOrder, pinOrderById: rankMap };
          }
          await new Promise((resolve) => setTimeout(resolve, 200));
        }
        if (!result.ok) throw new Error(SEND_ERRORS[result.reason] || '反重力未能完成置顶拖拽排序，请检查电脑端。');
        throw new Error('反重力尚未确认保存置顶排序，请检查电脑端。');
      }
      case 'followup.list': {
        const shouldInspectWindow = Boolean(
          meta && (this.config?.configFile || this.antigravityWindowQueueEnabled) && (
            meta.notFullyIdle || meta.running || meta.desktopQueued?.length ||
            meta.deliveries?.some((entry) => entry.state === 'desktop_queued')
          ),
        );
        if (shouldInspectWindow) await this.refreshAntigravityWindowQueue(threadId, meta);
        return { items: this.antigravityQueueItems(threadId) };
      }
      case 'turn.start':
      case 'turn.steer':
      case 'followup.enqueue': {
        if (!meta) throw new Error('没有找到这个反重力对话');
        const isSteer = payload.action === 'turn.steer';
        return this.serializeAntigravityDelivery(async () => {
          const requestId = payload.requestId || args.requestId || `ag-q-${crypto.randomUUID()}`;
          const previous = [...(meta.queue || []), ...(meta.deliveries || [])].find((entry) => entry.id === requestId);
          if (previous) return { ...this.antigravityDeliveryResult(threadId, previous), duplicate: true };
          const { text, imagePaths, attachments } = this.antigravityAttachmentParts({ ...args, threadId });
          if (!text && !imagePaths.length) throw new Error(SEND_ERRORS.empty_message);
          const entry = {
            id: requestId, text, createdAt: Date.now(),
            ...(isSteer ? { steerNow: true } : {}),
            ...(imagePaths.length ? { imagePaths } : {}),
            ...(attachments.length ? { attachments: publicAttachments(attachments) } : {}),
          };
          const enqueue = () => {
            const before = meta.queue || [];
            meta.queue = [...before, entry];
            try { this.saveAntigravityThreads({ required: true }); } catch (error) { meta.queue = before; throw error; }
            const item = this.antigravityQueueItem(threadId, entry);
            this.emit('followup.queued', threadId, item);
            return { queued: true, item, backend: 'antigravity' };
          };
          if (!isSteer && (meta.running || meta.waiting || meta.queue?.length)) return enqueue();
          try {
            const delivered = await this.deliverAntigravity(threadId, meta, entry, { waitForIdle: !isSteer, steerNow: isSteer });
            if (delivered.accepted) this.emit('followup.started', threadId, delivered.item);
            else if (delivered.failed || delivered.uncertain) this.emit('followup.failed', threadId, { ...delivered.item, needsConfirmation: delivered.uncertain });
            return delivered;
          }
          catch (error) { if (error.code === 'USER_ACTIVE') return enqueue(); throw error; }
        });
      }
      case 'followup.steer': {
        if (!meta) throw new Error('没有找到这个反重力对话');
        return this.serializeAntigravityDelivery(() => this.steerAntigravityQueuedItem(threadId, meta, args.id));
      }
      case 'followup.steer_all': {
        if (!meta) throw new Error('没有找到这个反重力对话');
        return this.serializeAntigravityDelivery(async () => {
          const ids = Array.isArray(args.ids) && args.ids.length
            ? args.ids
            : this.antigravityQueueItems(threadId).filter((item) => ['desktop_queued', 'pending'].includes(item.state)).map((item) => item.id);
          if (!ids.length) throw new Error(SEND_ERRORS.no_queue);
          const results = [];
          for (const itemId of ids) {
            results.push(await this.steerAntigravityQueuedItem(threadId, meta, itemId));
          }
          return { steered: true, count: results.length, items: results.map((r) => r.item), backend: 'antigravity' };
        });
      }
      case 'followup.cancel': {
        return this.serializeAntigravityDelivery(async () => {
          if (meta) {
            const queued = meta.queue?.find((entry) => entry.id === args.id);
            const delivery = meta.deliveries?.find((entry) => entry.id === args.id);
            const desktopQueued = meta.desktopQueued?.find((entry) => entry.id === args.id);
            if (['dispatching', 'started'].includes(delivery?.state)) throw new Error('这条消息已经开始发送，无法再从队列取消。');
            if (delivery?.queuedAtDesktop || desktopQueued) {
              const target = delivery || desktopQueued;
              const result = await this.runAntigravitySend(threadId, 'cancel_queued', target.text || '');
              if (!result.ok) {
                if (Array.isArray(result.queuedItems) && ['no_queue', 'queued_item_not_found'].includes(result.reason)) {
                  this.applyAntigravityWindowQueue(threadId, meta, result.queuedItems);
                  setTimeout(() => this.pollAntigravity().catch((error) => this.log(error)), 500).unref?.();
                }
                throw new Error(SEND_ERRORS[result.reason] || '无法从反重力等待队列删除这条消息，请在电脑上操作。');
              }
              if (delivery) {
                Object.assign(delivery, { state: 'cancelled', queuedAtDesktop: false, reason: null, stateVersion: Math.max(Date.now(), (delivery.stateVersion || 0) + 1) });
                this.releaseFollowupAttachments?.(delivery);
              } else {
                meta.desktopQueued = (meta.desktopQueued || []).filter((entry) => entry.id !== args.id);
              }
              if (Array.isArray(result.queuedItems)) this.applyAntigravityWindowQueue(threadId, meta, result.queuedItems);
              this.saveAntigravityThreads();
              this.emit('followup.cancelled', threadId, { id: args.id, threadId });
              return { cancelled: true, backend: 'antigravity' };
            }
            const before = { queue: meta.queue, deliveries: meta.deliveries };
            const cancelled = (entry) => ({ ...entry, state: 'cancelled', stateVersion: Math.max(Date.now(), (entry.stateVersion || 0) + 1) });
            meta.queue = (meta.queue || []).filter((entry) => entry.id !== args.id);
            meta.deliveries = (meta.deliveries || []).map((entry) => entry.id === args.id ? cancelled(entry) : entry);
            if (queued && !delivery) meta.deliveries.push(cancelled(queued));
            try { this.saveAntigravityThreads({ required: true }); } catch (error) { Object.assign(meta, before); throw error; }
            this.releaseFollowupAttachments?.(queued || delivery);
          }
          this.emit('followup.cancelled', threadId, { id: args.id, threadId });
          return { cancelled: true, backend: 'antigravity' };
        });
      }
      // The phone's waiting card (shared with Claude): answer Antigravity's question.
      case 'claude.desktop.answer': {
        const waiting = meta?.waiting;
        if (!waiting || waiting.kind !== 'question') throw new Error(SEND_ERRORS.no_question);
        if (args.requestId && waiting.requestId && args.requestId !== waiting.requestId) throw new Error(SEND_ERRORS.no_question);
        const answers = Array.isArray(args.answers) ? args.answers.map((answer) => ({
          labels: (Array.isArray(answer?.labels) ? answer.labels : []).map(String), other: String(answer?.other || '').trim(),
        })) : (args.choice ? [{ labels: [String(args.choice)], other: '' }] : []);
        if (!answers.length || answers.some((answer) => !answer.labels.length && !answer.other)) throw new Error(SEND_ERRORS.bad_answer);
        const result = await this.runAntigravitySend(threadId, 'answer', JSON.stringify({ answers }));
        if (!result.ok) throw new Error(SEND_ERRORS[result.reason] || `回答失败：${result.reason}`);
        setTimeout(() => this.pollAntigravity().catch((error) => this.log(error)), 1_500).unref?.();
        return { ok: true, answered: true, backend: 'antigravity' };
      }
      case 'turn.stop': {
        const result = await this.runAntigravitySend(threadId, 'stop');
        if (!result.ok) throw new Error(SEND_ERRORS[result.reason] || `停止失败：${result.reason}`);
        if (meta) { Object.assign(meta, { stoppedAt: Date.now(), sentAt: 0, running: false, waiting: null, notFullyIdle: false, summaryStatus: '', indexVersion: 0 }); this.announceAntigravityStatus(threadId, meta); this.saveAntigravityThreads(); }
        setTimeout(() => this.pollAntigravity().catch((error) => this.log(error)), 1_500).unref?.();
        return { stopped: true, backend: 'antigravity' };
      }
      // Reading the model and permission means opening the conversation in
      // Antigravity's window, so that happens only when the phone asks for a
      // fresh read (its settings dialog); opening a conversation gets the last one.
      case 'settings.get':
      case 'thread.settings.read': {
        if (!meta) throw new Error('没有找到这个反重力对话');
        if (args.refresh) {
          const read = await this.runAntigravitySend(threadId, 'settings');
          if (!read.ok) throw new Error(SEND_ERRORS[read.reason] || `读取反重力设置失败：${read.reason}`);
          const shaped = antigravityCatalog(read);
          if (!shaped.catalog) throw new Error('暂时无法读取反重力的可用模型，请重新打开模型设置。');
          this.saveAntigravityCatalogCache({ catalog: shaped.catalog, permissionCatalog: shaped.permissionCatalog });
          meta.settings = { ...shaped.settings, at: Date.now() };
          this.saveAntigravityThreads();
        }
        const cached = this.antigravityCatalogCache || {};
        const saved = meta.settings || {};
        const settings = { model: saved.model || '', effort: saved.effort || '', permissionMode: saved.permissionMode || '' };
        // The phone reads a command result's settings from its top level
        // (the thread.settings event nests them); give both.
        return { backend: 'antigravity', ...settings, settings, catalog: cached.catalog || null, permissionCatalog: cached.permissionCatalog || null, updatedAt: saved.at || 0 };
      }
      case 'settings.set': {
        if (!meta) throw new Error('没有找到这个反重力对话');
        const settings = args.settings || args;
        const key = String(settings.model || '').trim();
        const model = key.startsWith('antigravity/') ? key.slice('antigravity/'.length) : '';
        const level = String(settings.effort || '').trim();
        const permission = String(settings.permissionMode || '').trim();
        if (permission && !PRESETS.some((preset) => preset.value === permission)) throw new Error('反重力没有这个权限模式');
        if (!model && !permission) throw new Error(SEND_ERRORS.bad_settings);
        const result = await this.runAntigravitySend(threadId, 'set', JSON.stringify({ ...(model ? { model, level } : {}), ...(permission ? { permission } : {}) }));
        if (!result.ok) throw new Error(SEND_ERRORS[result.reason] || `反重力设置失败：${result.reason}`);
        const known = this.antigravityCatalogCache?.catalog?.groups?.[0]?.models?.map((row) => ({ name: row.id, levels: row.reasoning?.efforts?.map((effort) => effort.id) })) || [];
        const current = antigravityModelOf(known, result.model);
        meta.settings = { model: current.model ? `antigravity/${current.model}` : '', effort: current.effort, permissionMode: result.permission || '', at: Date.now() };
        this.saveAntigravityThreads();
        const now = { model: meta.settings.model, effort: meta.settings.effort, permissionMode: meta.settings.permissionMode };
        this.emit('thread.settings', threadId, { threadId, settings: now, updatedAt: meta.settings.at, source: 'antigravity' });
        const permissionName = PRESETS.find((preset) => preset.value === now.permissionMode)?.name;
        const label = [current.model && `${current.model}${current.effort ? ` ${LEVEL_NAMES[current.effort] || current.effort}` : ''}`, permissionName].filter(Boolean).join(' · ');
        return { saved: true, backend: 'antigravity', ...now, reason: `反重力已切换，下一条消息起生效${label ? `：${label}` : ''}` };
      }
      default:
        if (/^(followup\.|thread\.(archive|compact|fork|rollback|resume)|approval)/.test(payload.action || '')) throw new Error(ANTIGRAVITY_ACTIONS_UNSUPPORTED);
        return { backend: 'antigravity', readOnly: true };
    }
  },
};

function install(Connector) { Object.assign(Connector.prototype, methods); }

module.exports = { install, methods, ANTIGRAVITY_ACTIONS_UNSUPPORTED, antigravityCatalog, antigravityModelOf };
