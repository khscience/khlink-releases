const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

function validateLocalPath(value) {
  const input = String(value || '');
  if (!/^[a-zA-Z]:[\\/]/.test(input) || input.startsWith('\\\\') || input.startsWith('\\\\.\\') || input.startsWith('\\\\?\\UNC')) {
    throw new Error('只能打开本机磁盘上的文件');
  }
  // Windows opens `auth.json::$DATA`, `auth.json.` and `auth.json ` as
  // `auth.json`, so such spellings would slip past the name checks below.
  if (input.slice(2).includes(':')) throw new Error('不支持这种写法的路径（文件数据流）');
  if (input.split(/[\\/]+/).some((part) => part !== '.' && part !== '..' && /[. ]$/.test(part))) {
    throw new Error('不支持以点或空格结尾的路径');
  }
  // Links and junctions (e.g. ~/.codex or Downloads moved to another drive)
  // are followed: assertReadable checks the file they really lead to.
  return path.resolve(input);
}

// Author decision (2026-11-22): khLink is end-to-end encrypted between the
// owner's own PC and paired phone, so file.read no longer blocks paths by
// credential/key name heuristics (while still validating local drive paths and
// rejecting UNC / raw device / ADS / trailing dot-or-space paths).
function isSecretPath() {
  return false;
}

function assertReadable(resolved) {
  try { return fs.realpathSync.native(resolved); }
  catch { throw new Error('无法确认文件的真实路径，已拒绝读取'); }
}

function drives() {
  try {
    const out = execFileSync('cmd.exe', ['/d', '/s', '/c', 'wmic logicaldisk get name,drivetype /format:csv'], { encoding: 'utf8', windowsHide: true, timeout: 5_000 });
    return out.split(/\r?\n/).map((line) => line.trim().split(',')).filter((p) => p.length >= 3 && ['2','3'].includes(p[p.length - 2]))
      .map((p) => ({ name: p[p.length - 1], path: `${p[p.length - 1]}\\`, directory: true, size: 0, modifiedAt: 0 }));
  } catch { return ['C','D','E','F','G','H','I'].map((d) => `${d}:\\`).filter(fs.existsSync)
    .map((p) => ({ name: p.slice(0,2), path: p, directory: true, size: 0, modifiedAt: 0 })); }
}

function list(input, cursor = 0, limit = 100) {
  if (!input) return { items: drives(), nextCursor: null };
  const target = validateLocalPath(input);
  const directory = fs.opendirSync(target); const page = []; let seen = 0; let entry;
  try {
    while ((entry = directory.readSync()) !== null && page.length < limit + 1) {
      if (seen++ < cursor) continue;
      page.push(entry);
    }
  } finally { directory.closeSync(); }
  const hasMore = page.length > limit; if (hasMore) page.pop();
  const items = page.map((entry) => {
    const fullPath = path.join(target, entry.name); let stat = null;
    try { stat = fs.lstatSync(fullPath); } catch {}
    return { name: entry.name, path: fullPath, directory: entry.isDirectory(), link: entry.isSymbolicLink(), size: stat?.size || 0, modifiedAt: stat?.mtimeMs || 0 };
  });
  return { path: target, items, nextCursor: hasMore ? cursor + items.length : null };
}

function inbox(threadId) {
  let safe = String(threadId || 'unbound').replace(/[^a-zA-Z0-9._-]/g, '_');
  if (!safe || safe === '.' || safe === '..') safe = 'unbound';
  const dir = path.join(os.homedir(), 'FengzhuAgentBridgeUploads', safe); fs.mkdirSync(dir, { recursive: true }); return dir;
}

module.exports = { validateLocalPath, assertReadable, isSecretPath, list, inbox };
