# Read the visible sidebar without expanding, scrolling or focusing the window.
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'claude-desktop-native.ps1')
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
$uia = [System.Windows.Automation.AutomationElement]
$types = [System.Windows.Automation.ControlType]
$scope = [System.Windows.Automation.TreeScope]
$walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker
$chosen = Get-KhClaudeDesktopWindow
if (-not $chosen) { return }
$window = $uia::FromHandle($chosen.MainWindowHandle)
$textCondition = New-Object System.Windows.Automation.PropertyCondition($uia::ControlTypeProperty, $types::Text)
$buttonCondition = New-Object System.Windows.Automation.PropertyCondition($uia::ControlTypeProperty, $types::Button)
# Use Unicode escapes through JSON so Windows PowerShell 5 can read this UTF-8 file without a BOM.
$headings = ConvertFrom-Json '["Pinned","\u7f6e\u9876","\u5df2\u7f6e\u9876","\u7f6e\u9802","\u5df2\u7f6e\u9802","\u5df2\u91d8\u9078"]'
$names = [System.Windows.Automation.Condition[]]@($headings | ForEach-Object {
  [System.Windows.Automation.PropertyCondition]::new($uia::NameProperty, [string]$_)
})
$named = New-Object System.Windows.Automation.OrCondition(,$names)
$headerCondition = New-Object System.Windows.Automation.AndCondition($textCondition, $named)
$pinnedHeaders = @($window.FindAll($scope::Descendants, $headerCondition) | Where-Object {
  $walker.GetParent($_).Current.ClassName -match '\bdf-nav-scroll-box\b'
})
if ($pinnedHeaders.Count -ne 1) { return }
$labels = New-Object 'System.Collections.Generic.List[string]'
for ($row = $walker.GetNextSibling($pinnedHeaders[0]); $row; $row = $walker.GetNextSibling($row)) {
  if ($row.Current.ControlType -eq $types::Text) { break } # next section
  $buttons = if ($row.Current.ControlType -eq $types::Button) { $row } else { $row.FindAll($scope::Descendants, $buttonCondition) }
  foreach ($button in $buttons) {
    if ($button.Current.ClassName -like '*df-row-indent*' -and $button.Current.Name) { $labels.Add($button.Current.Name) }
  }
}
[Console]::WriteLine((ConvertTo-Json -InputObject $labels.ToArray() -Compress))
