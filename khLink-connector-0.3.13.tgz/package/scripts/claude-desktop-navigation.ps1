# Safe, read-only identity checks used by Claude Desktop send navigation.
# Never accept a title alone after clicking the sidebar: two sessions can share
# a title. The actual Code document URL must name the requested local session.
function Get-KhSessionIdFromUrl([string]$url) {
  if ($url -match '^https://claude\.ai/(?:epitaxy|code|claude-code-desktop)/(local_[0-9a-f-]{36})(?:[/?#]|$)') { return $Matches[1] }
  return $null
}
function Find-KhFocusedSessionInLogText([string]$text) {
  if (-not $text) { return @{ found = $false; sessionId = $null } }
  $lines = $text -split "`r?`n"
  for ($i = $lines.Length - 1; $i -ge 0; $i--) {
    $line = $lines[$i]
    if (-not $line) { continue }
    if ($line -match 'LocalSessions\.setFocusedSession:\s*sessionId=(local_[0-9a-f-]{36}|null)(?:\s|$)') {
      $val = $Matches[1]
      return @{ found = $true; sessionId = $(if ($val -eq 'null') { $null } else { $val }) }
    }
    if ($line -match '\[info\]\s+Starting app\b') {
      return @{ found = $true; sessionId = $null }
    }
  }
  return @{ found = $false; sessionId = $null }
}
function Get-KhMainLogFocusedSession([string]$logPath = '') {
  if (-not $logPath -and (Get-Command Desktop-LogPath -ErrorAction SilentlyContinue)) {
    try { $logPath = [string](Desktop-LogPath) } catch { $logPath = '' }
  }
  if (-not $logPath -or -not (Test-Path -LiteralPath $logPath -PathType Leaf)) { return $null }
  try {
    $share = [IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete
    $fs = [IO.FileStream]::new($logPath, [IO.FileMode]::Open, [IO.FileAccess]::Read, $share)
    try {
      $len = $fs.Length
      if ($len -le 0) { return $null }
      foreach ($windowBytes in 65536, 524288, 2097152) {
        $readLen = [int][Math]::Min($len, [long]$windowBytes)
        $offset = $len - $readLen
        $fs.Seek($offset, [IO.SeekOrigin]::Begin) | Out-Null
        $buf = New-Object byte[] $readLen
        $got = 0
        while ($got -lt $readLen) {
          $n = $fs.Read($buf, $got, $readLen - $got)
          if ($n -le 0) { break }
          $got += $n
        }
        if ($got -le 0) { return $null }
        $chunk = [Text.Encoding]::UTF8.GetString($buf, 0, $got)
        if ($offset -gt 0) {
          $nl = $chunk.IndexOf("`n")
          if ($nl -ge 0) { $chunk = $chunk.Substring($nl + 1) }
        }
        $hit = Find-KhFocusedSessionInLogText $chunk
        if ($hit.found -or $offset -eq 0) { return $hit.sessionId }
      }
    } finally { $fs.Dispose() }
  } catch { return $null }
  return $null
}
function Get-KhSessionTitleFromHeaderButton([string]$name) {
  if (-not $name) { return $null }
  $loadingSuffix = ', rename session, rename available once the chat has loaded'
  if ($name.EndsWith($loadingSuffix, [StringComparison]::Ordinal)) {
    return $name.Substring(0, $name.Length - $loadingSuffix.Length)
  }
  $renameSuffix = ', rename session'
  if ($name.EndsWith($renameSuffix, [StringComparison]::Ordinal)) {
    return $name.Substring(0, $name.Length - $renameSuffix.Length)
  }
  return $null
}
function Get-KhSessionTitleFromMoreOptions([string]$name) {
  if (-not $name) { return $null }
  $prefix = 'More options for '
  if ($name.StartsWith($prefix, [StringComparison]::Ordinal) -and $name.Length -gt $prefix.Length) {
    return $name.Substring($prefix.Length)
  }
  return $null
}
function Test-KhSessionIdentity([string]$visibleUrl, [string]$sessionId, [string]$shown, [string]$expected, [string]$logFocusedId = '') {
  $norm = { param($value) ([string]$value -replace '\s+', ' ').Trim() }
  $logId = if ($logFocusedId -match '^local_[0-9a-f-]{36}$') { $logFocusedId } else { $null }
  if ($logId -and $logId -cne $sessionId) { return $false }
  if ($shown -and $expected -and ((& $norm $shown) -cne (& $norm $expected))) { return $false }
  if ($logId -ceq $sessionId) { return $true }
  $urlId = Get-KhSessionIdFromUrl $visibleUrl
  if ($urlId) {
    if ($urlId -cne $sessionId) { return $false }
    return $true
  }
  if ($shown -and $expected) { return ((& $norm $shown) -ceq (& $norm $expected)) }
  return $false
}
function Test-KhSidebarIdentity([string]$visibleUrl, [string]$sessionId, [string]$shown, [string]$expected, [string]$logFocusedId = '') {
  $norm = { param($value) ([string]$value -replace '\s+', ' ').Trim() }
  if (-not $expected) { return $false }
  if ($shown -and ((& $norm $shown) -cne (& $norm $expected))) { return $false }
  $logId = if ($logFocusedId -match '^local_[0-9a-f-]{36}$') { $logFocusedId } else { $null }
  if ($logId) { return ($logId -ceq $sessionId) }
  if ((Get-KhSessionIdFromUrl $visibleUrl) -cne $sessionId) { return $false }
  return $true
}
function Get-KhUniqueAutomationElements($elements) {
  # Claude can expose nested accessibility nodes both named Sidebar. Walking
  # both returns the very same session button twice; only distinct UIA runtime
  # IDs count as different sessions. Fail closed if an ID is unavailable.
  $seen = @{}
  foreach ($element in $elements) {
    try {
      $id = @($element.GetRuntimeId())
      if (-not $id.Count) { return @() }
      $key = $id -join ','
      if (-not $seen.ContainsKey($key)) { $seen[$key] = $element }
    } catch { return @() }
  }
  return @($seen.Values)
}
function Select-KhSidebarButton($buttons, [string]$title) {
  $norm = { param($value) ([string]$value -replace '\s+', ' ').Trim() }
  $wanted = & $norm $title
  if (-not $wanted) { return $null }
  $enabled = @($buttons | Where-Object { try { $_.Current.IsEnabled } catch { $false } })
  $matches = @($enabled | Where-Object { try { (& $norm $_.Current.Name) -ceq $wanted } catch { $false } })
  if (-not $matches.Count) {
    # Electron can append accessibility status text such as "Unread response"
    # to the session button name. This only locates a candidate: the caller
    # must still check the actual document URL and header before sending.
    $prefix = $wanted + ' '
    $matches = @($enabled | Where-Object {
      try { (& $norm $_.Current.Name).StartsWith($prefix, [StringComparison]::Ordinal) } catch { $false }
    })
  }
  $matches = @(Get-KhUniqueAutomationElements $matches)
  if ($matches.Count -ne 1) { return $null }
  return $matches[0]
}

function Get-KhVisibleCodeUrl($window) {
  $uia = [System.Windows.Automation.AutomationElement]
  $cond = New-Object System.Windows.Automation.AndCondition(
    (New-Object System.Windows.Automation.PropertyCondition($uia::ControlTypeProperty, [System.Windows.Automation.ControlType]::Document)),
    (New-Object System.Windows.Automation.PropertyCondition($uia::AutomationIdProperty, 'RootWebArea')))
  $values = @()
  foreach ($doc in $window.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)) {
    try {
      $value = [string]$doc.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value
      if (Get-KhSessionIdFromUrl $value) { $values += $value }
    } catch { }
  }
  $unique = @($values | Select-Object -Unique)
  if ($unique.Count -eq 1) { return $unique[0] }
  return $null
}

# Read the active session header title without ever matching sidebar rows.
# Supports the legacy "<title>, rename session" button, the jointTrigger header
# ("More options for <title>" inside h2), and the 2026-11 dframe split header
# ("More options for <title>" adjacent to a sibling h2 heading of the same title).
function Get-KhHeaderSessionTitle($window) {
  if (-not $window) { return $null }
  $uia = [System.Windows.Automation.AutomationElement]
  $norm = { param($value) ([string]$value -replace '\s+', ' ').Trim() }
  $btnCond = New-Object System.Windows.Automation.PropertyCondition($uia::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)
  $allButtons = @($window.FindAll([System.Windows.Automation.TreeScope]::Descendants, $btnCond))
  foreach ($b in $allButtons) {
    try {
      $title = Get-KhSessionTitleFromHeaderButton ([string]$b.Current.Name)
      if ($title) { return $title }
    } catch { }
  }
  $walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker
  $isHeading = {
    param($el)
    if (-not $el) { return $false }
    $loc = [string]$el.Current.LocalizedControlType
    $cls = [string]$el.Current.ClassName
    return ($loc -eq 'heading' -or $cls -match '\bh[12]\b')
  }
  foreach ($b in $allButtons) {
    try {
      $candidate = Get-KhSessionTitleFromMoreOptions ([string]$b.Current.Name)
      if (-not $candidate) { continue }
      $wantNorm = & $norm $candidate
      $node = $b
      for ($depth = 0; $depth -lt 4 -and $node; $depth++) {
        $parent = $walker.GetParent($node)
        if (-not $parent) { break }
        if (& $isHeading $parent) { return $candidate }
        if ($depth -lt 2) {
          $sib = $walker.GetPreviousSibling($node)
          for ($s = 0; $s -lt 3 -and $sib; $s++) {
            if ((& $isHeading $sib) -and ((& $norm ([string]$sib.Current.Name)) -ceq $wantNorm)) { return $candidate }
            $sib = $walker.GetPreviousSibling($sib)
          }
        }
        $node = $parent
      }
    } catch { }
  }
  return $null
}

function Invoke-KhUniqueSidebarSession($window, [string]$title) {
  $uia = [System.Windows.Automation.AutomationElement]
  $bySidebarName = New-Object System.Windows.Automation.PropertyCondition($uia::NameProperty, 'Sidebar')
  $clickable = New-Object System.Windows.Automation.OrCondition(
    (New-Object System.Windows.Automation.PropertyCondition($uia::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)),
    (New-Object System.Windows.Automation.PropertyCondition($uia::ControlTypeProperty, [System.Windows.Automation.ControlType]::Hyperlink)))
  $buttons = @()
  $sidebars = @($window.FindAll([System.Windows.Automation.TreeScope]::Descendants, $bySidebarName))
  foreach ($sidebar in $sidebars) {
    foreach ($button in $sidebar.FindAll([System.Windows.Automation.TreeScope]::Descendants, $clickable)) { $buttons += $button }
  }
  $target = Select-KhSidebarButton $buttons $title
  if (-not $target) { return $false }
  try { $target.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke(); return $true } catch {
    if (Get-Command Trace-Navigation -ErrorAction SilentlyContinue) { Trace-Navigation ('sidebar-invoke-failed-{0}' -f $_.Exception.GetType().Name) }
    return $false
  }
}
