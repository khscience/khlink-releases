#!/bin/bash
# khLink connector for macOS: install, log in, run as a LaunchAgent.
#
#   ./khlink-macos.sh install   copy the connector package this script is in into
#                               ~/Library/Application Support/khLink/connector/app
#                               and install its Node dependencies
#   ./khlink-macos.sh login     log this Mac in to a khLink account (browser)
#   ./khlink-macos.sh start     run the connector now and at every login, and
#                               look for a newer connector every few hours
#   ./khlink-macos.sh update    install a newer connector now, if there is one
#   ./khlink-macos.sh autoupdate [on|off]
#   ./khlink-macos.sh stop      stop it and remove it from login items
#   ./khlink-macos.sh status    show whether it is running and its last log lines
#   ./khlink-macos.sh accessibility  check or prompt macOS Accessibility permission
#   ./khlink-macos.sh rebuild-helper rebuild and restart khLinkHelper.app
#   ./khlink-macos.sh uninstall [--purge]  stop it and delete the program; --purge
#                               also deletes this Mac's account data
#
# The connector stores its secrets sealed with a key in the login Keychain, so
# login and the connector itself run in the user's GUI session (a LaunchAgent),
# also when this script is started over SSH.
#
# With the khLink app (/Applications/khLink.app, the menu bar app from the
# .dmg) the app's own binary is the desktop-control helper, Node comes from
# ~/Library/Application Support/khLink/runtime, and `update` also updates the
# app. The app passes its location in KHLINK_APP; the script remembers it.
set -euo pipefail

LABEL=com.khlink.connector
HELPER_LABEL=com.khlink.helper
LOGIN_LABEL=com.khlink.login
UPDATE_LABEL=com.khlink.update
TRAY_LABEL=com.khlink.tray
UPDATE_EVERY=21600
KHLINK_HOME="$HOME/Library/Application Support/khLink"
BASE="$KHLINK_HOME/connector"
RUNTIME_NODE="$KHLINK_HOME/runtime/node/bin/node"
APP_RECORD="$BASE/app-bundle"
APP_BUNDLE_ID=vip.fengzhu.khlink
LEGACY_HELPER_APP="$KHLINK_HOME/khLinkHelper.app"
HELPER_APP="$LEGACY_HELPER_APP"
HELPER_BIN="$HELPER_APP/Contents/MacOS/khLinkHelper"
HELPER_BUNDLE_ID=vip.fengzhu.khlink.helper
APP="$BASE/app"
LOGS="$BASE/logs"
DATA="$HOME/Library/Application Support/FengzhuAgentBridge"
HELPER_SOCK="$DATA/helper.sock"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
HELPER_PLIST="$HOME/Library/LaunchAgents/$HELPER_LABEL.plist"
UPDATE_PLIST="$HOME/Library/LaunchAgents/$UPDATE_LABEL.plist"
TRAY_PLIST="$HOME/Library/LaunchAgents/$TRAY_LABEL.plist"
# The update agent runs this copy: the one inside the app is replaced by an update.
SELF="$BASE/khlink-macos.sh"
DOMAIN="gui/$(id -u)"
HERE="$(cd "$(dirname "$0")" && pwd)"

die() { echo "khLink: $*" >&2; exit 1; }
stamp() { echo "$(date '+%F %T') $*"; }

is_app_bundle() {
  [ -x "$1/Contents/MacOS/khLink" ] && [ "$(/usr/bin/defaults read "$1/Contents/Info" CFBundleIdentifier 2>/dev/null)" = "$APP_BUNDLE_ID" ]
}

# The khLink app this Mac uses, if any: the one that started us, the one
# recorded earlier, or the usual places.
app_bundle() {
  local b
  for b in "${KHLINK_APP:-}" "$(cat "$APP_RECORD" 2>/dev/null || true)" /Applications/khLink.app "$HOME/Applications/khLink.app"; do
    [ -n "$b" ] || continue
    case "$b" in */AppTranslocation/*|/Volumes/*) continue ;; esac
    if is_app_bundle "$b"; then
      if [ "$(cat "$APP_RECORD" 2>/dev/null || true)" != "$b" ]; then mkdir -p "$BASE"; printf '%s\n' "$b" > "$APP_RECORD"; fi
      echo "$b"; return 0
    fi
  done
  return 1
}

# The desktop-control helper: the khLink app's binary, or the helper built
# from source by earlier command-line installs.
if APP_BUNDLE="$(app_bundle)"; then
  HELPER_APP="$APP_BUNDLE"; HELPER_BIN="$APP_BUNDLE/Contents/MacOS/khLink"; HELPER_BUNDLE_ID="$APP_BUNDLE_ID"
else
  APP_BUNDLE=""
fi

# bootout returns before the job is gone; bootstrapping right after fails
# with "5: Input/output error".
unload() {
  launchctl bootout "$DOMAIN/$1" 2>/dev/null || return 0
  local i; for i in $(seq 1 30); do launchctl print "$DOMAIN/$1" >/dev/null 2>&1 || return 0; sleep 0.5; done
}
load() {
  local i; for i in 1 2 3 4 5; do launchctl bootstrap "$DOMAIN" "$1" 2>/dev/null && return 0; sleep 1; done
  launchctl bootstrap "$DOMAIN" "$1"
}

find_node() {
  local candidates=() n
  # The Node the khLink app installed comes first: it is the one tested with this connector.
  [ -x "$RUNTIME_NODE" ] && candidates+=("$RUNTIME_NODE")
  command -v node >/dev/null 2>&1 && candidates+=("$(command -v node)")
  for n in /opt/homebrew/bin/node /usr/local/bin/node "$HOME"/.local/node-*/bin/node "$HOME"/.nvm/versions/node/*/bin/node "$HOME"/.volta/bin/node; do
    [ -x "$n" ] && candidates+=("$n")
  done
  for n in ${candidates[@]+"${candidates[@]}"}; do
    local major; major="$("$n" -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)"
    if [ "$major" -ge 22 ]; then echo "$n"; return 0; fi
  done
  return 1
}

agent_path() {
  # Where agent CLIs are usually installed; a LaunchAgent gets only /usr/bin:/bin.
  local node_dir; node_dir="$(dirname "$1")"
  local npm_prefix; npm_prefix="$("$node_dir/npm" prefix -g 2>/dev/null || true)"
  local p="$node_dir"
  for d in "$HOME/.local/bin" "$HOME/.claude/local" "$HOME/.local/npm/bin" "$HOME/.npm-global/bin" "${npm_prefix:+$npm_prefix/bin}" /opt/homebrew/bin /usr/local/bin /usr/bin /bin /usr/sbin /sbin; do
    [ -n "$d" ] && [ -d "$d" ] && case ":$p:" in *":$d:"*) ;; *) p="$p:$d" ;; esac
  done
  echo "$p"
}

write_plist() { # label, plist path, mode (keep | once | every:SECONDS), program args...
  # The program is Node unless the first argument is /bin/bash.
  local label="$1" file="$2" mode="$3"; shift 3
  local node; node="$(find_node)" || die "需要 Node.js 22 或更新版本"
  local args="" a
  [ "${1:-}" = /bin/bash ] || set -- "$node" "$@"
  for a in "$@"; do args="$args<string>$(printf '%s' "$a" | sed 's/&/\&amp;/g; s/</\&lt;/g')</string>"; done
  local extra=""
  case "$mode" in
    keep) extra='<key>RunAtLoad</key><true/><key>KeepAlive</key><true/><key>ThrottleInterval</key><integer>20</integer><key>ProcessType</key><string>Interactive</string>' ;;
    once) extra='<key>RunAtLoad</key><true/>' ;;
    every:*) extra="<key>StartInterval</key><integer>${mode#every:}</integer><key>ProcessType</key><string>Background</string>" ;;
  esac
  mkdir -p "$(dirname "$file")" "$LOGS"
  cat > "$file" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$label</string>
  <key>ProgramArguments</key><array>$args</array>
  <key>WorkingDirectory</key><string>$APP</string>
  <key>EnvironmentVariables</key><dict><key>PATH</key><string>$(agent_path "$node")</string><key>NODE_NO_WARNINGS</key><string>1</string><key>KHLINK_HELPER_BIN</key><string>$(printf '%s' "$HELPER_BIN" | sed 's/&/\&amp;/g; s/</\&lt;/g')</string></dict>
  $extra
  <key>StandardOutPath</key><string>$LOGS/$label.log</string>
  <key>StandardErrorPath</key><string>$LOGS/$label.log</string>
</dict></plist>
EOF
}

# A rename, so an update run of the old copy keeps reading the file it opened.
install_self() { cp "$APP/scripts/khlink-macos.sh" "$SELF.new" && chmod 755 "$SELF.new" && mv -f "$SELF.new" "$SELF"; }

install_helper() {
  local src="${1:-}"
  # The khLink app is the helper; nothing to build.
  [ -n "$APP_BUNDLE" ] && return 0
  # Preserve existing khLinkHelper.app across routine connector updates so macOS
  # Accessibility TCC trust (ad-hoc CDHash) is not invalidated.
  if [ -x "$HELPER_BIN" ] && [ "${2:-}" != "--force" ]; then return 0; fi
  local adapter_dir=""
  for d in "$src/../macos-adapter" "$src/macos-adapter" "$APP/macos-adapter"; do
    if [ -f "$d/build.sh" ] && [ -f "$d/Sources/main.swift" ]; then adapter_dir="$d"; break; fi
  done
  if [ -n "$adapter_dir" ] && command -v swiftc >/dev/null 2>&1; then
    bash "$adapter_dir/build.sh" "$(dirname "$HELPER_APP")" >/dev/null 2>&1 && echo "已安装 khLink Helper 到 $HELPER_APP" || echo "警告：khLink Helper 编译失败（不影响命令行连接模式）"
  fi
}

write_helper_plist() {
  mkdir -p "$(dirname "$HELPER_PLIST")" "$LOGS" "$DATA"
  cat > "$HELPER_PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$HELPER_LABEL</string>
  <key>ProgramArguments</key><array>
    <string>$HELPER_BIN</string>
    <string>--socket</string>
    <string>$HELPER_SOCK</string>
  </array>
  <key>AssociatedBundleIdentifiers</key><array>
    <string>$HELPER_BUNDLE_ID</string>
  </array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ThrottleInterval</key><integer>10</integer>
  <key>ProcessType</key><string>Interactive</string>
  <key>StandardOutPath</key><string>$LOGS/$HELPER_LABEL.log</string>
  <key>StandardErrorPath</key><string>$LOGS/$HELPER_LABEL.log</string>
</dict></plist>
EOF
}

start_helper() {
  [ -x "$HELPER_BIN" ] || return 0
  write_helper_plist
  unload "$HELPER_LABEL"
  load "$HELPER_PLIST"
}

# One request to the helper over its socket. Node, not python3: a Mac without
# the developer tools answers python3 with an install dialog.
helper_rpc() {
  local action="$1" node
  [ -S "$HELPER_SOCK" ] || return 1
  node="$(find_node)" || return 1
  "$node" -e '
    const s = require("net").createConnection(process.argv[1]); let d = "";
    const t = setTimeout(() => process.exit(1), 5000);
    s.on("connect", () => s.write(JSON.stringify({ id: 1, request: { action: process.argv[2] } }) + "\n"));
    s.on("data", (c) => { d += c; if (d.includes("\n")) { console.log(d.trim()); clearTimeout(t); s.end(); } });
    s.on("error", () => process.exit(1));' "$HELPER_SOCK" "$action" 2>/dev/null
}

# The helper answers on its socket within `seconds`.
wait_helper() {
  local i; for i in $(seq 1 "$1"); do helper_rpc ax_status >/dev/null && return 0; sleep 1; done; return 1
}

# The menu bar app starts at every login. Only written here: loading it now
# would start a second copy next to the one that may be running.
write_tray_plist() {
  [ -n "$APP_BUNDLE" ] || return 0
  mkdir -p "$(dirname "$TRAY_PLIST")"
  cat > "$TRAY_PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$TRAY_LABEL</string>
  <key>ProgramArguments</key><array><string>$HELPER_BIN</string><string>--background</string></array>
  <key>AssociatedBundleIdentifiers</key><array><string>$APP_BUNDLE_ID</string></array>
  <key>RunAtLoad</key><true/>
  <key>LimitLoadToSessionType</key><string>Aqua</string>
  <key>ProcessType</key><string>Interactive</string>
</dict></plist>
EOF
}

# The menu bar app: the bundle's binary with no argument or a tray one
# (--background at login and after updates); the helper roles take others.
tray_pids() { [ -n "$APP_BUNDLE" ] && pgrep -f "^$APP_BUNDLE/Contents/MacOS/khLink( --(background|show|snapshot))?\$" 2>/dev/null || true; }

cmd_install() {
  local src="${1:-$(dirname "$HERE")}"
  [ -f "$src/package.json" ] && [ -d "$src/src" ] || die "找不到连接器程序：$src"
  local node; node="$(find_node)" || die "需要 Node.js 22 或更新版本（https://nodejs.org）"
  mkdir -p "$APP"
  rm -rf "$APP/src" "$APP/scripts"
  (cd "$src" && tar cf - package.json src scripts $( [ -d native ] && echo native ) $( [ -d dsh-bridge ] && echo dsh-bridge ) $( [ -d macos-adapter ] && echo macos-adapter )) | (cd "$APP" && tar xf -)
  if [ -d "$src/node_modules" ]; then
    # The khLink app carries the dependencies: no npm, no network.
    rm -rf "$APP/node_modules"; (cd "$src" && tar cf - node_modules) | (cd "$APP" && tar xf -)
  else
    (cd "$APP" && PATH="$(dirname "$node"):$PATH" npm install --omit=dev --no-audit --no-fund >/dev/null)
  fi
  install_self
  install_helper "$src"
  echo "已安装 khLink 连接器 $(cd "$APP" && "$node" -p 'require("./package.json").version') 到 $APP"
}

cmd_login() {
  [ -f "$APP/src/cli.js" ] || die "请先运行 install"
  local file="$BASE/$LOGIN_LABEL.plist" log="$LOGS/$LOGIN_LABEL.log"
  write_plist "$LOGIN_LABEL" "$file" once src/cli.js login "$@"
  rm -f "$log"; : > "$log"
  unload "$LOGIN_LABEL"
  load "$file"
  # Follow the login until it ends.
  tail -n +1 -f "$log" &
  local tailer=$!
  # Right after bootstrap the job may still be "spawn scheduled": wait until it has run and exited
  # (state "not running"), not merely until it is not "running" yet. Give up after 15 minutes.
  local waited=0 state
  while [ "$waited" -lt 900 ]; do
    state="$(launchctl print "$DOMAIN/$LOGIN_LABEL" 2>/dev/null | awk -F' = ' '/^\tstate = /{print $2; exit}' || true)"
    [ -z "$state" ] || [ "$state" = "not running" ] && break
    sleep 1; waited=$((waited + 1))
  done
  sleep 1; kill "$tailer" 2>/dev/null || true
  launchctl bootout "$DOMAIN/$LOGIN_LABEL" 2>/dev/null || true
  rm -f "$file"
  grep -q '连接器已配置' "$log" || die "登录没有完成"
  if launchctl print "$DOMAIN/$LABEL" >/dev/null 2>&1; then launchctl kickstart -k "$DOMAIN/$LABEL"; echo "已重启连接器"; fi
}

cmd_start() {
  [ -f "$APP/src/cli.js" ] || die "请先运行 install"
  [ -f "$DATA/config.json" ] || die "请先运行 login"
  start_helper
  write_plist "$LABEL" "$PLIST" keep src/cli.js start
  unload "$LABEL"
  # launchd only appends to the connector's output log (stopped right now;
  # helper and update logs stay open in their processes). Dated logs rotate.
  local f
  for f in "$LOGS/$LABEL.log"; do
    [ -f "$f" ] && [ "$(wc -c < "$f")" -gt 5242880 ] && { tail -c 1048576 "$f" > "$f.tmp" && mv "$f.tmp" "$f"; } || true
  done
  load "$PLIST"
  echo "khLink 连接器已启动，并会在登录 Mac 时自动运行"
  if [ -n "$APP_BUNDLE" ]; then
    write_tray_plist
    # The app took over desktop control; the old separately built helper is not used any more.
    [ -d "$LEGACY_HELPER_APP" ] && rm -rf "$LEGACY_HELPER_APP" && echo "已改用 khLink 应用做桌面控制助手"
  fi
  [ -f "$BASE/autoupdate-off" ] || autoupdate_on
}

autoupdate_on() {
  install_self
  write_plist "$UPDATE_LABEL" "$UPDATE_PLIST" "every:$UPDATE_EVERY" /bin/bash "$SELF" update --auto
  unload "$UPDATE_LABEL"
  load "$UPDATE_PLIST"
  echo "已开启自动更新（每 $((UPDATE_EVERY / 3600)) 小时检查一次）"
}

autoupdate_off() { unload "$UPDATE_LABEL"; rm -f "$UPDATE_PLIST"; }

cmd_autoupdate() {
  case "${1:-}" in
    on) rm -f "$BASE/autoupdate-off"; autoupdate_on ;;
    off) : > "$BASE/autoupdate-off"; autoupdate_off; echo "已关闭自动更新，需要时运行 update 手动更新" ;;
    *) if [ -f "$UPDATE_PLIST" ]; then echo "自动更新：开"; else echo "自动更新：关"; fi ;;
  esac
}

# "<version> <pid>" of the connector, from a status file written within the last 15 seconds.
running_connector() {
  "$1" -e 'try { const s = JSON.parse(require("fs").readFileSync(process.argv[1], "utf8")); if (Date.now() - s.updatedAt <= 15000) console.log(`${s.version || ""} ${s.connectorPid || ""}`); } catch {}' "$DATA/status.json"
}

wait_version() { # node, version, seconds, pid of the connector it replaces
  local i now; for i in $(seq 1 "$3"); do
    now="$(running_connector "$1")"
    [ "${now% *}" = "$2" ] && [ "${now#* }" != "${4:-}" ] && return 0
    sleep 1
  done; return 1
}

# The running connector takes the new code: its supervisor swaps only the
# connector process, so a Codex turn in progress keeps running.
reload_connector() {
  if launchctl print "$DOMAIN/$LABEL" 2>/dev/null | grep -q 'state = running'; then
    : > "$DATA/reload.request"
  else
    launchctl kickstart "$DOMAIN/$LABEL" 2>/dev/null || load "$PLIST"
  fi
}

UPDATE_NAMES="package.json src scripts native dsh-bridge macos-adapter"
WORK="$BASE/update"

cmd_update() {
  local auto=false force="" a
  for a in "$@"; do case "$a" in --auto) auto=true ;; --force) force=--force ;; esac; done
  [ -f "$APP/src/cli.js" ] || die "请先运行 install"
  local node; node="$(find_node)" || die "需要 Node.js 22 或更新版本"
  local work="$WORK"
  mkdir -p "$work"
  # One update at a time (the timer and a manual run); a lock older than 30 minutes is stale.
  if ! mkdir "$work/lock" 2>/dev/null; then
    [ -n "$(find "$work/lock" -maxdepth 0 -mmin +30 2>/dev/null)" ] || { stamp "已有一次更新在进行"; stamp "检查结束"; return 0; }
    rm -rf "$work/lock"; mkdir "$work/lock"
  fi
  # The menu bar app waits for the last line.
  trap 'rm -rf "$WORK/lock"; stamp "检查结束"' EXIT
  local rc=0
  update_connector || rc=$?
  update_app || true
  $auto && return 0
  return $rc
}

update_connector() {
  local result
  result="$(cd "$APP" && "$node" src/cli.js update-stage --app "$APP" --work "$work" $force 2>&1 | tail -n 1)" || true
  field() { "$node" -e 'try { const v = JSON.parse(process.argv[1])[process.argv[2]]; console.log(v === undefined ? "" : String(v)); } catch { console.log(""); }' "$result" "$1"; }
  local available version staged deps busy installed
  available="$(field available)"; version="$(field version)"; staged="$(field staged)"
  deps="$(field depsChanged)"; busy="$(field busy)"; installed="$(field installed)"
  if [ -z "$available" ]; then stamp "检查更新失败：$result"; $auto && return 0; return 1; fi
  if [ "$available" != true ]; then stamp "已是最新版本 $installed"; return 0; fi
  if [ -n "$busy" ]; then stamp "有新版本 $version，$busy"; return 0; fi
  [ -d "$staged" ] || die "更新包不存在：$staged"
  stamp "更新 $installed → $version"

  local previous="$work/previous" n ok=true
  rm -rf "$previous"; mkdir -p "$previous"
  for n in $UPDATE_NAMES; do [ -e "$APP/$n" ] && mv "$APP/$n" "$previous/$n"; done
  for n in $UPDATE_NAMES; do [ -e "$staged/$n" ] && mv "$staged/$n" "$APP/$n"; done
  rm -rf "$staged"
  if [ "$deps" = true ]; then
    cp -R "$APP/node_modules" "$previous/node_modules" 2>/dev/null || true
    (cd "$APP" && PATH="$(dirname "$node"):$PATH" npm install --omit=dev --no-audit --no-fund >/dev/null 2>&1) || ok=false
  fi
  # Not started with `start` (no LaunchAgent): nothing to restart or wait for.
  local old_pid; old_pid="$(running_connector "$node")"; old_pid="${old_pid#* }"
  if $ok && [ -f "$PLIST" ]; then reload_connector; wait_version "$node" "$version" 90 "$old_pid" || ok=false; fi
  if $ok; then
    install_self
    if ! [ -x "$HELPER_BIN" ]; then
      install_helper "$APP" || true
      start_helper || true
    fi
    rm -rf "$previous"
    stamp "已更新到 $version"
    return 0
  fi

  # The new connector did not come up: put the previous one back and restart it.
  stamp "$version 没有正常启动，恢复 $installed"
  for n in $UPDATE_NAMES node_modules; do
    if [ -e "$previous/$n" ]; then rm -rf "${APP:?}/$n"; mv "$previous/$n" "$APP/$n"
    elif [ "$n" != node_modules ]; then rm -rf "${APP:?}/$n"; fi
  done
  rm -rf "$previous"
  if [ -f "$PLIST" ]; then
    unload "$LABEL"; load "$PLIST"
    wait_version "$node" "$installed" 90 || stamp "$installed 也还没上线，请运行 status 查看"
  fi
  return 1
}

# Menu bar app update: the signed manifest's `macApp` package, checked by
# update-stage (SHA-256, same bundle id and signing requirement as the app in
# place). The helper restarts from the new app; when Accessibility was granted
# before and the new helper is not trusted any more, the old app goes back.
update_app() {
  [ -n "$APP_BUNDLE" ] || return 0
  local result field_v
  result="$(cd "$APP" && "$node" src/cli.js update-stage --mac-app "$APP_BUNDLE" --work "$WORK" $force 2>&1 | tail -n 1)" || true
  field_v() { "$node" -e 'try { const v = JSON.parse(process.argv[1])[process.argv[2]]; console.log(v === undefined ? "" : String(v)); } catch { console.log(""); }' "$result" "$1"; }
  local available version staged installed
  available="$(field_v available)"; version="$(field_v version)"; staged="$(field_v staged)"; installed="$(field_v installed)"
  if [ -z "$available" ]; then stamp "菜单程序检查更新失败：$result"; return 1; fi
  if [ "$available" != true ]; then stamp "菜单程序已是最新版本 $installed"; return 0; fi
  [ -d "$staged" ] || { stamp "菜单程序更新包不存在：$staged"; return 1; }
  local dir; dir="$(dirname "$APP_BUNDLE")"
  if ! [ -w "$dir" ] || ! [ -w "$APP_BUNDLE" ]; then stamp "菜单程序有新版本 $version，但没有权限写入 $dir"; rm -rf "$staged"; return 1; fi
  stamp "更新菜单程序 $installed → $version"

  local had_ax=false tray_was_running=false
  helper_rpc ax_status 2>/dev/null | grep -q '"axTrusted":true' && had_ax=true
  [ -n "$(tray_pids)" ] && tray_was_running=true
  local previous="$WORK/previous-app"
  rm -rf "$previous"; mkdir -p "$previous"
  unload "$HELPER_LABEL"
  [ -n "$(tray_pids)" ] && kill $(tray_pids) 2>/dev/null || true
  mv "$APP_BUNDLE" "$previous/khLink.app"
  mv "$staged" "$APP_BUNDLE"
  /usr/bin/xattr -dr com.apple.quarantine "$APP_BUNDLE" 2>/dev/null || true
  local ok=true
  load "$HELPER_PLIST" 2>/dev/null || ok=false
  if $ok && ! wait_helper 15; then ok=false; stamp "新菜单程序的桌面控制助手没有响应"; fi
  if $ok && $had_ax && ! helper_rpc ax_status | grep -q '"axTrusted":true'; then ok=false; stamp "更新后辅助功能授权失效"; fi
  if $ok; then
    rm -rf "$previous"
    $tray_was_running && /usr/bin/open -n "$APP_BUNDLE" --args --background 2>/dev/null || true
    stamp "菜单程序已更新到 $version$($had_ax && echo "，辅助功能授权保持有效")"
    return 0
  fi
  stamp "恢复菜单程序 $installed"
  unload "$HELPER_LABEL"
  rm -rf "$APP_BUNDLE"; mv "$previous/khLink.app" "$APP_BUNDLE"; rm -rf "$previous"
  load "$HELPER_PLIST" 2>/dev/null || true
  $tray_was_running && /usr/bin/open -n "$APP_BUNDLE" --args --background 2>/dev/null || true
  return 1
}

cmd_stop() {
  autoupdate_off
  if launchctl print "$DOMAIN/$HELPER_LABEL" >/dev/null 2>&1; then unload "$HELPER_LABEL"; fi
  rm -f "$HELPER_PLIST" "$HELPER_SOCK"
  if launchctl print "$DOMAIN/$LABEL" >/dev/null 2>&1; then unload "$LABEL"; echo "已停止 khLink 连接器"; else echo "khLink 连接器没有在运行"; fi
  rm -f "$PLIST"
}

cmd_logout() {
  # Stop the connector and forget this Mac's login; the app and the helper stay installed.
  if launchctl print "$DOMAIN/$LABEL" >/dev/null 2>&1; then unload "$LABEL"; fi
  rm -f "$PLIST" "$DATA/config.json" "$DATA/status.json"
  echo "已退出登录，这台 Mac 不再接收手机消息；需要时重新登录"
}

cmd_accessibility() {
  [ -x "$HELPER_BIN" ] || die "未安装 khLink 应用或桌面控制助手"
  if ! [ -S "$HELPER_SOCK" ]; then
    start_helper
    sleep 1.2
  fi
  local resp=""
  resp="$(helper_rpc prompt_accessibility || true)"
  if echo "$resp" | grep -q '"axTrusted":true'; then
    echo "macOS 辅助功能权限：已授权（$(basename "$HELPER_APP" .app)）"
    return 0
  fi
  echo "已触发 macOS 辅助功能授权提示，并为你打开了「系统设置 → 隐私与安全性 → 辅助功能」。"
  echo "请在列表里打开 $(basename "$HELPER_APP" .app) 旁边的开关；列表里没有它时，把 Finder 中选中的 $(basename "$HELPER_APP") 拖进去。"
  echo "路径：$HELPER_APP"
  open -R "$HELPER_APP" >/dev/null 2>&1 || true
  open "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility" >/dev/null 2>&1 || true
}

cmd_rebuild_helper() {
  [ -z "$APP_BUNDLE" ] || die "已使用 khLink 应用（$APP_BUNDLE）做桌面控制助手，它随应用自动更新，不需要重新编译"
  [ -d "$APP/macos-adapter" ] || die "找不到 macos-adapter 源码：$APP/macos-adapter"
  install_helper "$APP" --force
  start_helper
  echo "已重新编译并重启 khLink Helper；如之前已授权辅助功能，请运行 ./khlink-macos.sh accessibility 确认或重新勾选。"
}

cmd_status() {
  if launchctl print "$DOMAIN/$LABEL" 2>/dev/null | grep -E 'state = |pid = ' | head -2; then :; else echo "未运行"; fi
  if [ -n "$APP_BUNDLE" ]; then
    echo "khLink 应用：$APP_BUNDLE $(/usr/bin/defaults read "$APP_BUNDLE/Contents/Info" CFBundleShortVersionString 2>/dev/null)$([ -n "$(tray_pids)" ] && echo "，菜单栏图标在运行")"
  fi
  if [ -x "$HELPER_BIN" ]; then
    local ax_resp=""
    ax_resp="$(helper_rpc ax_status || true)"
    if echo "$ax_resp" | grep -q '"axTrusted":true'; then
      echo "桌面控制助手：已运行，辅助功能已授权"
    elif [ -S "$HELPER_SOCK" ]; then
      echo "桌面控制助手：已运行，辅助功能未授权（运行 ./khlink-macos.sh accessibility 开启）"
    else
      echo "桌面控制助手：已安装，未启动"
    fi
  fi
  cmd_autoupdate
  [ -f "$LOGS/$UPDATE_LABEL.log" ] && tail -n 3 "$LOGS/$UPDATE_LABEL.log"
  local log; log="$(ls -t "$DATA/logs"/connector-*.log 2>/dev/null | head -1 || true)"
  [ -n "$log" ] && tail -n 8 "$log"
}

cmd_uninstall() {
  local purge=false a
  for a in "$@"; do [ "$a" = --purge ] && purge=true; done
  cmd_stop
  unload "$TRAY_LABEL"; rm -f "$TRAY_PLIST"
  rm -rf "$APP" "$BASE/update" "$SELF" "$LEGACY_HELPER_APP" "$KHLINK_HOME/runtime" "$APP_RECORD"
  # Started from the khLink app: it moves itself to the Trash. From the command line: do it here.
  if [ -n "$APP_BUNDLE" ] && [ -z "${KHLINK_APP:-}" ]; then
    [ -n "$(tray_pids)" ] && kill $(tray_pids) 2>/dev/null || true
    mv "$APP_BUNDLE" "$HOME/.Trash/khLink-$(date +%s).app" 2>/dev/null && echo "已把 khLink 应用移到废纸篓"
  fi
  if $purge; then
    rm -rf "$DATA" "$KHLINK_HOME"
    /usr/bin/security delete-generic-password -s khLink >/dev/null 2>&1 || true
    echo "已删除程序和这台 Mac 的 khLink 账号数据"
  else
    echo "已删除程序；账号数据保留在 ~/Library/Application Support/FengzhuAgentBridge"
  fi
}

case "${1:-}" in
  install) shift; cmd_install "$@" ;;
  login) shift; cmd_login "$@" ;;
  start) cmd_start ;;
  stop) cmd_stop ;;
  logout) cmd_logout ;;
  # The khLink window's "开机启动": the menu bar app at login (the connector always starts).
  trayautostart) case "${2:-}" in on) write_tray_plist; echo on ;; off) rm -f "$TRAY_PLIST"; echo off ;; *) [ -f "$TRAY_PLIST" ] && echo on || echo off ;; esac ;;
  restart) cmd_start ;;
  status) cmd_status ;;
  accessibility) cmd_accessibility ;;
  rebuild-helper) cmd_rebuild_helper ;;
  update) shift; cmd_update "$@" ;;
  autoupdate) shift; cmd_autoupdate "$@" ;;
  uninstall) shift; cmd_uninstall "$@" ;;
  *) sed -n '2,18p' "$0" | sed 's/^# \{0,1\}//'; exit 1 ;;
esac
