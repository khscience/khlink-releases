#!/bin/bash
# Build khLink.app for macOS: the menu bar app and the desktop-control helper
# in one universal (arm64 + x86_64) binary, signed with a fixed identity so the
# Accessibility permission survives updates.
#
#   build-app.sh <out-dir> [--payload <connector-package-dir> <node-arm64-dir> <node-x64-dir>]
#
# Without --payload: the lean app used for in-app updates (khLink-mac-<v>-app.zip).
# With --payload: the first-install app that also carries the connector (with
# node_modules) and the Node runtime for both processors (inside the .dmg).
# KHLINK_MACOS_SIGN_IDENTITY: codesign identity; "-" (ad hoc) when unset, which
# is fine for local tests but loses the Accessibility permission on every update.
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:?out dir}"; shift
PAYLOAD_CONNECTOR=""; NODE_ARM=""; NODE_X64=""
if [ "${1:-}" = --payload ]; then PAYLOAD_CONNECTOR="$2"; NODE_ARM="$3"; NODE_X64="$4"; fi
VERSION="${KHLINK_APP_VERSION:-$(tr -d "[:space:]" < "$HERE/VERSION")}"
BUILD="$(date +%Y%m%d%H%M)"
SIGN_ID="${KHLINK_MACOS_SIGN_IDENTITY:--}"
APP="$OUT/khLink.app"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
sed -e "s/__VERSION__/$VERSION/" -e "s/__BUILD__/$BUILD/" "$HERE/App-Info.plist" > "$APP/Contents/Info.plist"
[ -f "$HERE/khLink.icns" ] && cp "$HERE/khLink.icns" "$APP/Contents/Resources/khLink.icns"
# The window is the Windows desktop app's page (kh-link-desktop/src), so both look the same.
WEB="${KHLINK_WEB_DIR:-$HERE/web}"
[ -d "$WEB" ] || WEB="$HERE/../../kh-link-desktop/src"
[ -f "$WEB/index.html" ] || { echo "desktop page missing: $WEB" >&2; exit 1; }
ditto "$WEB" "$APP/Contents/Resources/web"

FW=(-framework Foundation -framework AppKit -framework ApplicationServices -framework CoreGraphics -framework IOKit -framework Carbon -framework WebKit -framework CoreImage)
for arch in arm64 x86_64; do
  swiftc -O -target "$arch-apple-macos13.0" "${FW[@]}" "$HERE"/Sources/*.swift -o "$TMP/khLink-$arch"
done
lipo -create "$TMP/khLink-arm64" "$TMP/khLink-x86_64" -output "$APP/Contents/MacOS/khLink"
chmod 755 "$APP/Contents/MacOS/khLink"

if [ -n "$PAYLOAD_CONNECTOR" ]; then
  P="$APP/Contents/Resources/payload"
  mkdir -p "$P/runtime"
  ditto "$PAYLOAD_CONNECTOR" "$P/connector"
  ditto "$NODE_ARM" "$P/runtime/node-arm64"
  ditto "$NODE_X64" "$P/runtime/node-x64"
fi

codesign --force --timestamp=none --sign "$SIGN_ID" --identifier vip.fengzhu.khlink "$APP"
codesign --verify --strict "$APP"
echo "built $APP $VERSION ($BUILD)"
codesign -d -r- "$APP" 2>&1 | grep designated || true
