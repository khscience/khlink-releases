import Foundation
import AppKit
import ApplicationServices
import CoreGraphics
import IOKit.pwr_mgt
import Carbon.HIToolbox

// MARK: - Protocol Models (matches Windows desktop-adapter --serve contract)

struct ServeEnvelope: Decodable {
    let id: UInt64
    let request: AdapterRequest
}

struct Attachment: Decodable {
    let name: String
    let path: String
    let size: UInt64?
    let mimeType: String?
}

struct AdapterRequest: Decodable {
    let action: String
    let requestId: String?
    let threadId: String?
    let title: String?
    let knownTitles: [String]?
    let mode: String?
    let text: String?
    let attachments: [Attachment]?
    let target: String?
    let model: String?
    let effort: String?
    let serviceTier: String?
    let permissionMode: String?
    let collaborationMode: String?
    let idleSeconds: Int?
    let steerNow: Bool?
}

struct AgentPresence: Encodable {
    let codex: Bool
    let claude: Bool
    let antigravity: Bool
    let codexProfileIsolation: Bool
}

struct DesktopQueuedItem: Encodable {
    let text: String
    let order: Int
}

struct AdapterResponse: Encodable {
    let ok: Bool
    let code: String
    let message: String
    let delivery: String
    var activeTitle: String? = nil
    var items: [DesktopQueuedItem]? = nil
    var effectiveCollaborationMode: String? = nil
    var desiredCollaborationMode: String? = nil
    var modeSyncState: String? = nil
    var reason: String? = nil
    var agentPresence: AgentPresence? = nil
    var axTrusted: Bool? = nil
    var screenLocked: Bool? = nil
    var controls: [String]? = nil
    var payload: String? = nil
}

struct ServeResponseEnvelope: Encodable {
    let id: UInt64
    let response: AdapterResponse
}

let jsonEncoder: JSONEncoder = {
    let enc = JSONEncoder()
    enc.outputFormatting = []
    return enc
}()

let jsonDecoder = JSONDecoder()

func writeStdoutLine(_ line: String) {
    if let data = (line + "\n").data(using: .utf8) {
        FileHandle.standardOutput.write(data)
    }
}

func emitWritePhase(_ transportId: UInt64?, writeLine: (String) -> Void = writeStdoutLine) {
    guard let id = transportId else { return }
    writeLine("{\"id\":\(id),\"phase\":\"write\"}")
}

func makeOk(_ code: String, _ message: String, delivery: String = "sent") -> AdapterResponse {
    AdapterResponse(ok: true, code: code, message: message, delivery: delivery)
}

func makeError(_ code: String, _ message: String, delivery: String = "not_sent") -> AdapterResponse {
    AdapterResponse(ok: false, code: code, message: message, delivery: delivery)
}

// MARK: - System State (Lock, Wake Assertion, Idle Time, Presence)

/// macOS also sets CGSSessionScreenIsLocked while the display sleeps when no
/// password is required to wake it ("Require password" off): nothing is locked
/// then, and the phone must not say so (seen on kh-mac, 2026-11-27). A lock
/// that was already there while the display was on stays a lock.
final class ScreenLockState {
    static let shared = ScreenLockState()
    private let lock = NSLock()
    private var lockedWhileAwake = false
    private var passwordOff: Bool?
    private var checkedAt = Date.distantPast

    /// `sysadminctl -screenLock status` says "off", "immediate" or a delay;
    /// read at most once a minute. nil when unknown.
    private func passwordIsOff() -> Bool? {
        if Date().timeIntervalSince(checkedAt) < 60 { return passwordOff }
        checkedAt = Date()
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/sbin/sysadminctl")
        process.arguments = ["-screenLock", "status"]
        let pipe = Pipe()
        process.standardOutput = pipe
        process.standardError = pipe
        do { try process.run() } catch { passwordOff = nil; return nil }
        let deadline = Date().addingTimeInterval(5)
        while process.isRunning && Date() < deadline { usleep(50_000) }
        if process.isRunning { process.terminate(); passwordOff = nil; return nil }
        let text = String(data: pipe.fileHandleForReading.readDataToEndOfFile(), encoding: .utf8) ?? ""
        if text.contains("screenLock is off") { passwordOff = true }
        else if text.contains("screenLock is") || text.contains("screenLock delay") { passwordOff = false }
        else { passwordOff = nil }
        return passwordOff
    }

    func resolve(flag: Bool, displayAsleep: Bool) -> Bool {
        lock.lock(); defer { lock.unlock() }
        if !flag { lockedWhileAwake = false; return false }
        if !displayAsleep { lockedWhileAwake = true; return true }
        if lockedWhileAwake { return true }
        return passwordIsOff() != true
    }
}

func isScreenLocked() -> Bool? {
    guard let dict = CGSessionCopyCurrentDictionary() as? [String: Any] else { return nil }
    let raw = (dict["CGSSessionScreenIsLocked"] as? Bool) ?? (dict["CGSSessionScreenIsLocked"] as? NSNumber)?.boolValue
    if raw == nil, let onConsole = dict["kCGSSessionOnConsoleKey"] as? Bool, !onConsole { return true }
    let flag = raw ?? false
    return ScreenLockState.shared.resolve(flag: flag, displayAsleep: CGDisplayIsAsleep(CGMainDisplayID()) != 0)
}

func userIdleSeconds() -> Double {
    CGEventSource.secondsSinceLastEventType(.combinedSessionState, eventType: .null)
}

func onMain<T>(_ body: () -> T) -> T {
    if Thread.isMainThread { return body() }
    return DispatchQueue.main.sync(execute: body)
}

func allRunningApps() -> [NSRunningApplication] {
    onMain { NSWorkspace.shared.runningApplications }
}

func frontmostApp() -> NSRunningApplication? {
    onMain { NSWorkspace.shared.frontmostApplication }
}

func runningCodexApp() -> NSRunningApplication? {
    if let direct = NSRunningApplication.runningApplications(withBundleIdentifier: "com.openai.codex").first(where: { !$0.isTerminated }) {
        return direct
    }
    let apps = allRunningApps()
    if let byBundle = apps.first(where: { !$0.isTerminated && $0.bundleIdentifier == "com.openai.codex" }) {
        return byBundle
    }
    return apps.first(where: { app in
        guard !app.isTerminated else { return false }
        let bundle = (app.bundleIdentifier ?? "").lowercased()
        let name = (app.localizedName ?? "").lowercased()
        if bundle.contains("codex") { return true }
        if name == "chatgpt" || name == "codex" {
            let path = app.bundleURL?.path ?? ""
            return FileManager.default.fileExists(atPath: path + "/Contents/Frameworks/Codex Framework.framework")
        }
        return false
    })
}

func runningClaudeApp() -> NSRunningApplication? {
    if let direct = NSRunningApplication.runningApplications(withBundleIdentifier: "com.anthropic.claudefordesktop").first(where: { !$0.isTerminated }) {
        return direct
    }
    return allRunningApps().first(where: { app in
        guard !app.isTerminated else { return false }
        let bundle = (app.bundleIdentifier ?? "").lowercased()
        return bundle == "com.anthropic.claudefordesktop" || bundle.contains("claudefordesktop")
    })
}

func runningAntigravityApp() -> NSRunningApplication? {
    return allRunningApps().first(where: { app in
        guard !app.isTerminated else { return false }
        let bundle = (app.bundleIdentifier ?? "").lowercased()
        let name = (app.localizedName ?? "").lowercased()
        return bundle.contains("antigravity") || name == "antigravity"
    })
}

func agentPresenceSnapshot() -> AdapterResponse {
    var resp = makeOk("presence", "Desktop agent window presence checked", delivery: "not_sent")
    resp.agentPresence = AgentPresence(
        codex: runningCodexApp() != nil,
        claude: runningClaudeApp() != nil,
        antigravity: runningAntigravityApp() != nil,
        codexProfileIsolation: false
    )
    resp.axTrusted = AXIsProcessTrusted()
    resp.screenLocked = isScreenLocked()
    return resp
}

// MARK: - Screen Monitor Mode (--screen-monitor)

final class WakeKeeper {
    private var assertionId: IOPMAssertionID = 0
    private(set) var active = false
    private(set) var error = false

    func setEnabled(_ enabled: Bool) {
        if enabled {
            if active { error = false; return }
            let reason = "khLink keep screen awake" as CFString
            var id: IOPMAssertionID = 0
            let status = IOPMAssertionCreateWithName(
                kIOPMAssertionTypePreventUserIdleDisplaySleep as CFString,
                IOPMAssertionLevel(kIOPMAssertionLevelOn),
                reason,
                &id
            )
            if status == kIOReturnSuccess {
                assertionId = id
                active = true
                error = false
            } else {
                active = false
                error = true
            }
        } else {
            if active {
                IOPMAssertionRelease(assertionId)
                assertionId = 0
                active = false
            }
            error = false
        }
    }

    deinit {
        if active { IOPMAssertionRelease(assertionId) }
    }
}

func runScreenMonitor() {
    let keeper = WakeKeeper()
    let lock = NSLock()
    var desiredWake = false

    func emitSample() {
        lock.lock()
        keeper.setEnabled(desiredWake)
        let active = keeper.active
        let err = keeper.error
        lock.unlock()
        let locked = isScreenLocked()
        let lockedJson = locked == nil ? "null" : (locked! ? "true" : "false")
        writeStdoutLine("{\"locked\":\(lockedJson),\"wakeActive\":\(active ? "true" : "false"),\"wakeError\":\(err ? "true" : "false")}")
    }

    let timer = DispatchSource.makeTimerSource(queue: DispatchQueue.global(qos: .utility))
    timer.schedule(deadline: .now() + 5, repeating: 5)
    timer.setEventHandler { emitSample() }
    timer.resume()

    emitSample()
    while let line = readLine() {
        let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
        lock.lock()
        if trimmed == "1" { desiredWake = true }
        else if trimmed == "0" { desiredWake = false }
        lock.unlock()
        emitSample()
    }
    timer.cancel()
    lock.lock()
    keeper.setEnabled(false)
    lock.unlock()
}

// MARK: - AXUIElement Helpers

final class AXHelper {
    private static var enabledPids = Set<pid_t>()

    static func appElement(for app: NSRunningApplication) -> AXUIElement {
        let el = AXUIElementCreateApplication(app.processIdentifier)
        if !enabledPids.contains(app.processIdentifier) {
            AXUIElementSetAttributeValue(el, "AXManualAccessibility" as CFString, kCFBooleanTrue)
            AXUIElementSetAttributeValue(el, "AXEnhancedUserInterface" as CFString, kCFBooleanTrue)
            enabledPids.insert(app.processIdentifier)
            Thread.sleep(forTimeInterval: 0.20)
        }
        return el
    }

    static func stringAttr(_ el: AXUIElement, _ attr: String) -> String {
        var value: CFTypeRef?
        guard AXUIElementCopyAttributeValue(el, attr as CFString, &value) == .success else { return "" }
        if let str = value as? String { return str }
        if let url = value as? URL { return url.absoluteString }
        if let num = value as? NSNumber { return num.stringValue }
        return ""
    }

    static func boolAttr(_ el: AXUIElement, _ attr: String) -> Bool? {
        var value: CFTypeRef?
        guard AXUIElementCopyAttributeValue(el, attr as CFString, &value) == .success else { return nil }
        if let b = value as? Bool { return b }
        if let n = value as? NSNumber { return n.boolValue }
        return nil
    }

    static func role(_ el: AXUIElement) -> String { stringAttr(el, kAXRoleAttribute) }
    static func subrole(_ el: AXUIElement) -> String { stringAttr(el, kAXSubroleAttribute) }
    static func title(_ el: AXUIElement) -> String { stringAttr(el, kAXTitleAttribute) }
    static func desc(_ el: AXUIElement) -> String { stringAttr(el, kAXDescriptionAttribute) }
    static func valueStr(_ el: AXUIElement) -> String { stringAttr(el, kAXValueAttribute) }
    static func identifier(_ el: AXUIElement) -> String { stringAttr(el, kAXIdentifierAttribute) }
    static func urlStr(_ el: AXUIElement) -> String { stringAttr(el, kAXURLAttribute) }
    static func isEnabled(_ el: AXUIElement) -> Bool { boolAttr(el, kAXEnabledAttribute) ?? true }

    static func label(_ el: AXUIElement) -> String {
        let t = title(el).trimmingCharacters(in: .whitespacesAndNewlines)
        if !t.isEmpty { return t }
        let d = desc(el).trimmingCharacters(in: .whitespacesAndNewlines)
        if !d.isEmpty { return d }
        let v = valueStr(el).trimmingCharacters(in: .whitespacesAndNewlines)
        if !v.isEmpty && v.count <= 200 { return v }
        return ""
    }

    static func children(_ el: AXUIElement) -> [AXUIElement] {
        var value: CFTypeRef?
        if AXUIElementCopyAttributeValue(el, kAXChildrenAttribute as CFString, &value) == .success,
           let arr = value as? [AXUIElement] {
            return arr
        }
        return []
    }

    static func windows(_ appEl: AXUIElement) -> [AXUIElement] {
        var value: CFTypeRef?
        if AXUIElementCopyAttributeValue(appEl, kAXWindowsAttribute as CFString, &value) == .success,
           let arr = value as? [AXUIElement] {
            return arr
        }
        return []
    }

    static func primaryWindow(of app: NSRunningApplication) -> (AXUIElement, AXUIElement)? {
        let axApp = appElement(for: app)
        var focused: CFTypeRef?
        if AXUIElementCopyAttributeValue(axApp, kAXFocusedWindowAttribute as CFString, &focused) == .success,
           let win = focused {
            return (axApp, win as! AXUIElement)
        }
        if let first = windows(axApp).first {
            return (axApp, first)
        }
        // Retry once after AXManualAccessibility warm-up
        Thread.sleep(forTimeInterval: 0.25)
        if let first = windows(axApp).first {
            return (axApp, first)
        }
        return nil
    }

    static func actions(_ el: AXUIElement) -> [String] {
        var names: CFArray?
        guard AXUIElementCopyActionNames(el, &names) == .success, let arr = names as? [String] else { return [] }
        return arr
    }

    static func press(_ el: AXUIElement) -> Bool {
        if AXUIElementPerformAction(el, kAXPressAction as CFString) == .success { return true }
        if AXUIElementPerformAction(el, kAXShowMenuAction as CFString) == .success { return true }
        return false
    }

    static func frame(_ el: AXUIElement) -> CGRect? {
        var posVal: CFTypeRef?
        var sizeVal: CFTypeRef?
        guard AXUIElementCopyAttributeValue(el, kAXPositionAttribute as CFString, &posVal) == .success,
              AXUIElementCopyAttributeValue(el, kAXSizeAttribute as CFString, &sizeVal) == .success,
              let pv = posVal, let sv = sizeVal else { return nil }
        var pt = CGPoint.zero
        var sz = CGSize.zero
        guard AXValueGetValue(pv as! AXValue, .cgPoint, &pt),
              AXValueGetValue(sv as! AXValue, .cgSize, &sz) else { return nil }
        return CGRect(origin: pt, size: sz)
    }

    static func webArea(in window: AXUIElement, waitIfMissing: Bool = true) -> AXUIElement? {
        func findOnce() -> AXUIElement? {
            var found: AXUIElement? = nil
            walk(window, maxDepth: 14, maxNodes: 600) { el, _ in
                if role(el) == "AXWebArea" {
                    found = el
                    return false
                }
                return true
            }
            return found
        }
        if let hit = findOnce() { return hit }
        if !waitIfMissing { return nil }
        for _ in 0..<8 {
            Thread.sleep(forTimeInterval: 0.2)
            if let hit = findOnce() { return hit }
        }
        return nil
    }

    static func scrollToVisible(_ el: AXUIElement) {
        _ = AXUIElementPerformAction(el, "AXScrollToVisible" as CFString)
    }

    static func walk(_ root: AXUIElement, maxDepth: Int = 64, maxNodes: Int = 20000, visit: (AXUIElement, Int) -> Bool) {
        var stack: [(AXUIElement, Int)] = [(root, 0)]
        var visited = 0
        while let (el, depth) = stack.popLast(), visited < maxNodes {
            visited += 1
            if !visit(el, depth) { return }
            if depth < maxDepth {
                let kids = children(el)
                for child in kids.reversed() {
                    stack.append((child, depth + 1))
                }
            }
        }
    }

    static func parent(_ el: AXUIElement) -> AXUIElement? {
        var value: CFTypeRef?
        guard AXUIElementCopyAttributeValue(el, kAXParentAttribute as CFString, &value) == .success,
              let p = value else { return nil }
        return (p as! AXUIElement)
    }

    static func isDescendantOrSelf(_ candidate: AXUIElement, of ancestor: AXUIElement, maxSteps: Int = 10) -> Bool {
        var cur: AXUIElement? = candidate
        for _ in 0..<maxSteps {
            guard let node = cur else { return false }
            if CFEqual(node, ancestor) { return true }
            var parent: CFTypeRef?
            if AXUIElementCopyAttributeValue(node, kAXParentAttribute as CFString, &parent) == .success, let p = parent {
                cur = (p as! AXUIElement)
            } else {
                return false
            }
        }
        return false
    }
}

// MARK: - Safe Clipboard & Keyboard Input

struct ClipboardSnapshot {
    let items: [[NSPasteboard.PasteboardType: Data]]
}

func saveClipboard() -> ClipboardSnapshot {
    let pb = NSPasteboard.general
    var saved: [[NSPasteboard.PasteboardType: Data]] = []
    for item in pb.pasteboardItems ?? [] {
        var dict: [NSPasteboard.PasteboardType: Data] = [:]
        for type in item.types {
            if let data = item.data(forType: type) {
                dict[type] = data
            }
        }
        if !dict.isEmpty { saved.append(dict) }
    }
    return ClipboardSnapshot(items: saved)
}

func restoreClipboard(_ snapshot: ClipboardSnapshot) {
    let pb = NSPasteboard.general
    pb.clearContents()
    if snapshot.items.isEmpty { return }
    var objects: [NSPasteboardItem] = []
    for dict in snapshot.items {
        let item = NSPasteboardItem()
        for (type, data) in dict {
            item.setData(data, forType: type)
        }
        objects.append(item)
    }
    pb.writeObjects(objects)
}

func postKey(_ keyCode: CGKeyCode, flags: CGEventFlags = []) {
    guard let src = CGEventSource(stateID: .hidSystemState),
          let down = CGEvent(keyboardEventSource: src, virtualKey: keyCode, keyDown: true),
          let up = CGEvent(keyboardEventSource: src, virtualKey: keyCode, keyDown: false) else { return }
    down.flags = flags
    up.flags = flags
    down.post(tap: .cghidEventTap)
    Thread.sleep(forTimeInterval: 0.03)
    up.post(tap: .cghidEventTap)
}

func postLeftClick(at point: CGPoint) {
    guard let src = CGEventSource(stateID: .hidSystemState),
          let down = CGEvent(mouseEventSource: src, mouseType: .leftMouseDown, mouseCursorPosition: point, mouseButton: .left),
          let up = CGEvent(mouseEventSource: src, mouseType: .leftMouseUp, mouseCursorPosition: point, mouseButton: .left) else { return }
    down.post(tap: .cghidEventTap)
    Thread.sleep(forTimeInterval: 0.03)
    up.post(tap: .cghidEventTap)
}

func activateAppWindow(_ app: NSRunningApplication, window: AXUIElement) -> Bool {
    if AXHelper.boolAttr(window, kAXMinimizedAttribute) == true {
        AXUIElementSetAttributeValue(window, kAXMinimizedAttribute as CFString, kCFBooleanFalse)
        Thread.sleep(forTimeInterval: 0.25)
    }
    if app.isHidden { onMain { _ = app.unhide() } }
    onMain {
        if #available(macOS 14.0, *) {
            _ = app.activate()
        } else {
            _ = app.activate(options: [.activateIgnoringOtherApps])
        }
    }
    _ = AXUIElementPerformAction(window, kAXRaiseAction as CFString)
    for _ in 0..<8 {
        if frontmostApp()?.processIdentifier == app.processIdentifier { return true }
        Thread.sleep(forTimeInterval: 0.1)
    }
    return frontmostApp()?.processIdentifier == app.processIdentifier
}

func activateAndFocus(_ app: NSRunningApplication, window: AXUIElement, editor: AXUIElement) -> Bool {
    guard activateAppWindow(app, window: window) else { return false }
    AXHelper.scrollToVisible(editor)
    _ = AXUIElementSetAttributeValue(editor, kAXFocusedAttribute as CFString, kCFBooleanTrue)
    for attempt in 0..<6 {
        Thread.sleep(forTimeInterval: 0.1)
        if AXHelper.boolAttr(editor, kAXFocusedAttribute) == true { return true }
        var focused: CFTypeRef?
        let axApp = AXHelper.appElement(for: app)
        if AXUIElementCopyAttributeValue(axApp, kAXFocusedUIElementAttribute as CFString, &focused) == .success,
           let f = focused {
            let fEl = f as! AXUIElement
            if AXHelper.isDescendantOrSelf(fEl, of: editor, maxSteps: 16) || AXHelper.isDescendantOrSelf(editor, of: fEl, maxSteps: 16) {
                return true
            }
        }
        if attempt == 2, let f = AXHelper.frame(editor), f.width > 10, f.height > 10 {
            postLeftClick(at: CGPoint(x: f.minX + min(40, f.width / 2), y: f.midY))
        } else {
            _ = AXHelper.press(editor)
            _ = AXUIElementSetAttributeValue(editor, kAXFocusedAttribute as CFString, kCFBooleanTrue)
        }
    }
    return false
}

// MARK: - Hot-Reloadable Selector Config (avoids recompiling helper & breaking TCC)

struct SelectorConfig: Decodable {
    var composerHints: [String]?
    var sendLabels: [String]?
    var stopLabels: [String]?
    var queuedHeaderHints: [String]?
    var queuedCancelLabels: [String]?
    var queuedSteerLabels: [String]?
    var modelButtonHints: [String]?
    var effortButtonHints: [String]?
    var permissionButtonHints: [String]?
    var planButtonHints: [String]?

    static let defaults = SelectorConfig(
        composerHints: ["和 codex 一起工作", "随心输入", "message", "ask", "codex", "prompt", "输入", "发送", "提问", "询问", "向", "说点什么", "问题"],
        sendLabels: ["send", "发送", "send message", "send prompt", "发送消息", "发送提示", "queue", "排队", "引导", "调整方向", "继续", "提交"],
        stopLabels: ["stop", "停止", "stop generating", "stop task", "停止生成", "停止任务", "停止响应", "中断", "取消生成"],
        queuedHeaderHints: ["queued", "排队", "待发送", "等待发送", "队列", "steer", "插队"],
        queuedCancelLabels: ["删除排队的消息", "remove queued message", "delete queued message", "cancel", "delete", "remove", "取消", "删除", "移除"],
        queuedSteerLabels: ["引导", "调整方向", "steer", "send now", "立即发送", "插队", "优先发送", "马上发送"],
        modelButtonHints: ["gpt-", "gpt", "o3", "o4", "codex", "model", "模型", "选择模型"],
        effortButtonHints: ["轻度", "标准", "极高", "最高", "深度", "低", "中", "高", "reasoning", "effort", "low", "medium", "high", "xhigh", "推理", "思考"],
        permissionButtonHints: ["更改权限", "权限", "permission", "approval", "sandbox", "auto", "full access", "完全访问权限", "完全访问", "完整访问", "默认权限", "帮我批准", "请求批准", "审批"],
        planButtonHints: ["plan", "计划", "规划"]
    )
}

func loadSelectors() -> SelectorConfig {
    let paths = [
        NSString(string: "~/Library/Application Support/khLink/connector/app/scripts/macos-selectors.json").expandingTildeInPath,
        NSString(string: "~/Library/Application Support/FengzhuAgentBridge/macos-selectors.json").expandingTildeInPath
    ]
    for p in paths {
        if let data = FileManager.default.contents(atPath: p),
           let cfg = try? jsonDecoder.decode(SelectorConfig.self, from: data) {
            return cfg
        }
    }
    return SelectorConfig.defaults
}

func hints(_ list: [String]?, fallback: [String]) -> [String] {
    guard let l = list, !l.isEmpty else { return fallback }
    return l.map { $0.lowercased() }
}

// MARK: - Codex Desktop AX Operations

func stripRequestMarker(_ raw: String) -> String {
    String(raw.unicodeScalars.filter { scalar in
        let v = scalar.value
        return v != 0x2063 && v != 0x200B && v != 0x200C && v != 0x200D && v != 0x2060
    })
}

func normalizeText(_ raw: String) -> String {
    raw.replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
        .trimmingCharacters(in: .whitespacesAndNewlines)
}

func normalizeVisibleText(_ raw: String) -> String {
    normalizeText(stripRequestMarker(raw))
}

func stripSidebarBadges(_ raw: String) -> String {
    var s = normalizeVisibleText(raw)
    for prefix in ["未读 ", "未读", "Unread ", "Unread"] {
        if s.hasPrefix(prefix) && s.count > prefix.count {
            s = String(s.dropFirst(prefix.count)).trimmingCharacters(in: .whitespacesAndNewlines)
        }
    }
    if let range = s.range(of: " 未读消息") {
        s = String(s[..<range.lowerBound]).trimmingCharacters(in: .whitespacesAndNewlines)
    }
    for suffix in [" 需要批准", "需要批准", " Needs approval", "Needs approval"] {
        if s.hasSuffix(suffix) && s.count > suffix.count {
            s = String(s.dropLast(suffix.count)).trimmingCharacters(in: .whitespacesAndNewlines)
        }
    }
    return s
}

func queueLabelCandidates(_ text: String) -> [String] {
    var result: [String] = []
    func add(_ value: String) {
        let norm = normalizeText(value)
        if !norm.isEmpty && !result.contains(norm) { result.append(norm) }
    }
    let visible = stripRequestMarker(text)
    for full in [text, visible] {
        let trimmed = full.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.hasPrefix("<send_user_message_question_reply>") && trimmed.hasSuffix("</send_user_message_question_reply>") {
            let body = trimmed
                .dropFirst("<send_user_message_question_reply>".count)
                .dropLast("</send_user_message_question_reply>".count)
                .trimmingCharacters(in: .whitespacesAndNewlines)
            add(trimmed)
            add(String(body))
            continue
        }
        add(full)
        if let firstLine = full.split(whereSeparator: \.isNewline).first {
            add(String(firstLine))
        }
    }
    return result
}

func matchesAny(_ text: String, patterns: [String]) -> Bool {
    let lower = text.lowercased()
    return patterns.contains { !$0.isEmpty && (lower == $0 || lower.contains($0)) }
}

func clickableAncestor(of el: AXUIElement, maxSteps: Int = 4) -> AXUIElement {
    let r = AXHelper.role(el)
    if r == kAXButtonRole || r == "AXLink" || r == kAXRowRole { return el }
    var cur: AXUIElement? = el
    for _ in 0..<maxSteps {
        guard let p = cur.flatMap({ AXHelper.parent($0) }) else { break }
        let pr = AXHelper.role(p)
        if pr == kAXButtonRole || pr == "AXLink" || pr == kAXRowRole { return p }
        cur = p
    }
    return el
}

func findComposer(in window: AXUIElement) -> AXUIElement? {
    let cfg = loadSelectors()
    let compHints = hints(cfg.composerHints, fallback: SelectorConfig.defaults.composerHints!)
    let root = AXHelper.webArea(in: window) ?? window
    var best: AXUIElement? = nil
    var fallbackEditor: AXUIElement? = nil
    AXHelper.walk(root, maxDepth: 64, maxNodes: 20000) { el, _ in
        let r = AXHelper.role(el)
        if r == kAXTextAreaRole || r == kAXComboBoxRole || r == kAXTextFieldRole {
            let desc = AXHelper.desc(el).lowercased()
            let title = AXHelper.title(el).lowercased()
            let placeholder = AXHelper.stringAttr(el, "AXPlaceholderValue").lowercased()
            let combined = "\(desc) \(title) \(placeholder)"
            if matchesAny(combined, patterns: compHints) {
                best = el
                return false
            }
            if r == kAXTextAreaRole && fallbackEditor == nil && AXHelper.isEnabled(el) {
                fallbackEditor = el
            }
        }
        return true
    }
    return best ?? fallbackEditor
}

func findSidebarItem(in window: AXUIElement, title: String) -> AXUIElement? {
    let root = AXHelper.webArea(in: window) ?? window
    let winFrame = AXHelper.frame(window)
    let sidebarLimit = (winFrame?.minX ?? 0) + 420
    let want = normalizeVisibleText(title)
    guard !want.isEmpty else { return nil }
    var exactBtn: AXUIElement? = nil
    var exactOther: AXUIElement? = nil
    var prefixBtn: AXUIElement? = nil
    var prefixOther: AXUIElement? = nil
    AXHelper.walk(root, maxDepth: 64, maxNodes: 20000) { el, _ in
        let r = AXHelper.role(el)
        let isClickable = (r == kAXButtonRole || r == "AXLink" || r == kAXRowRole)
        if isClickable || r == kAXStaticTextRole || r == "AXGroup" {
            if let f = AXHelper.frame(el), f.minX > sidebarLimit { return true }
            let rawLbl = normalizeVisibleText(AXHelper.label(el))
            if rawLbl.isEmpty { return true }
            let cleanLbl = stripSidebarBadges(rawLbl)
            if rawLbl == want || cleanLbl == want {
                if isClickable {
                    exactBtn = el
                    return false
                }
                if exactOther == nil { exactOther = clickableAncestor(of: el) }
            } else if min(cleanLbl.count, want.count) >= 6 && (cleanLbl.hasPrefix(want) || want.hasPrefix(cleanLbl)) {
                if isClickable && prefixBtn == nil { prefixBtn = el }
                else if prefixOther == nil { prefixOther = clickableAncestor(of: el) }
            }
        }
        return true
    }
    return exactBtn ?? exactOther ?? prefixBtn ?? prefixOther
}

func mainPaneMinX(in window: AXUIElement, composerFrame: CGRect? = nil) -> CGFloat {
    if let cf = composerFrame ?? findComposer(in: window).flatMap({ AXHelper.frame($0) }), cf.width > 100 {
        return cf.minX - 24
    }
    return (AXHelper.frame(window)?.minX ?? 0) + 350
}

func findStopButton(in window: AXUIElement) -> AXUIElement? {
    let cfg = loadSelectors()
    let stopHints = hints(cfg.stopLabels, fallback: SelectorConfig.defaults.stopLabels!)
    let root = AXHelper.webArea(in: window) ?? window
    let winFrame = AXHelper.frame(window)
    let sidebarEdge = mainPaneMinX(in: window)
    let bottomZoneY = (winFrame?.maxY ?? 0) - 280
    var bottomHit: AXUIElement? = nil
    var anyHit: AXUIElement? = nil
    AXHelper.walk(root, maxDepth: 64, maxNodes: 20000) { el, _ in
        if AXHelper.role(el) == kAXButtonRole && AXHelper.isEnabled(el) {
            if let f = AXHelper.frame(el) {
                if f.minX < sidebarEdge { return true }
                let l = AXHelper.label(el)
                if matchesAny(l, patterns: stopHints) {
                    if f.minY >= bottomZoneY {
                        bottomHit = el
                        return false
                    }
                    if anyHit == nil { anyHit = el }
                }
            }
        }
        return true
    }
    return bottomHit ?? anyHit
}

func findSendButton(in window: AXUIElement, mode: String? = nil) -> (element: AXUIElement, isSteer: Bool)? {
    let cfg = loadSelectors()
    let rawSendHints = hints(cfg.sendLabels, fallback: SelectorConfig.defaults.sendLabels!)
    let queueHints = ["加入队列", "排队", "queue"]
    let steerHints = ["引导", "调整方向", "steer", "立即发送"]
    let plainSendHints = rawSendHints.filter { !steerHints.contains($0) }
    let excluded = ["添加文件等内容", "更改权限", "听写", "开启语音聊天", "开始新的语音聊天", "语音"]
    let root = AXHelper.webArea(in: window) ?? window
    let winFrame = AXHelper.frame(window)
    let sidebarEdge = mainPaneMinX(in: window)
    let bottomZoneY = (winFrame?.maxY ?? 0) - 260
    var queueBtn: AXUIElement? = nil
    var steerBtn: AXUIElement? = nil
    var plainBtn: AXUIElement? = nil
    let lowerMode = (mode ?? "").lowercased()
    AXHelper.walk(root, maxDepth: 64, maxNodes: 20000) { el, _ in
        if AXHelper.role(el) == kAXButtonRole && AXHelper.isEnabled(el) {
            if let f = AXHelper.frame(el), f.minX < sidebarEdge || f.minY < bottomZoneY { return true }
            let l = normalizeText(AXHelper.label(el))
            if l.isEmpty || excluded.contains(where: { l.contains($0) }) { return true }
            if queueBtn == nil && matchesAny(l, patterns: queueHints) { queueBtn = el }
            else if steerBtn == nil && matchesAny(l, patterns: steerHints) { steerBtn = el }
            else if plainBtn == nil && matchesAny(l, patterns: plainSendHints) { plainBtn = el }
        }
        return true
    }
    if lowerMode == "queue" {
        if let q = queueBtn { return (q, false) }
        if let p = plainBtn { return (p, false) }
        // Never click a Steer-only button when the caller explicitly requested Queue.
        return nil
    }
    if lowerMode == "steer" {
        if let s = steerBtn { return (s, true) }
        if let q = queueBtn { return (q, false) }
        if let p = plainBtn { return (p, false) }
        return nil
    }
    if let p = plainBtn { return (p, false) }
    if let q = queueBtn { return (q, false) }
    if let s = steerBtn { return (s, true) }
    return nil
}

func composerHasDraft(_ composer: AXUIElement) -> Bool {
    let val = normalizeText(AXHelper.valueStr(composer))
    if val.isEmpty { return false }
    let ph = normalizeText(AXHelper.stringAttr(composer, "AXPlaceholderValue"))
    let t = normalizeText(AXHelper.title(composer))
    let d = normalizeText(AXHelper.desc(composer))
    if val == ph || val == t || val == d { return false }
    let lower = val.lowercased()
    let placeholders = [
        "和 codex 一起工作", "随心输入", "ask anything", "message codex",
        "work with codex", "send a message", "给 codex 发消息", "向 codex 提问"
    ]
    if placeholders.contains(lower) { return false }
    return true
}

func detectActiveTitle(window: AXUIElement, knownTitles: [String]) -> String? {
    let normalizedKnown = knownTitles.map { ($0, normalizeText($0)) }.filter { !$0.1.isEmpty }
    let winTitle = normalizeText(AXHelper.title(window))
    let winLower = winTitle.lowercased()
    if !winTitle.isEmpty && winLower != "chatgpt" && winLower != "codex" {
        for (orig, norm) in normalizedKnown where winTitle == norm {
            return orig
        }
        for (orig, norm) in normalizedKnown where min(winTitle.count, norm.count) >= 6 && (winTitle.hasPrefix(norm) || norm.hasPrefix(winTitle)) {
            return orig
        }
        // Window title authoritatively names another conversation; never confuse
        // a message bubble inside this thread with a different active thread.
        return nil
    }
    let root = AXHelper.webArea(in: window) ?? window
    let winFrame = AXHelper.frame(window)
    let sidebarEdge = (winFrame?.minX ?? 0) + 260
    let headerMaxY = (winFrame?.minY ?? 0) + 120
    var found: String? = nil
    AXHelper.walk(root, maxDepth: 64, maxNodes: 15000) { el, _ in
        let r = AXHelper.role(el)
        if r == "AXHeading" || r == kAXStaticTextRole || r == kAXButtonRole {
            if let f = AXHelper.frame(el), f.minX < sidebarEdge || f.minY > headerMaxY { return true }
            let lbl = normalizeText(AXHelper.label(el))
            if lbl.isEmpty { return true }
            for (orig, norm) in normalizedKnown where lbl == norm || (min(lbl.count, norm.count) >= 8 && (lbl.hasPrefix(norm) || norm.hasPrefix(lbl))) {
                found = orig
                return false
            }
        }
        return true
    }
    return found
}

func isActiveTask(window: AXUIElement, title: String) -> Bool {
    detectActiveTitle(window: window, knownTitles: [title]) != nil
}

func listQueuedItems(in window: AXUIElement) -> [DesktopQueuedItem] {
    let cfg = loadSelectors()
    let cancelHints = hints(cfg.queuedCancelLabels, fallback: SelectorConfig.defaults.queuedCancelLabels!)
    let steerHints = hints(cfg.queuedSteerLabels, fallback: SelectorConfig.defaults.queuedSteerLabels!)
    let root = AXHelper.webArea(in: window) ?? window
    guard let composer = findComposer(in: window), let compFrame = AXHelper.frame(composer) else {
        return []
    }
    let sidebarEdge = mainPaneMinX(in: window, composerFrame: compFrame)
    // Queued message rows sit right above the composer inside the main pane
    let minY = compFrame.minY - 360
    let maxY = compFrame.minY + 10
    var rowButtons: [AXUIElement] = []
    AXHelper.walk(root, maxDepth: 64, maxNodes: 20000) { el, _ in
        if AXHelper.role(el) == kAXButtonRole {
            if let f = AXHelper.frame(el), f.minX >= sidebarEdge, f.minY >= minY, f.maxY <= maxY {
                let l = AXHelper.label(el)
                if matchesAny(l, patterns: steerHints) || matchesAny(l, patterns: cancelHints) {
                    rowButtons.append(el)
                }
            }
        }
        return true
    }
    var seenTexts = Set<String>()
    var items: [DesktopQueuedItem] = []
    for btn in rowButtons {
        guard let parent = AXHelper.parent(btn) else { continue }
        let container = AXHelper.parent(parent) ?? parent
        var rowTexts: [String] = []
        AXHelper.walk(container, maxDepth: 8, maxNodes: 80) { node, _ in
            if AXHelper.role(node) == kAXStaticTextRole {
                let t = normalizeText(AXHelper.label(node))
                if !t.isEmpty && !matchesAny(t, patterns: cancelHints) && !matchesAny(t, patterns: steerHints) {
                    rowTexts.append(t)
                }
            }
            return true
        }
        let joined = normalizeText(rowTexts.joined(separator: " "))
        if !joined.isEmpty && !seenTexts.contains(joined) {
            seenTexts.insert(joined)
            items.append(DesktopQueuedItem(text: joined, order: items.count))
        }
    }
    return items
}

func invokeQueuedRowAction(in window: AXUIElement, text: String, actionHints: [String], transportId: UInt64?, writeLine: (String) -> Void) -> Bool {
    let candidates = queueLabelCandidates(text)
    guard !candidates.isEmpty else { return false }
    let root = AXHelper.webArea(in: window) ?? window
    let winFrame = AXHelper.frame(window)
    let compFrame = findComposer(in: window).flatMap { AXHelper.frame($0) }
    let sidebarEdge = mainPaneMinX(in: window, composerFrame: compFrame)
    let minY = (compFrame?.minY ?? (winFrame?.maxY ?? 0) - 260) - 420
    let maxY = (compFrame?.minY ?? (winFrame?.maxY ?? 0)) + 20

    var targetTextNodes: [AXUIElement] = []
    AXHelper.walk(root, maxDepth: 64, maxNodes: 20000) { el, _ in
        let r = AXHelper.role(el)
        if r == kAXStaticTextRole || r == "AXGroup" {
            if let f = AXHelper.frame(el), f.minX < sidebarEdge || f.minY < minY || f.maxY > maxY { return true }
            let rawLbl = normalizeText(AXHelper.label(el))
            let visLbl = normalizeVisibleText(AXHelper.label(el))
            if visLbl.isEmpty { return true }
            let matched = candidates.contains { cand in
                let cVis = normalizeVisibleText(cand)
                return rawLbl == cand || visLbl == cVis
                    || (cVis.count >= 8 && visLbl.contains(cVis))
                    || (visLbl.count >= 8 && cVis.contains(visLbl))
            }
            if matched {
                targetTextNodes.append(el)
            }
        }
        return true
    }

    for startNode in targetTextNodes {
        var cur = startNode
        for _ in 0..<6 {
            guard let parent = AXHelper.parent(cur) else { break }
            var actionBtn: AXUIElement? = nil
            AXHelper.walk(parent, maxDepth: 6, maxNodes: 100) { el, _ in
                if AXHelper.role(el) == kAXButtonRole && AXHelper.isEnabled(el) {
                    if let f = AXHelper.frame(el), f.minX < sidebarEdge { return true }
                    if matchesAny(AXHelper.label(el), patterns: actionHints) {
                        actionBtn = el
                        return false
                    }
                }
                return true
            }
            if let btn = actionBtn {
                emitWritePhase(transportId, writeLine: writeLine)
                return AXHelper.press(btn)
            }
            cur = parent
        }
    }
    return false
}

func detectApprovalStatus(window: AXUIElement, title: String) -> Bool? {
    let root = AXHelper.webArea(in: window) ?? window
    let winFrame = AXHelper.frame(window)
    let sidebarLimit = (winFrame?.minX ?? 0) + 420
    let sidebarEdge = (winFrame?.minX ?? 0) + 260
    let want = normalizeVisibleText(title)

    var sidebarMatches: [Bool] = []
    if !want.isEmpty {
        AXHelper.walk(root, maxDepth: 64, maxNodes: 15000) { el, _ in
            let r = AXHelper.role(el)
            if r == kAXButtonRole || r == kAXRowRole {
                if let f = AXHelper.frame(el), f.minX > sidebarLimit { return true }
                let raw = normalizeVisibleText(AXHelper.label(el))
                if raw.isEmpty { return true }
                let cleaned = stripSidebarBadges(raw)
                if cleaned == want {
                    let pending = raw.contains("需要批准") || raw.lowercased().contains("needs approval")
                    sidebarMatches.append(pending)
                }
            }
            return true
        }
    }
    if sidebarMatches.count == 1 { return sidebarMatches[0] }

    var hasAllow = false
    var hasDeny = false
    AXHelper.walk(root, maxDepth: 64, maxNodes: 15000) { el, _ in
        if AXHelper.role(el) == kAXButtonRole && AXHelper.isEnabled(el) {
            if let f = AXHelper.frame(el), f.minX < sidebarEdge { return true }
            let lbl = normalizeVisibleText(AXHelper.label(el))
            let low = lbl.lowercased()
            if lbl == "允许一次" || low == "allow once" { hasAllow = true }
            if lbl == "拒绝" || low == "deny" { hasDeny = true }
            if hasAllow && hasDeny { return false }
        }
        return true
    }
    if hasAllow && hasDeny { return true }
    return nil
}

func normalizeAlnum(_ raw: String) -> String {
    String(raw.unicodeScalars.filter { CharacterSet.alphanumerics.contains($0) && $0.isASCII }).lowercased()
}

func modelMenuMatches(_ name: String, model: String) -> Bool {
    let expected = normalizeAlnum(model)
    guard !expected.isEmpty else { return false }
    let actual = normalizeAlnum(name)
    return actual == expected
}

func desiredEffortRank(_ value: String) -> Int? {
    switch value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
    case "minimal", "none", "light", "low", "轻度", "低": return 0
    case "medium", "standard", "中", "标准": return 1
    case "high", "高", "深度": return 2
    case "xhigh", "extra-high", "very-high", "极高": return 3
    case "max", "最高": return 4
    case "ultra": return 5
    default: return nil
    }
}

func effortOptionLabels(for effort: String) -> [String] {
    switch effort.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
    case "minimal", "none", "light", "low", "轻度", "低": return ["轻度", "低", "low", "minimal", "light"]
    case "medium", "standard", "中", "标准": return ["中", "标准", "medium", "standard"]
    case "high", "高", "深度": return ["高", "深度", "high"]
    case "xhigh", "extra-high", "very-high", "极高": return ["极高", "extra high", "xhigh"]
    case "max", "最高": return ["最高", "max"]
    default: return [effort.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()]
    }
}

func permissionTargetLabels(for mode: String) -> (labels: [String], yolo: Bool)? {
    switch mode.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
    case "manual", "untrusted": return (["请求批准", "ask for approval", "manual"], false)
    case "auto", "on-request", "default": return (["帮我批准", "默认权限", "auto", "on-request"], false)
    case "yolo", "never", "full_access", "full-access": return (["完全访问权限", "完全访问", "完整访问", "full access"], true)
    default: return nil
    }
}

func requestedFastMode(_ tier: String) -> Bool? {
    switch tier.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
    case "priority", "fast", "快速": return true
    case "default", "standard", "标准": return false
    default: return nil
    }
}

func findComposerSettingsButton(in window: AXUIElement) -> AXUIElement? {
    let root = AXHelper.webArea(in: window) ?? window
    let winFrame = AXHelper.frame(window)
    let compFrame = findComposer(in: window).flatMap { AXHelper.frame($0) }
    let sidebarEdge = mainPaneMinX(in: window, composerFrame: compFrame)
    let minY = (compFrame?.minY ?? ((winFrame?.maxY ?? 0) - 240)) - 10
    let excluded = ["添加文件等内容", "更改权限", "听写", "发送", "开启语音聊天", "开始新的语音聊天", "语音", "评价回复", "更多操作"]
    var best: (CGFloat, AXUIElement)? = nil
    AXHelper.walk(root, maxDepth: 64, maxNodes: 20000) { el, _ in
        let r = AXHelper.role(el)
        if (r == kAXPopUpButtonRole || r == kAXMenuButtonRole || r == kAXButtonRole) && AXHelper.isEnabled(el) {
            guard let f = AXHelper.frame(el), f.minX >= sidebarEdge, f.minY >= minY, f.width > 20 else { return true }
            let lbl = normalizeVisibleText(AXHelper.label(el))
            if lbl.isEmpty || excluded.contains(where: { lbl == $0 || lbl.contains($0) }) { return true }
            if best == nil || f.width > best!.0 {
                best = (f.width, el)
            }
        }
        return true
    }
    return best?.1
}

func findToolbarButton(in window: AXUIElement, hints patterns: [String]) -> AXUIElement? {
    let root = AXHelper.webArea(in: window) ?? window
    let winFrame = AXHelper.frame(window)
    let sidebarEdge = (winFrame?.minX ?? 0) + 260
    let bottomZoneY = (winFrame?.maxY ?? 0) - 240
    var trigger: AXUIElement? = nil
    AXHelper.walk(root, maxDepth: 64, maxNodes: 20000) { el, _ in
        let r = AXHelper.role(el)
        if (r == kAXPopUpButtonRole || r == kAXMenuButtonRole || r == kAXButtonRole) && AXHelper.isEnabled(el) {
            if let f = AXHelper.frame(el), f.minX >= sidebarEdge, f.minY >= bottomZoneY {
                if matchesAny(AXHelper.label(el), patterns: patterns) {
                    trigger = el
                    return false
                }
            }
        }
        return true
    }
    return trigger
}

func visibleMenuCandidates(in window: AXUIElement, excluding trigger: AXUIElement? = nil) -> [(AXUIElement, String)] {
    var out: [(AXUIElement, String)] = []
    AXHelper.walk(window, maxDepth: 64, maxNodes: 20000) { el, _ in
        let r = AXHelper.role(el)
        if r == kAXMenuItemRole || r == kAXRadioButtonRole || r == kAXCheckBoxRole || r == kAXButtonRole {
            if let trig = trigger, CFEqual(el, trig) { return true }
            let lbl = normalizeVisibleText(AXHelper.label(el))
            if !lbl.isEmpty { out.append((el, lbl)) }
        }
        return true
    }
    return out
}

func readModernEffortRank(in window: AXUIElement) -> Int? {
    var found: Int? = nil
    AXHelper.walk(window, maxDepth: 64, maxNodes: 20000) { el, _ in
        let r = AXHelper.role(el)
        if r == kAXStaticTextRole || r == kAXMenuItemRole {
            let lbl = normalizeVisibleText(AXHelper.label(el))
            if let range = lbl.range(of: "，第 "), lbl[range.upperBound...].contains("项") {
                let prefix = String(lbl[..<range.lowerBound])
                if let lastToken = prefix.split(whereSeparator: \.isWhitespace).last,
                   let rank = desiredEffortRank(String(lastToken)) {
                    found = rank
                    return false
                }
            }
        }
        return true
    }
    return found
}

func confirmPendingFullAccessDialog(in window: AXUIElement) {
    Thread.sleep(forTimeInterval: 0.35)
    let confirmLabels = ["继续", "确认", "开启完整访问权限", "开启完全访问权限", "allow", "continue", "confirm"]
    let candidates = visibleMenuCandidates(in: window)
    if let hit = candidates.first(where: { el, lbl in
        AXHelper.role(el) == kAXButtonRole && confirmLabels.contains(lbl.lowercased())
    }) {
        _ = AXHelper.press(hit.0)
        Thread.sleep(forTimeInterval: 0.25)
    }
}

func applyPermissionSetting(in window: AXUIElement, mode: String, triggerHints: [String]) -> (Bool, String) {
    guard let spec = permissionTargetLabels(for: mode) else {
        return (false, "invalid_permission_mode")
    }
    guard let btn = findToolbarButton(in: window, hints: triggerHints) else {
        return (false, "settings_button_not_found")
    }
    _ = AXHelper.press(btn)
    Thread.sleep(forTimeInterval: 0.35)
    let items = visibleMenuCandidates(in: window, excluding: btn)
    let targetEl = items.first(where: { _, lbl in
        let low = lbl.lowercased()
        return spec.labels.contains(where: { low == $0 || low.hasPrefix($0) || low.contains($0) })
    })?.0
    if let opt = targetEl {
        _ = AXHelper.press(opt)
        Thread.sleep(forTimeInterval: 0.25)
        if spec.yolo { confirmPendingFullAccessDialog(in: window) }
        return (true, "selected")
    }
    postKey(CGKeyCode(kVK_Escape))
    return (false, "settings_option_not_matched")
}

func openCombinedSettingsPopover(in window: AXUIElement, fallbackHints: [String]) -> AXUIElement? {
    guard let btn = findComposerSettingsButton(in: window) ?? findToolbarButton(in: window, hints: fallbackHints) else {
        return nil
    }
    _ = AXHelper.press(btn)
    Thread.sleep(forTimeInterval: 0.35)
    return btn
}

func applyModelSetting(in window: AXUIElement, model: String, fallbackHints: [String]) -> (Bool, String) {
    guard let btn = openCombinedSettingsPopover(in: window, fallbackHints: fallbackHints) else {
        return (false, "settings_button_not_found")
    }
    defer { postKey(CGKeyCode(kVK_Escape)); Thread.sleep(forTimeInterval: 0.15) }
    var items = visibleMenuCandidates(in: window, excluding: btn)
    if let cat = items.first(where: { _, lbl in
        lbl == "选择模型" || lbl.hasPrefix("模型 ") || lbl == "模型" || lbl.lowercased() == "select model" || lbl.lowercased().hasPrefix("model ")
    }) {
        _ = AXHelper.press(cat.0)
        Thread.sleep(forTimeInterval: 0.35)
        items = visibleMenuCandidates(in: window, excluding: btn)
    }
    if let exact = items.first(where: { _, lbl in modelMenuMatches(lbl, model: model) }) {
        _ = AXHelper.press(exact.0)
        Thread.sleep(forTimeInterval: 0.25)
        return (true, "selected")
    }
    let want = normalizeText(model).lowercased()
    if let contains = items.first(where: { _, lbl in lbl.lowercased().contains(want) }) {
        _ = AXHelper.press(contains.0)
        Thread.sleep(forTimeInterval: 0.25)
        return (true, "selected")
    }
    return (false, "settings_option_not_matched")
}

func applyEffortSetting(in window: AXUIElement, effort: String, fallbackHints: [String]) -> (Bool, String) {
    guard let targetRank = desiredEffortRank(effort) else {
        return (false, "settings_option_not_matched")
    }
    if targetRank == 5 {
        return (false, "confirmation_required")
    }
    guard let btn = openCombinedSettingsPopover(in: window, fallbackHints: fallbackHints) else {
        return (false, "settings_button_not_found")
    }
    defer { postKey(CGKeyCode(kVK_Escape)); Thread.sleep(forTimeInterval: 0.15) }
    let targets = effortOptionLabels(for: effort)
    var items = visibleMenuCandidates(in: window, excluding: btn)

    // Modern slider/scale ("强度") inside combined settings popover.
    if let scale = items.first(where: { _, lbl in lbl == "强度" || lbl.lowercased() == "effort" }) {
        var current = readModernEffortRank(in: window)
        if current == nil {
            let btnLbl = normalizeVisibleText(AXHelper.label(btn))
            if let lastToken = btnLbl.split(whereSeparator: \.isWhitespace).last {
                current = desiredEffortRank(String(lastToken))
            }
        }
        if var cur = current {
            if cur == targetRank { return (true, "already_selected") }
            _ = AXUIElementSetAttributeValue(scale.0, kAXFocusedAttribute as CFString, kCFBooleanTrue)
            Thread.sleep(forTimeInterval: 0.15)
            for _ in 0..<6 {
                if cur == targetRank { return (true, "selected") }
                let key = cur < targetRank ? CGKeyCode(kVK_RightArrow) : CGKeyCode(kVK_LeftArrow)
                postKey(key)
                Thread.sleep(forTimeInterval: 0.25)
                if let nextRank = readModernEffortRank(in: window) {
                    cur = nextRank
                } else {
                    cur += (cur < targetRank ? 1 : -1)
                }
            }
            if cur == targetRank { return (true, "selected") }
        }
    }

    if let cat = items.first(where: { _, lbl in lbl.hasPrefix("推理强度") || lbl.lowercased().hasPrefix("reasoning") }) {
        _ = AXHelper.press(cat.0)
        Thread.sleep(forTimeInterval: 0.35)
        items = visibleMenuCandidates(in: window, excluding: btn)
    }
    if let hit = items.first(where: { _, lbl in targets.contains(lbl.lowercased()) }) {
        _ = AXHelper.press(hit.0)
        Thread.sleep(forTimeInterval: 0.25)
        return (true, "selected")
    }
    return (false, "settings_option_not_matched")
}

func applyServiceTierSetting(in window: AXUIElement, tier: String, fallbackHints: [String]) -> (Bool, String) {
    guard let wantFast = requestedFastMode(tier) else {
        return (false, "settings_option_not_matched")
    }
    guard let btn = openCombinedSettingsPopover(in: window, fallbackHints: fallbackHints) else {
        return (false, "settings_button_not_found")
    }
    defer { postKey(CGKeyCode(kVK_Escape)); Thread.sleep(forTimeInterval: 0.15) }
    var items = visibleMenuCandidates(in: window, excluding: btn)
    if let toggle = items.first(where: { _, lbl in lbl == "启用快速模式" || lbl == "启用标准模式" || lbl.lowercased().contains("fast mode") }) {
        let isOn = AXHelper.boolAttr(toggle.0, kAXValueAttribute) ?? (AXHelper.valueStr(toggle.0) == "1")
        let desiredOn = (toggle.1 == "启用标准模式") ? !wantFast : wantFast
        if isOn != desiredOn {
            _ = AXHelper.press(toggle.0)
            Thread.sleep(forTimeInterval: 0.25)
        }
        return (true, "selected")
    }
    if let cat = items.first(where: { _, lbl in lbl.hasPrefix("速度") || lbl.lowercased().hasPrefix("speed") }) {
        _ = AXHelper.press(cat.0)
        Thread.sleep(forTimeInterval: 0.35)
        items = visibleMenuCandidates(in: window, excluding: btn)
    }
    let wantLabels = wantFast ? ["快速", "fast", "priority"] : ["标准", "standard", "default"]
    if let hit = items.first(where: { _, lbl in wantLabels.contains(where: { lbl.lowercased().hasPrefix($0) }) }) {
        _ = AXHelper.press(hit.0)
        Thread.sleep(forTimeInterval: 0.25)
        return (true, "selected")
    }
    return (false, "settings_option_not_matched")
}

func detectCollaborationMode(in window: AXUIElement) -> String? {
    let root = AXHelper.webArea(in: window) ?? window
    let winFrame = AXHelper.frame(window)
    let sidebarEdge = (winFrame?.minX ?? 0) + 260
    let bottomZoneY = (winFrame?.maxY ?? 0) - 260
    var mode: String? = nil
    AXHelper.walk(root, maxDepth: 64, maxNodes: 15000) { el, _ in
        let r = AXHelper.role(el)
        if r == kAXButtonRole || r == kAXCheckBoxRole {
            if let f = AXHelper.frame(el), f.minX < sidebarEdge || f.minY < bottomZoneY { return true }
            let lbl = normalizeVisibleText(AXHelper.label(el))
            let low = lbl.lowercased()
            if lbl.contains("退出计划") || low.contains("exit plan") {
                mode = "plan"
                return false
            }
            if lbl == "计划" || lbl == "计划模式" || low == "plan" || low == "plan mode" {
                let active = AXHelper.boolAttr(el, kAXValueAttribute) == true || AXHelper.valueStr(el) == "1"
                mode = active ? "plan" : "default"
                return false
            }
        }
        return true
    }
    return mode
}

func applyCollaborationMode(in window: AXUIElement, desired: String, planHints: [String]) -> (Bool, String, String?) {
    let want = desired.lowercased() == "plan" ? "plan" : "default"
    if let current = detectCollaborationMode(in: window), current == want {
        return (true, "already_selected", current)
    }
    if let btn = findToolbarButton(in: window, hints: planHints + ["退出计划", "计划模式", "plan mode"]) {
        _ = AXHelper.press(btn)
        Thread.sleep(forTimeInterval: 0.30)
        let after = detectCollaborationMode(in: window)
        if after == nil || after == want {
            return (true, "selected", after ?? want)
        }
        return (false, "plan_mode_unverified", after)
    }
    return (false, "plan_mode_unsupported", detectCollaborationMode(in: window))
}

func dumpControls(for app: NSRunningApplication, window: AXUIElement, mode: String? = nil) -> [String] {
    var lines: [String] = []
    let winFrame = AXHelper.frame(window)
    let wfStr = winFrame.map { "(\(Int($0.minX)),\(Int($0.minY)),\(Int($0.width))x\(Int($0.height)))" } ?? "?"
    lines.append("WIN title=\(AXHelper.title(window)) pid=\(app.processIdentifier) bundle=\(app.bundleIdentifier ?? "") frame=\(wfStr)")
    let root = AXHelper.webArea(in: window) ?? window
    lines.append("ROOT role=\(AXHelper.role(root)) url=\(AXHelper.urlStr(root))")
    let includeText = (mode == "text" || mode == "all")
    var visitedCount = 0
    AXHelper.walk(root, maxDepth: 64, maxNodes: 20000) { el, depth in
        visitedCount += 1
        let r = AXHelper.role(el)
        let sr = AXHelper.subrole(el)
        let lbl = AXHelper.label(el).replacingOccurrences(of: "\n", with: " ")
        let ph = AXHelper.stringAttr(el, "AXPlaceholderValue")
        let domId = AXHelper.stringAttr(el, "AXDOMIdentifier")
        let interestingRole = [
            kAXButtonRole, "AXLink", kAXTextAreaRole, kAXTextFieldRole, kAXComboBoxRole,
            kAXPopUpButtonRole, kAXMenuButtonRole, kAXMenuRole, kAXMenuItemRole,
            kAXRadioButtonRole, kAXCheckBoxRole, "AXHeading", "AXWebArea"
        ].contains(r) || (includeText && r == kAXStaticTextRole && !lbl.isEmpty)
        if interestingRole {
            var parts = ["d=\(depth)", r]
            if !sr.isEmpty { parts.append("sr=\(sr)") }
            if !lbl.isEmpty { parts.append("lbl=\(String(lbl.prefix(90)))") }
            if !ph.isEmpty { parts.append("ph=\(String(ph.prefix(50)))") }
            if !domId.isEmpty { parts.append("dom=\(domId)") }
            if let f = AXHelper.frame(el), f.width > 0 || f.height > 0 {
                parts.append("f=(\(Int(f.minX)),\(Int(f.minY)),\(Int(f.width))x\(Int(f.height)))")
            }
            if !AXHelper.isEnabled(el) { parts.append("disabled") }
            lines.append(parts.joined(separator: " | "))
            if lines.count >= 400 { return false }
        }
        return true
    }
    lines.append("STATS visited=\(visitedCount) controls=\(lines.count - 2)")
    return lines
}

// MARK: - Main Request Router

let axOperationLock = NSLock()

func handleRequest(_ req: AdapterRequest, transportId: UInt64?, writeLine: (String) -> Void = writeStdoutLine) -> AdapterResponse {
    axOperationLock.lock()
    defer { axOperationLock.unlock() }
    if req.action == "agent_presence" {
        return agentPresenceSnapshot()
    }
    if req.action == "ax_status" {
        let trusted = AXIsProcessTrusted()
        var resp = makeOk("ax_status", trusted ? "Accessibility trusted" : "Accessibility permission required", delivery: "not_sent")
        resp.axTrusted = trusted
        resp.screenLocked = isScreenLocked()
        return resp
    }
    if req.action == "prompt_accessibility" {
        let opts = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
        let trusted = AXIsProcessTrustedWithOptions(opts)
        var resp = makeOk("ax_prompted", trusted ? "Accessibility already trusted" : "Accessibility permission dialog triggered", delivery: "not_sent")
        resp.axTrusted = trusted
        resp.screenLocked = isScreenLocked()
        return resp
    }
    guard AXIsProcessTrusted() else {
        var resp = makeError("ax_permission_required", "需要在 macOS「系统设置 → 隐私与安全性 → 辅助功能」中允许 khLink Helper", delivery: "not_sent")
        resp.axTrusted = false
        return resp
    }
    if req.action == "antigravity" {
        return handleAntigravity(req, transportId: transportId, writeLine: writeLine)
    }
    guard let app = runningCodexApp() else {
        return makeError("desktop_not_ready", "Codex Desktop was not found")
    }
    guard let (_, window) = AXHelper.primaryWindow(of: app) else {
        return makeError("desktop_present", "Codex Desktop is running but has no accessible window")
    }

    switch req.action {
    case "inspect":
        let controls = dumpControls(for: app, window: window, mode: req.mode)
        for line in controls {
            FileHandle.standardError.write((line + "\n").data(using: .utf8)!)
        }
        var resp = makeOk("inspected", "Codex Desktop controls were listed", delivery: "not_sent")
        resp.controls = controls
        return resp

    case "probe":
        if req.threadId != nil {
            if let t = req.title, !t.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, isActiveTask(window: window, title: t) {
                let msg = findComposer(in: window) != nil
                    ? "The requested Codex task is the active Desktop writer"
                    : "The requested Codex task is active and still loading"
                return makeOk("task_active", msg, delivery: "not_sent")
            }
            if findComposer(in: window) != nil {
                return makeError("desktop_other_task", "Codex Desktop is open on another task; background protocol may write this task")
            }
            return makeError("desktop_present", "Codex Desktop is open but its composer is still loading")
        }
        return findComposer(in: window) != nil
            ? makeOk("ready", "Codex Desktop adapter is ready", delivery: "not_sent")
            : makeError("desktop_present", "Codex Desktop is open but its composer is still loading")

    case "open_thread":
        guard let title = req.title?.trimmingCharacters(in: .whitespacesAndNewlines), !title.isEmpty else {
            return makeError("missing_task_title", "The target task title is required")
        }
        if isScreenLocked() == true {
            return makeError("screen_locked", "Mac 已锁屏，暂时无法切换桌面会话")
        }
        let prev = frontmostApp()
        defer { if let p = prev, p.processIdentifier != app.processIdentifier { onMain { _ = p.activate() } } }
        if isActiveTask(window: window, title: title) {
            return makeOk("task_opened", "Codex Desktop is already on the requested task", delivery: "not_sent")
        }
        guard let item = findSidebarItem(in: window, title: title) else {
            return makeError("task_identity_unconfirmed", "Could not locate task in Codex sidebar")
        }
        AXHelper.scrollToVisible(item)
        _ = AXHelper.press(item)
        for _ in 0..<15 {
            Thread.sleep(forTimeInterval: 0.15)
            if isActiveTask(window: window, title: title) {
                return makeOk("task_opened", "Codex Desktop opened the requested task", delivery: "not_sent")
            }
        }
        return makeError("task_identity_unconfirmed", "Clicked sidebar item but target task did not become active")

    case "interrupt":
        if isScreenLocked() == true {
            return makeError("screen_locked", "Mac 已锁屏，无法停止桌面任务")
        }
        if let title = req.title?.trimmingCharacters(in: .whitespacesAndNewlines), !title.isEmpty, !isActiveTask(window: window, title: title) {
            if let item = findSidebarItem(in: window, title: title) {
                AXHelper.scrollToVisible(item)
                _ = AXHelper.press(item)
                Thread.sleep(forTimeInterval: 0.35)
            }
        }
        guard let stopBtn = findStopButton(in: window) else {
            return makeError("stop_button_not_found", "Stop button was not found in Codex Desktop")
        }
        emitWritePhase(transportId, writeLine: writeLine)
        _ = AXHelper.press(stopBtn)
        return makeOk("interrupted", "Codex Desktop stop button invoked")

    case "dispatch":
        guard let reqId = req.requestId, !reqId.isEmpty else {
            return makeError("missing_request_id", "requestId is required")
        }
        if isScreenLocked() == true {
            return makeError("screen_locked", "Mac 已锁屏，无法向桌面输入框发送消息")
        }
        let text = req.text ?? ""
        let attachments = req.attachments ?? []
        if text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && attachments.isEmpty {
            return makeError("empty_message", "Message text or attachment is required")
        }
        let prev = frontmostApp()
        defer { if let p = prev, p.processIdentifier != app.processIdentifier { onMain { _ = p.activate() } } }

        if let title = req.title?.trimmingCharacters(in: .whitespacesAndNewlines), !title.isEmpty, !isActiveTask(window: window, title: title) {
            guard let item = findSidebarItem(in: window, title: title) else {
                return makeError("task_identity_unconfirmed", "Could not locate target task in Codex Desktop")
            }
            AXHelper.scrollToVisible(item)
            _ = AXHelper.press(item)
            var opened = false
            for _ in 0..<20 {
                Thread.sleep(forTimeInterval: 0.15)
                if isActiveTask(window: window, title: title) { opened = true; break }
            }
            if !opened {
                return makeError("task_identity_unconfirmed", "Target task did not open in Codex Desktop")
            }
        }

        guard let composer = findComposer(in: window) else {
            return makeError("composer_not_found", "Could not locate composer in Codex Desktop")
        }
        if composerHasDraft(composer) {
            return makeError("draft_in_composer", "Codex Desktop composer already has unsent text")
        }
        guard activateAndFocus(app, window: window, editor: composer) else {
            return makeError("focus_failed", "Could not focus Codex Desktop composer")
        }

        let savedClipboard = saveClipboard()
        defer { restoreClipboard(savedClipboard) }

        if !attachments.isEmpty {
            let urls = attachments.map { URL(fileURLWithPath: $0.path) as NSURL }
            let pb = NSPasteboard.general
            pb.clearContents()
            pb.writeObjects(urls)
            postKey(CGKeyCode(kVK_ANSI_V), flags: .maskCommand)
            Thread.sleep(forTimeInterval: 0.45)
        }
        if !text.isEmpty {
            func pasteText() -> Bool {
                let pb = NSPasteboard.general
                pb.clearContents()
                pb.setString(text, forType: .string)
                postKey(CGKeyCode(kVK_ANSI_V), flags: .maskCommand)
                for _ in 0..<6 {
                    Thread.sleep(forTimeInterval: 0.10)
                    if composerHasDraft(composer) { return true }
                }
                return false
            }
            var pasted = pasteText()
            if !pasted {
                _ = activateAndFocus(app, window: window, editor: composer)
                pasted = pasteText()
            }
            if !pasted && attachments.isEmpty {
                return makeError("paste_failed", "Could not verify text pasted into Codex Desktop composer", delivery: "not_sent")
            }
        }

        let sendCandidate = findSendButton(in: window, mode: req.mode)
        if (req.mode ?? "").lowercased() == "queue" && sendCandidate == nil {
            // Desktop composer only offers Steer (not Queue) right now. Clear our
            // pasted text so we never leave a draft or steer early.
            if !text.isEmpty && composerHasDraft(composer) {
                postKey(CGKeyCode(kVK_ANSI_A), flags: .maskCommand)
                Thread.sleep(forTimeInterval: 0.05)
                postKey(CGKeyCode(kVK_Delete))
                Thread.sleep(forTimeInterval: 0.15)
            }
            return makeError("control_not_found", "Codex Desktop queue control was not available", delivery: "not_sent")
        }

        emitWritePhase(transportId, writeLine: writeLine)
        if let sendBtn = sendCandidate {
            _ = AXHelper.press(sendBtn.element)
        } else {
            postKey(CGKeyCode(kVK_Return))
        }
        var cleared = false
        for attempt in 0..<12 {
            Thread.sleep(forTimeInterval: 0.10)
            if !composerHasDraft(composer) { cleared = true; break }
            if attempt == 4 {
                postKey(CGKeyCode(kVK_Return))
            }
        }
        if !cleared && !text.isEmpty {
            return makeError("submit_unconfirmed", "Submitted to Codex Desktop but composer still contains text", delivery: "uncertain")
        }
        if (req.mode ?? "").lowercased() == "steer" {
            return makeOk(sendCandidate?.isSteer == true ? "steer_accepted" : "dispatched", "Message steered to Codex Desktop")
        }
        return makeOk("dispatched", "Message submitted to Codex Desktop")

    case "list_queued":
        let active = detectActiveTitle(window: window, knownTitles: req.knownTitles ?? [])
        let items = listQueuedItems(in: window)
        var resp = makeOk("queued_listed", "Listed queued items", delivery: "not_sent")
        resp.activeTitle = active
        resp.items = items
        if let title = active, let approval = detectApprovalStatus(window: window, title: title) {
            resp.reason = approval ? "desktop_approval_pending" : "desktop_approval_clear"
        }
        resp.effectiveCollaborationMode = detectCollaborationMode(in: window)
        return resp

    case "cancel":
        if isScreenLocked() == true {
            return makeError("screen_locked", "Mac 已锁屏，无法取消排队消息")
        }
        guard let text = req.text, !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            return makeError("missing_text", "Queued item text is required")
        }
        if let title = req.title?.trimmingCharacters(in: .whitespacesAndNewlines), !title.isEmpty, !isActiveTask(window: window, title: title) {
            if let item = findSidebarItem(in: window, title: title) {
                AXHelper.scrollToVisible(item)
                _ = AXHelper.press(item)
                Thread.sleep(forTimeInterval: 0.35)
            }
        }
        let cfg = loadSelectors()
        let cancelHints = hints(cfg.queuedCancelLabels, fallback: SelectorConfig.defaults.queuedCancelLabels!)
        guard invokeQueuedRowAction(in: window, text: text, actionHints: cancelHints, transportId: transportId, writeLine: writeLine) else {
            return makeError("queued_item_not_found", "Could not locate queued item cancel button")
        }
        return makeOk("cancelled", "Queued message cancelled in Codex Desktop")

    case "steer_queued":
        if isScreenLocked() == true {
            return makeError("screen_locked", "Mac 已锁屏，无法插队发送消息")
        }
        guard let text = req.text, !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            return makeError("missing_text", "Queued item text is required")
        }
        if let title = req.title?.trimmingCharacters(in: .whitespacesAndNewlines), !title.isEmpty, !isActiveTask(window: window, title: title) {
            if let item = findSidebarItem(in: window, title: title) {
                AXHelper.scrollToVisible(item)
                _ = AXHelper.press(item)
                Thread.sleep(forTimeInterval: 0.35)
            }
        }
        let cfg = loadSelectors()
        let steerHints = hints(cfg.queuedSteerLabels, fallback: SelectorConfig.defaults.queuedSteerLabels!)
        guard invokeQueuedRowAction(in: window, text: text, actionHints: steerHints, transportId: transportId, writeLine: writeLine) else {
            return makeError("queued_item_not_found", "Could not locate queued item steer button")
        }
        return makeOk("steered", "Queued message steered in Codex Desktop")

    case "settings":
        if isScreenLocked() == true {
            return makeError("screen_locked", "Mac 已锁屏，无法同步桌面设置")
        }
        if req.model == nil && req.effort == nil && req.serviceTier == nil && req.permissionMode == nil && req.collaborationMode == nil {
            return makeError("empty_settings", "No desktop setting was requested", delivery: "not_sent")
        }
        let prev = frontmostApp()
        defer { if let p = prev, p.processIdentifier != app.processIdentifier { onMain { _ = p.activate() } } }
        guard activateAppWindow(app, window: window) else {
            return makeError("focus_failed", "Could not activate Codex Desktop window", delivery: "not_sent")
        }
        if let title = req.title?.trimmingCharacters(in: .whitespacesAndNewlines), !title.isEmpty, !isActiveTask(window: window, title: title) {
            guard let item = findSidebarItem(in: window, title: title) else {
                return makeError("task_identity_unconfirmed", "Could not locate target task in Codex Desktop")
            }
            AXHelper.scrollToVisible(item)
            _ = AXHelper.press(item)
            var opened = false
            for _ in 0..<15 {
                Thread.sleep(forTimeInterval: 0.15)
                if isActiveTask(window: window, title: title) { opened = true; break }
            }
            if !opened {
                return makeError("task_identity_unconfirmed", "Target task did not open in Codex Desktop")
            }
        }
        let cfg = loadSelectors()
        var effectiveMode: String? = nil
        var desiredMode: String? = nil
        var modeSyncState: String? = nil
        if let mode = req.collaborationMode, !mode.isEmpty {
            let lower = mode.lowercased()
            guard lower == "plan" || lower == "default" || lower == "execute" else {
                var err = makeError("invalid_collaboration_mode", "Unknown collaboration mode", delivery: "not_sent")
                err.desiredCollaborationMode = mode
                err.modeSyncState = "failed"
                return err
            }
            desiredMode = lower == "plan" ? "plan" : "default"
            let (ok, code, actual) = applyCollaborationMode(in: window, desired: desiredMode!, planHints: hints(cfg.planButtonHints, fallback: SelectorConfig.defaults.planButtonHints!))
            if !ok {
                var err = makeError(code, "Could not apply collaboration mode \(desiredMode!) in Codex Desktop", delivery: "not_sent")
                err.effectiveCollaborationMode = actual
                err.desiredCollaborationMode = desiredMode
                err.modeSyncState = "failed"
                return err
            }
            effectiveMode = actual ?? desiredMode
            modeSyncState = "applied"
            Thread.sleep(forTimeInterval: 0.15)
        }
        if let model = req.model, !model.isEmpty {
            let (ok, code) = applyModelSetting(in: window, model: model, fallbackHints: hints(cfg.modelButtonHints, fallback: SelectorConfig.defaults.modelButtonHints!))
            if !ok { return makeError(code, "Could not select model \(model) in Codex Desktop") }
            Thread.sleep(forTimeInterval: 0.15)
        }
        if let effort = req.effort, !effort.isEmpty {
            let (ok, code) = applyEffortSetting(in: window, effort: effort, fallbackHints: hints(cfg.effortButtonHints, fallback: SelectorConfig.defaults.effortButtonHints!))
            if !ok { return makeError(code, "Could not select reasoning effort \(effort) in Codex Desktop") }
            Thread.sleep(forTimeInterval: 0.15)
        }
        if let tier = req.serviceTier, !tier.isEmpty {
            let (ok, code) = applyServiceTierSetting(in: window, tier: tier, fallbackHints: hints(cfg.modelButtonHints, fallback: SelectorConfig.defaults.modelButtonHints!))
            if !ok { return makeError(code, "Could not select service tier \(tier) in Codex Desktop") }
            Thread.sleep(forTimeInterval: 0.15)
        }
        if let perm = req.permissionMode, !perm.isEmpty {
            let (ok, code) = applyPermissionSetting(in: window, mode: perm, triggerHints: hints(cfg.permissionButtonHints, fallback: SelectorConfig.defaults.permissionButtonHints!))
            if !ok { return makeError(code, "Could not select permission mode \(perm) in Codex Desktop") }
        }
        var resp = makeOk("settings_updated", "Codex Desktop settings updated", delivery: "not_sent")
        resp.effectiveCollaborationMode = effectiveMode
        resp.desiredCollaborationMode = desiredMode
        resp.modeSyncState = modeSyncState
        return resp

    default:
        return makeError("unsupported_action", "Unsupported macOS adapter action: \(req.action)")
    }
}

func writeAllFd(_ fd: Int32, _ data: Data) -> Bool {
    data.withUnsafeBytes { raw in
        guard let base = raw.baseAddress else { return true }
        var sent = 0
        while sent < data.count {
            let n = Darwin.write(fd, base.advanced(by: sent), data.count - sent)
            if n <= 0 {
                if errno == EINTR { continue }
                return false
            }
            sent += n
        }
        return true
    }
}

func handleSocketClient(_ clientFd: Int32) {
    defer { Darwin.close(clientFd) }
    var euid: uid_t = 0
    var egid: gid_t = 0
    if getpeereid(clientFd, &euid, &egid) != 0 || euid != geteuid() {
        return
    }
    let writeLock = NSLock()
    let writeLine: (String) -> Void = { line in
        guard let data = (line + "\n").data(using: .utf8) else { return }
        writeLock.lock()
        _ = writeAllFd(clientFd, data)
        writeLock.unlock()
    }
    var buffer = Data()
    var chunk = [UInt8](repeating: 0, count: 8192)
    while true {
        let n = Darwin.read(clientFd, &chunk, chunk.count)
        if n < 0 {
            if errno == EINTR { continue }
            break
        }
        if n == 0 { break }
        buffer.append(chunk, count: n)
        if buffer.count > 16 * 1024 * 1024 {
            break
        }
        while let nlIndex = buffer.firstIndex(of: 0x0A) {
            let lineData = buffer.subdata(in: 0..<nlIndex)
            buffer.removeSubrange(0...nlIndex)
            guard let lineStr = String(data: lineData, encoding: .utf8) else { continue }
            let trimmed = lineStr.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.isEmpty { continue }
            guard let reqData = trimmed.data(using: .utf8),
                  let env = try? jsonDecoder.decode(ServeEnvelope.self, from: reqData) else {
                continue
            }
            let resp = handleRequest(env.request, transportId: env.id, writeLine: writeLine)
            let out = ServeResponseEnvelope(id: env.id, response: resp)
            if let encoded = try? jsonEncoder.encode(out), let str = String(data: encoded, encoding: .utf8) {
                writeLine(str)
            }
        }
    }
}

func runSocketServer(path: String) {
    signal(SIGPIPE, SIG_IGN)
    let dir = (path as NSString).deletingLastPathComponent
    if !dir.isEmpty {
        try? FileManager.default.createDirectory(atPath: dir, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
    }
    Darwin.unlink(path)

    let serverFd = Darwin.socket(AF_UNIX, SOCK_STREAM, 0)
    guard serverFd >= 0 else {
        fputs("failed to create unix socket\n", stderr)
        exit(2)
    }

    var addr = sockaddr_un()
    addr.sun_family = sa_family_t(AF_UNIX)
    let pathBytes = Array(path.utf8CString)
    let maxLen = MemoryLayout.size(ofValue: addr.sun_path)
    guard pathBytes.count <= maxLen else {
        fputs("socket path too long: \(path)\n", stderr)
        Darwin.close(serverFd)
        exit(2)
    }
    withUnsafeMutablePointer(to: &addr.sun_path) { ptr in
        ptr.withMemoryRebound(to: CChar.self, capacity: maxLen) { dst in
            for i in 0..<pathBytes.count {
                dst[i] = pathBytes[i]
            }
        }
    }
    let addrLen = socklen_t(MemoryLayout<sockaddr_un>.size)
    let oldMask = Darwin.umask(0o077)
    let bindRes = withUnsafePointer(to: &addr) { ptr in
        ptr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sa in
            Darwin.bind(serverFd, sa, addrLen)
        }
    }
    _ = Darwin.umask(oldMask)
    guard bindRes == 0 else {
        fputs("failed to bind unix socket at \(path): errno=\(errno)\n", stderr)
        Darwin.close(serverFd)
        exit(2)
    }
    _ = Darwin.chmod(path, 0o600)
    guard Darwin.listen(serverFd, 16) == 0 else {
        fputs("failed to listen on unix socket\n", stderr)
        Darwin.close(serverFd)
        Darwin.unlink(path)
        exit(2)
    }

    let app = NSApplication.shared
    app.setActivationPolicy(.prohibited)
    // The helper runs from khLink.app, so macOS takes it for "khLink is already open" and sends a
    // double click in Finder (or `open`) here. Pass it on to the menu bar app.
    let reopen = HelperReopenDelegate()
    app.delegate = reopen
    let acceptQueue = DispatchQueue(label: "vip.fengzhu.khlink.helper.accept")
    let clientQueue = DispatchQueue(label: "vip.fengzhu.khlink.helper.clients", attributes: .concurrent)
    acceptQueue.async {
        while true {
            let clientFd = Darwin.accept(serverFd, nil, nil)
            if clientFd < 0 {
                if errno == EINTR { continue }
                usleep(50_000)
                continue
            }
            clientQueue.async {
                handleSocketClient(clientFd)
            }
        }
    }
    withExtendedLifetime(reopen) { app.run() }
}

final class HelperReopenDelegate: NSObject, NSApplicationDelegate {
    private var last = Date.distantPast
    private func openTray() {
        // Debounce: open and reopen events can both arrive for one double click.
        guard Date().timeIntervalSince(last) > 2 else { return }
        last = Date()
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/usr/bin/open")
        // -n: a separate menu bar process; if one already runs it shows its window and exits.
        p.arguments = ["-n", Bundle.main.bundlePath, "--args", "--show"]
        try? p.run()
    }
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool { openTray(); return false }
    func application(_ application: NSApplication, open urls: [URL]) { openTray() }
}

func runServe() {
    while let line = readLine() {
        let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty { continue }
        guard let data = trimmed.data(using: .utf8),
              let env = try? jsonDecoder.decode(ServeEnvelope.self, from: data) else {
            continue
        }
        let resp = handleRequest(env.request, transportId: env.id)
        let out = ServeResponseEnvelope(id: env.id, response: resp)
        if let encoded = try? jsonEncoder.encode(out), let str = String(data: encoded, encoding: .utf8) {
            writeStdoutLine(str)
        }
    }
}

// MARK: - Entry Point

let args = Array(CommandLine.arguments.dropFirst())

if args.contains("--screen-monitor") {
    runScreenMonitor()
    exit(0)
}

if let idx = args.firstIndex(of: "--socket"), idx + 1 < args.count {
    runSocketServer(path: args[idx + 1])
    exit(0)
}

if args.contains("--prompt-accessibility") {
    let opts = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
    let trusted = AXIsProcessTrustedWithOptions(opts)
    let bid = Bundle.main.bundleIdentifier ?? ""
    let bpath = Bundle.main.bundlePath
    writeStdoutLine("{\"trusted\":\(trusted ? "true" : "false"),\"bundleId\":\"\(bid)\",\"bundlePath\":\"\(bpath)\"}")
    exit(trusted ? 0 : 1)
}

if args.contains("--check-accessibility") {
    let trusted = AXIsProcessTrusted()
    let bid = Bundle.main.bundleIdentifier ?? ""
    let bpath = Bundle.main.bundlePath
    writeStdoutLine("{\"trusted\":\(trusted ? "true" : "false"),\"bundleId\":\"\(bid)\",\"bundlePath\":\"\(bpath)\"}")
    exit(trusted ? 0 : 1)
}

if args.contains("--serve") {
    runServe()
    exit(0)
}

// Launched as an app (Finder, login item, `open`): the menu bar app. The
// connector only ever starts this binary with one of the flags above.
if !args.contains("--once") && args.allSatisfy({ $0.hasPrefix("-psn") || $0.hasPrefix("-NS") || $0 == "YES" || $0 == "NO" || $0 == "--show" || $0 == "--background" || $0 == "--snapshot" }) {
    runTrayApp()
    exit(0)
}

// Single-shot JSON on stdin (`--once`)
let inputData = FileHandle.standardInput.readDataToEndOfFile()
guard let req = try? jsonDecoder.decode(AdapterRequest.self, from: inputData) else {
    let err = makeError("invalid_input", "Invalid JSON request")
    if let data = try? jsonEncoder.encode(err), let str = String(data: data, encoding: .utf8) {
        writeStdoutLine(str)
    }
    exit(2)
}
let result = handleRequest(req, transportId: nil)
if let data = try? jsonEncoder.encode(result), let str = String(data: data, encoding: .utf8) {
    writeStdoutLine(str)
}
exit(result.ok ? 0 : (result.delivery == "uncertain" ? 3 : 2))
