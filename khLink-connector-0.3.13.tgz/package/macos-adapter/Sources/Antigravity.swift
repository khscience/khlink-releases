// Google Antigravity (com.google.antigravity) on macOS, driven through its
// window the way scripts/antigravity-send.ps1 does on Windows: open the
// conversation from its sidebar link (/c/<id>), paste into "Message input",
// press "Send message"; "Stop" for stop. One JSON result per request, in
// AdapterResponse.payload, with the same fields the Windows script prints.
// It never uses Antigravity's local server, debugging port or sign-in token.
import AppKit
import ApplicationServices
import Carbon.HIToolbox
import Foundation

struct AGResult: Encodable {
    var ok: Bool
    var reason: String? = nil
    var mayHaveSent: Bool? = nil
    var receiptSource: String? = nil
    var confirmedAt: Double? = nil
    var queuedInWindow: Bool? = nil
    var steered: Bool? = nil
    var conversationId: String? = nil
    var ids: [String]? = nil
    var sendEnabled: Bool? = nil
    var queuedItems: [String]? = nil
}

private func agResponse(_ r: AGResult, controls: [String]? = nil) -> AdapterResponse {
    var resp = r.ok ? makeOk("antigravity", r.reason ?? "ok", delivery: r.mayHaveSent == false ? "not_sent" : "sent")
        : makeError(r.reason ?? "failed", r.reason ?? "failed", delivery: r.mayHaveSent == true ? "uncertain" : "not_sent")
    if let data = try? jsonEncoder.encode(r) { resp.payload = String(data: data, encoding: .utf8) }
    resp.controls = controls
    return resp
}

private func agFail(_ reason: String, mayHaveSent: Bool = false) -> AdapterResponse {
    agResponse(AGResult(ok: false, reason: reason, mayHaveSent: mayHaveSent))
}

private let agIdPattern = try! NSRegularExpression(pattern: "/c/([0-9a-f-]{36})(?:[?#/]|$)")

func agConversationId(inURL url: String) -> String? {
    let range = NSRange(url.startIndex..., in: url)
    guard let m = agIdPattern.firstMatch(in: url, range: range), let r = Range(m.range(at: 1), in: url) else { return nil }
    return String(url[r])
}

private func agNorm(_ s: String) -> String {
    s.replacingOccurrences(of: "\r", with: "").replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression).trimmingCharacters(in: .whitespacesAndNewlines)
}

/// The window whose page shows a conversation, or the largest one.
private func agWindow(_ app: NSRunningApplication) -> AXUIElement? {
    let axApp = AXHelper.appElement(for: app)
    let wins = AXHelper.windows(axApp)
    if wins.isEmpty { return nil }
    let scored = wins.map { w -> (AXUIElement, CGFloat) in
        let f = AXHelper.frame(w) ?? .zero
        return (w, f.width * f.height)
    }
    return scored.max(by: { $0.1 < $1.1 })?.0
}

private func agWebAreas(_ window: AXUIElement) -> [AXUIElement] {
    var out: [AXUIElement] = []
    // Antigravity 2.35 wraps its page in a blank data: web area; the page
    // with the /c/<id> address is nested inside it, so keep looking inside.
    AXHelper.walk(window, maxDepth: 60, maxNodes: 12000) { el, _ in
        if AXHelper.role(el) == "AXWebArea" { out.append(el) }
        return true
    }
    return out
}

private func agCurrentId(_ window: AXUIElement) -> String? {
    for area in agWebAreas(window) { if let id = agConversationId(inURL: AXHelper.urlStr(area)) { return id } }
    return nil
}

private func agFind(_ window: AXUIElement, maxNodes: Int = 30000, _ match: (AXUIElement, String, String) -> Bool) -> AXUIElement? {
    var found: AXUIElement?
    AXHelper.walk(window, maxDepth: 80, maxNodes: maxNodes) { el, _ in
        if found != nil { return false }
        let role = AXHelper.role(el)
        if match(el, role, AXHelper.label(el)) { found = el; return false }
        return true
    }
    return found
}

private func agFindAll(_ window: AXUIElement, _ match: (AXUIElement, String, String) -> Bool) -> [AXUIElement] {
    var out: [AXUIElement] = []
    AXHelper.walk(window, maxDepth: 80, maxNodes: 30000) { el, _ in
        if match(el, AXHelper.role(el), AXHelper.label(el)) { out.append(el) }
        return true
    }
    return out
}

private func agLink(_ window: AXUIElement, id: String) -> AXUIElement? {
    agFind(window) { el, role, _ in role == "AXLink" && AXHelper.urlStr(el).contains("/c/\(id)") }
}

private func agMessageBox(_ window: AXUIElement) -> AXUIElement? {
    let candidates = agFindAll(window) { el, role, label in
        let ph = AXHelper.stringAttr(el, "AXPlaceholderValue")
        return [kAXTextAreaRole, kAXComboBoxRole, kAXTextFieldRole].contains(role)
            && (AXHelper.desc(el) == "Message input" || AXHelper.title(el) == "Message input" || ph.hasPrefix("Message") || label == "Message input")
    }
    // The composer of the open conversation is the lowest one on screen.
    return candidates.max(by: { (AXHelper.frame($0)?.minY ?? 0) < (AXHelper.frame($1)?.minY ?? 0) })
}

/// The editor reports its placeholder while empty.
private func agBoxText(_ box: AXUIElement) -> String {
    let v = AXHelper.valueStr(box)
    let ph = AXHelper.stringAttr(box, "AXPlaceholderValue")
    if v == "Message input" || (!ph.isEmpty && v == ph) { return "" }
    return v.trimmingCharacters(in: .whitespacesAndNewlines)
}

private func agButton(_ window: AXUIElement, _ pattern: String) -> AXUIElement? {
    let re = try! NSRegularExpression(pattern: pattern, options: [.caseInsensitive])
    return agFind(window) { _, role, label in
        role == kAXButtonRole && re.firstMatch(in: label, range: NSRange(label.startIndex..., in: label)) != nil
    }
}

/// This box's own Send: with several panes (or a side chat) open there is
/// more than one, and the first one found can be another pane's. Take the
/// one nearest this box and wait for it to become enabled.
private func agSendButton(_ window: AXUIElement, box: AXUIElement?) -> AXUIElement? {
    let candidates = agFindAll(window) { _, role, label in
        role == kAXButtonRole && ["send message", "send"].contains(label.trimmingCharacters(in: .whitespaces).lowercased())
    }
    let anchor = box.flatMap { AXHelper.frame($0) }
    func distance(_ el: AXUIElement) -> CGFloat {
        guard let a = anchor, let f = AXHelper.frame(el) else { return .greatestFiniteMagnitude }
        return hypot(f.midX - a.maxX, f.midY - a.maxY)
    }
    // Only the nearest: an enabled Send further away is another pane's,
    // possibly holding the user's own draft.
    return candidates.min { distance($0) < distance($1) }
}

/// Messages Antigravity holds until the running turn ends: each queued row
/// has "Send now: <text>", "Edit: <text>" and "Delete: <text>" buttons.
private func agQueued(_ window: AXUIElement, _ verb: String = "Send now") -> [(AXUIElement, String)] {
    let prefix = verb.lowercased() + ": "
    var out: [(AXUIElement, String)] = []
    for el in agFindAll(window, { _, role, label in role == kAXButtonRole && label.lowercased().hasPrefix(prefix) }) {
        out.append((el, String(AXHelper.label(el).dropFirst(prefix.count))))
    }
    return out
}

/// A row shows its text in full or cut short; either way it matches.
private func agSameQueued(_ a: String, _ b: String) -> Bool {
    let x = agNorm(a).lowercased(), y = agNorm(b).lowercased()
    if x.isEmpty || y.isEmpty { return false }
    return x == y || x.hasPrefix(y) || y.hasPrefix(x)
}

/// "Send now" (steer) or "Delete" (cancel) on the queued row for `text`.
private func agQueuedAction(_ window: AXUIElement, text: String, verb: String, done: String, missing: String) -> AdapterResponse {
    let items = agQueued(window).map { $0.1 }
    func fail(_ reason: String) -> AdapterResponse {
        var r = AGResult(ok: false, reason: reason, mayHaveSent: false); r.queuedItems = items; return agResponse(r)
    }
    if items.isEmpty { return fail("no_queue") }
    guard agQueued(window).contains(where: { agSameQueued($0.1, text) }) else { return fail("queued_item_not_found") }
    guard let button = agQueued(window, verb).first(where: { agSameQueued($0.1, text) })?.0 else { return fail(missing) }
    if !AXHelper.press(button), let f = AXHelper.frame(button) { postLeftClick(at: CGPoint(x: f.midX, y: f.midY)) }
    var after = items
    for _ in 0..<15 {
        Thread.sleep(forTimeInterval: 0.2)
        after = agQueued(window).map { $0.1 }
        if after.count < items.count || !after.contains(where: { agSameQueued($0, text) }) {
            var r = AGResult(ok: true, reason: done, mayHaveSent: verb == "Send now"); r.queuedItems = after; return agResponse(r)
        }
    }
    var r = AGResult(ok: false, reason: verb == "Send now" ? "steer_invoke_failed" : "delete_invoke_failed", mayHaveSent: verb == "Send now")
    r.queuedItems = after
    return agResponse(r)
}

private func agMatchingTextCount(_ window: AXUIElement, _ text: String) -> Int {
    let want = agNorm(text)
    if want.isEmpty { return 0 }
    return agFindAll(window) { el, role, _ in
        role == kAXStaticTextRole && agNorm(AXHelper.valueStr(el).isEmpty ? AXHelper.label(el) : AXHelper.valueStr(el)) == want
    }.count
}

private func agClearBox(_ box: AXUIElement) {
    postKey(CGKeyCode(kVK_ANSI_A), flags: .maskCommand)
    Thread.sleep(forTimeInterval: 0.05)
    postKey(CGKeyCode(kVK_Delete))
    Thread.sleep(forTimeInterval: 0.15)
}

/// Open the conversation in the window and wait until its page shows it.
private func agOpen(_ window: AXUIElement, id: String) -> Bool {
    if agCurrentId(window) == id { return true }
    var link = agLink(window, id: id)
    if link == nil {
        // A project lists only its latest conversations behind "See all (N)".
        for more in agFindAll(window, { _, role, label in role == kAXButtonRole && label.range(of: "^See all \\(\\d+\\)$", options: .regularExpression) != nil }) {
            _ = AXHelper.press(more)
            Thread.sleep(forTimeInterval: 0.3)
            if let l = agLink(window, id: id) { link = l; break }
        }
    }
    guard let target = link else { return false }
    AXHelper.scrollToVisible(target)
    if !AXHelper.press(target), let f = AXHelper.frame(target) { postLeftClick(at: CGPoint(x: f.midX, y: f.midY)) }
    for _ in 0..<30 {
        Thread.sleep(forTimeInterval: 0.15)
        if agCurrentId(window) == id { return true }
    }
    return false
}

func handleAntigravity(_ req: AdapterRequest, transportId: UInt64?, writeLine: (String) -> Void) -> AdapterResponse {
    guard let app = runningAntigravityApp() else { return agFail("not_running") }
    guard let window = agWindow(app) else { return agFail("not_running") }
    let mode = (req.mode ?? "send").lowercased()
    let id = (req.threadId ?? "").lowercased()

    switch mode {
    case "inspect":
        if req.text == "windows" {
            var lines: [String] = []
            for w in AXHelper.windows(AXHelper.appElement(for: app)) {
                let f = AXHelper.frame(w) ?? .zero
                lines.append("WIN title=\(AXHelper.title(w)) frame=(\(Int(f.minX)),\(Int(f.minY)),\(Int(f.width))x\(Int(f.height)))")
                for area in agWebAreas(w) { lines.append("  AREA url=\(String(AXHelper.urlStr(area).prefix(160)))") }
                let links = agFindAll(w) { _, role, _ in role == "AXLink" }.prefix(12)
                for l in links { lines.append("  LINK \(String(AXHelper.label(l).prefix(40))) url=\(String(AXHelper.urlStr(l).prefix(120)))") }
                for b in agFindAll(w, { _, role, _ in role == kAXButtonRole }).prefix(60) {
                    let f = AXHelper.frame(b) ?? .zero
                    lines.append("  BUTTON \(String(AXHelper.label(b).prefix(40)))\(AXHelper.isEnabled(b) ? "" : " (disabled)") at=(\(Int(f.midX)),\(Int(f.midY)))")
                }
                if let box = agMessageBox(w), let f = AXHelper.frame(box) { lines.append("  BOX at=(\(Int(f.minX)),\(Int(f.minY)),\(Int(f.width))x\(Int(f.height)))") }
            }
            return agResponse(AGResult(ok: true, reason: "inspected", mayHaveSent: false, conversationId: agCurrentId(window)), controls: lines)
        }
        return agResponse(AGResult(ok: true, reason: "inspected", mayHaveSent: false, conversationId: agCurrentId(window)), controls: dumpControls(for: app, window: window, mode: req.text))
    case "list":
        let ids = agFindAll(window) { el, role, _ in role == "AXLink" && agConversationId(inURL: AXHelper.urlStr(el)) != nil }
            .compactMap { agConversationId(inURL: AXHelper.urlStr($0)) }
        return agResponse(AGResult(ok: true, reason: "listed", mayHaveSent: false, ids: Array(NSOrderedSet(array: ids)) as? [String]))
    case "probe", "open":
        guard !id.isEmpty else { return agFail("conversation_not_in_sidebar") }
        if mode == "probe" {
            let open = agCurrentId(window) == id
            let known = open || agLink(window, id: id) != nil
            if !known { return agFail("conversation_not_in_sidebar") }
            let box = open ? agMessageBox(window) : nil
            let send = open ? agSendButton(window, box: box) : nil
            var r = AGResult(ok: true, reason: "probed", mayHaveSent: false, conversationId: agCurrentId(window))
            r.sendEnabled = send.map { AXHelper.isEnabled($0) }
            if open && box == nil { return agFail("no_message_box") }
            return agResponse(r)
        }
        return agOpen(window, id: id) ? agResponse(AGResult(ok: true, reason: "opened", mayHaveSent: false, conversationId: id)) : agFail("conversation_not_opened")
    case "queue", "steer", "cancel_queued":
        guard !id.isEmpty, agOpen(window, id: id) else { return agFail("conversation_not_opened") }
        if mode == "queue" {
            var r = AGResult(ok: true, reason: "queue", mayHaveSent: false, conversationId: id)
            r.queuedItems = agQueued(window).map { $0.1 }
            return agResponse(r)
        }
        return mode == "steer"
            ? agQueuedAction(window, text: req.text ?? "", verb: "Send now", done: "steered", missing: "steer_button_not_found")
            : agQueuedAction(window, text: req.text ?? "", verb: "Delete", done: "deleted", missing: "delete_button_not_found")
    case "stop":
        guard !id.isEmpty, agOpen(window, id: id) else { return agFail("conversation_not_opened") }
        // The composer's own cancel ("Cancel (⌃C)" in 2.35, "Cancel (Ctrl+C)"
        // before), the one nearest the message box. A bare "Cancel" can be any
        // dialog's. Else this conversation's own sidebar row "Stop execution".
        let box = agMessageBox(window)
        let composerStop = try! NSRegularExpression(pattern: "^(stop task|stop generation|stop response|(stop|cancel) \\((ctrl\\+|⌃)\\w\\))$", options: [.caseInsensitive])
        func isComposerStop(_ label: String) -> Bool { composerStop.firstMatch(in: label, range: NSRange(label.startIndex..., in: label)) != nil }
        let anchor = box.flatMap { AXHelper.frame($0) }
        func findStop() -> AXUIElement? {
            if let near = agFindAll(window, { _, role, label in role == kAXButtonRole && isComposerStop(label) }).min(by: { l, r in
                guard let a = anchor, let lf = AXHelper.frame(l), let rf = AXHelper.frame(r) else { return false }
                return hypot(lf.midX - a.maxX, lf.midY - a.maxY) < hypot(rf.midX - a.maxX, rf.midY - a.maxY)
            }) { return near }
            guard let row = agLink(window, id: id).flatMap({ AXHelper.frame($0) }) else { return nil }
            return agFindAll(window) { el, role, label in
                guard role == kAXButtonRole, label.lowercased() == "stop execution", let f = AXHelper.frame(el) else { return false }
                return f.midY >= row.minY - 4 && f.midY <= row.maxY + 4
            }.first
        }
        guard let button = findStop() else { return agFail("no_stop_button") }
        if !AXHelper.press(button), let f = AXHelper.frame(button) { postLeftClick(at: CGPoint(x: f.midX, y: f.midY)) }
        for _ in 0..<15 {
            Thread.sleep(forTimeInterval: 0.2)
            if findStop() == nil { return agResponse(AGResult(ok: true, reason: "stopped", mayHaveSent: true)) }
        }
        return agFail("stop_not_confirmed", mayHaveSent: true)
    case "send", "check":
        return agSend(app: app, window: window, id: id, req: req, check: mode == "check", transportId: transportId, writeLine: writeLine)
    default:
        return agFail("unsupported_on_mac")
    }
}

private func agSend(app: NSRunningApplication, window: AXUIElement, id: String, req: AdapterRequest, check: Bool, transportId: UInt64?, writeLine: (String) -> Void) -> AdapterResponse {
    let text = req.text ?? ""
    let images = (req.attachments ?? []).map { $0.path }
    let hasText = !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    if !hasText && images.isEmpty { return agFail("empty_message") }
    if let idle = req.idleSeconds, idle > 0, userIdleSeconds() < Double(idle) { return agFail("user_active") }
    for path in images where !FileManager.default.fileExists(atPath: path) { return agFail("image_missing") }
    guard !id.isEmpty else { return agFail("conversation_not_in_sidebar") }
    guard agOpen(window, id: id) else {
        return agFail(agLink(window, id: id) == nil && agCurrentId(window) != id ? "conversation_not_in_sidebar" : "conversation_not_opened")
    }
    guard let box = agMessageBox(window) else { return agFail("no_message_box") }
    if !agBoxText(box).isEmpty { return agFail("draft_in_box") }

    let previousFront = frontmostApp()
    defer {
        if let prev = previousFront, prev.processIdentifier != app.processIdentifier {
            onMain { if #available(macOS 14.0, *) { _ = prev.activate() } else { _ = prev.activate(options: []) } }
        }
    }
    guard activateAndFocus(app, window: window, editor: box) else { return agFail(images.isEmpty ? "needs_foreground" : "image_needs_foreground") }
    let saved = saveClipboard()
    defer { restoreClipboard(saved) }
    let before = hasText ? agMatchingTextCount(window, text) : 0
    let queuedBefore = agQueued(window).count

    if !images.isEmpty {
        let pb = NSPasteboard.general
        pb.clearContents()
        pb.writeObjects(images.map { URL(fileURLWithPath: $0) as NSURL })
        postKey(CGKeyCode(kVK_ANSI_V), flags: .maskCommand)
        Thread.sleep(forTimeInterval: 0.6)
    }
    if hasText {
        guard agCurrentId(window) == id else { return agFail("conversation_not_opened") }
        let pb = NSPasteboard.general
        pb.clearContents()
        pb.setString(text, forType: .string)
        postKey(CGKeyCode(kVK_ANSI_V), flags: .maskCommand)
        var taken = false
        for _ in 0..<10 {
            Thread.sleep(forTimeInterval: 0.15)
            if agNorm(agBoxText(box)) == agNorm(text) { taken = true; break }
        }
        if !taken { if !agBoxText(box).isEmpty { agClearBox(box) }; return agFail("text_not_taken") }
    }
    var send: AXUIElement?
    for i in 0..<(images.isEmpty ? 10 : 20) {
        send = agSendButton(window, box: box)
        if let s = send, AXHelper.isEnabled(s) { break }
        // The editor can keep Send disabled until it sees a typed key after a
        // paste: type a space and take it back once.
        if i == 6 && hasText {
            postKey(CGKeyCode(kVK_End), flags: .maskCommand)
            postKey(CGKeyCode(kVK_Space)); Thread.sleep(forTimeInterval: 0.05); postKey(CGKeyCode(kVK_Delete))
        }
        Thread.sleep(forTimeInterval: 0.15)
    }
    if check {
        let enabled = send.map { AXHelper.isEnabled($0) } ?? false
        agClearBox(box)
        var r = AGResult(ok: true, reason: "checked", mayHaveSent: false)
        r.sendEnabled = enabled
        return agResponse(r)
    }
    guard let sendButton = send, AXHelper.isEnabled(sendButton) else {
        agClearBox(box)
        return agFail(hasText ? "send_unavailable" : "image_paste_failed")
    }
    guard agCurrentId(window) == id else { agClearBox(box); return agFail("conversation_not_opened") }
    emitWritePhase(transportId, writeLine: writeLine)
    _ = AXHelper.press(sendButton)
    for _ in 0..<15 {
        Thread.sleep(forTimeInterval: 0.2)
        let current = agMessageBox(window)
        let cleared = current.map { agBoxText($0).isEmpty } ?? false
        let shown = !hasText || agMatchingTextCount(window, text) > before
        let queue = agQueued(window).map { $0.1 }
        // While a turn runs, Antigravity holds the message in its queue.
        let queued = queue.count > queuedBefore || (hasText && queue.contains { agSameQueued($0, text) })
        if cleared && (shown || queued) {
            var steered = false, items = queue
            if queued && req.steerNow == true {
                let r = agQueuedAction(window, text: text, verb: "Send now", done: "steered", missing: "steer_button_not_found")
                if r.ok { steered = true; items = agQueued(window).map { $0.1 } }
            }
            var result = AGResult(ok: true, reason: "confirmed", mayHaveSent: true, receiptSource: "window", confirmedAt: Date().timeIntervalSince1970 * 1000, queuedInWindow: queued && !steered, steered: steered)
            result.queuedItems = items
            return agResponse(result)
        }
    }
    return agResponse(AGResult(ok: true, reason: "clicked", mayHaveSent: true))
}
