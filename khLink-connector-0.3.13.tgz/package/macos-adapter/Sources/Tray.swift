// khLink menu bar app: first-run setup (install, browser login, Accessibility),
// connection status, updates, logs, quit and uninstall.
//
// The same binary is also the desktop-control helper (`--socket`, run by the
// LaunchAgent com.khlink.helper), so one Accessibility grant for khLink.app
// covers both. Everything the background service does goes through the
// connector's own scripts/khlink-macos.sh, which the command line uses too.
import AppKit
import ApplicationServices
import Foundation

private let fm = FileManager.default
private let homeURL = fm.homeDirectoryForCurrentUser

enum KHPaths {
    static let base = homeURL.appendingPathComponent("Library/Application Support/khLink")
    static let connectorBase = base.appendingPathComponent("connector")
    static let connectorApp = connectorBase.appendingPathComponent("app")
    static let script = connectorBase.appendingPathComponent("khlink-macos.sh")
    static let runtime = base.appendingPathComponent("runtime/node")
    static let data = homeURL.appendingPathComponent("Library/Application Support/FengzhuAgentBridge")
    static let status = data.appendingPathComponent("status.json")
    static let config = data.appendingPathComponent("config.json")
    static let connectorLogs = data.appendingPathComponent("logs")
    static let serviceLogs = connectorBase.appendingPathComponent("logs")
    static let updatePlist = homeURL.appendingPathComponent("Library/LaunchAgents/com.khlink.update.plist")
    static let helperPlist = homeURL.appendingPathComponent("Library/LaunchAgents/com.khlink.helper.plist")
    static let trayLock = base.appendingPathComponent("tray.lock")
    static let actionLog = serviceLogs.appendingPathComponent("khlink-app.log")
}

// MARK: - Helpers

func khReadJSON(_ url: URL) -> [String: Any]? {
    guard let data = try? Data(contentsOf: url) else { return nil }
    return (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
}

func khVersionNewer(_ a: String, than b: String) -> Bool {
    let x = a.split(separator: ".").map { Int($0) ?? 0 }
    let y = b.split(separator: ".").map { Int($0) ?? 0 }
    for i in 0..<max(x.count, y.count) {
        let p = i < x.count ? x[i] : 0, q = i < y.count ? y[i] : 0
        if p != q { return p > q }
    }
    return false
}

func khIsAppleSilicon() -> Bool {
    var value: Int32 = 0
    var size = MemoryLayout<Int32>.size
    return sysctlbyname("hw.optional.arm64", &value, &size, nil, 0) == 0 && value == 1
}

var khAppVersion: String { Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "?" }
var khPayload: URL? {
    guard let res = Bundle.main.resourceURL?.appendingPathComponent("payload") else { return nil }
    return fm.fileExists(atPath: res.appendingPathComponent("connector/package.json").path) ? res : nil
}

func khConnectorVersion(_ dir: URL) -> String? { khReadJSON(dir.appendingPathComponent("package.json"))?["version"] as? String }

/// Runs a command with the bundled Node first on PATH; output lines go to `onLine` on the main queue.
@discardableResult
func khRun(_ args: [String], onLine: ((String) -> Void)? = nil, completion: ((Int32) -> Void)? = nil) -> Process? {
    let process = Process()
    process.executableURL = URL(fileURLWithPath: args[0])
    process.arguments = Array(args.dropFirst())
    var env = ProcessInfo.processInfo.environment
    env["PATH"] = "\(KHPaths.runtime.path)/bin:/usr/bin:/bin:/usr/sbin:/sbin"
    env["KHLINK_APP"] = Bundle.main.bundlePath
    process.environment = env
    let pipe = Pipe()
    process.standardOutput = pipe
    process.standardError = pipe
    var buffer = Data()
    try? fm.createDirectory(at: KHPaths.serviceLogs, withIntermediateDirectories: true)
    let log = try? FileHandle(forWritingTo: { () -> URL in
        if !fm.fileExists(atPath: KHPaths.actionLog.path) { fm.createFile(atPath: KHPaths.actionLog.path, contents: nil) }
        return KHPaths.actionLog
    }())
    log?.seekToEndOfFile()
    log?.write("\n[\(Date())] \(args.map { ($0 as NSString).lastPathComponent }.joined(separator: " "))\n".data(using: .utf8)!)
    pipe.fileHandleForReading.readabilityHandler = { handle in
        let chunk = handle.availableData
        if chunk.isEmpty { return }
        log?.write(chunk)
        buffer.append(chunk)
        while let nl = buffer.firstIndex(of: 0x0a) {
            let line = String(decoding: buffer[buffer.startIndex..<nl], as: UTF8.self)
            buffer.removeSubrange(buffer.startIndex...nl)
            if let onLine = onLine { DispatchQueue.main.async { onLine(line) } }
        }
    }
    process.terminationHandler = { p in
        pipe.fileHandleForReading.readabilityHandler = nil
        let rest = pipe.fileHandleForReading.readDataToEndOfFile()
        log?.write(rest)
        try? log?.close()
        let tail = String(decoding: buffer + rest, as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)
        DispatchQueue.main.async {
            if !tail.isEmpty, let onLine = onLine { tail.split(separator: "\n").forEach { onLine(String($0)) } }
            completion?(p.terminationStatus)
        }
    }
    do { try process.run() } catch {
        DispatchQueue.main.async { onLine?("无法运行：\(error.localizedDescription)"); completion?(-1) }
        return nil
    }
    return process
}

func khScript(_ args: [String], onLine: ((String) -> Void)? = nil, completion: ((Int32) -> Void)? = nil) {
    khRun(["/bin/bash", KHPaths.script.path] + args, onLine: onLine, completion: completion)
}

/// The update replaces this app and restarts it, so it must outlive this process.
func khDetachedUpdate() {
    let log = KHPaths.serviceLogs.appendingPathComponent("com.khlink.update.log").path
    // Paths go in as arguments, never into the command text.
    khRun(["/bin/bash", "-c", "nohup /bin/bash \"$1\" update >> \"$2\" 2>&1 &", "bash", KHPaths.script.path, log])
}

// MARK: - State

struct KHState {
    var installed = false
    var loggedIn = false
    var connectorVersion: String?
    var online = false
    var relayConnected = false
    var deviceName: String?
    var axTrusted = false
    var autoUpdate = false
    var helperUsesThisApp = false

    static func read() -> KHState {
        var s = KHState()
        s.installed = fm.fileExists(atPath: KHPaths.connectorApp.appendingPathComponent("src/cli.js").path) && fm.fileExists(atPath: KHPaths.script.path)
        s.loggedIn = fm.fileExists(atPath: KHPaths.config.path)
        s.connectorVersion = khConnectorVersion(KHPaths.connectorApp)
        if let st = khReadJSON(KHPaths.status) {
            let updated = (st["updatedAt"] as? NSNumber)?.doubleValue ?? 0
            s.online = Date().timeIntervalSince1970 * 1000 - updated < 30_000 && (st["lifecycle"] as? String ?? "running") != "stopped"
            s.relayConnected = s.online && ((st["connected"] as? Bool) ?? false)
            s.deviceName = (st["deviceName"] as? String)?.replacingOccurrences(of: " 后台连接器", with: "")
        }
        s.axTrusted = AXIsProcessTrusted()
        s.autoUpdate = fm.fileExists(atPath: KHPaths.updatePlist.path)
        if let plist = try? String(contentsOf: KHPaths.helperPlist, encoding: .utf8) {
            s.helperUsesThisApp = plist.contains(Bundle.main.bundlePath + "/Contents/MacOS/")
        }
        return s
    }
}

// MARK: - Setup window

final class SetupWindowController: NSWindowController, NSWindowDelegate {
    weak var tray: TrayController?
    private let stepIcons = (0..<3).map { _ in NSTextField(labelWithString: "○") }
    private let stepTexts = (0..<3).map { _ in NSTextField(wrappingLabelWithString: "") }
    private let installButton = NSButton(title: "安装", target: nil, action: nil)
    private let loginButton = NSButton(title: "在浏览器中登录", target: nil, action: nil)
    private let axButton = NSButton(title: "去授权", target: nil, action: nil)
    private let doneButton = NSButton(title: "完成", target: nil, action: nil)
    private let footer = NSTextField(wrappingLabelWithString: "")
    private let logView = NSTextView()
    private var busy = false
    private var axPolling: Timer?

    init(tray: TrayController) {
        self.tray = tray
        let window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 560, height: 520), styleMask: [.titled, .closable], backing: .buffered, defer: false)
        window.title = "khLink 设置"
        window.isReleasedWhenClosed = false
        super.init(window: window)
        window.delegate = self
        build()
    }
    required init?(coder: NSCoder) { fatalError() }

    private func build() {
        guard let content = window?.contentView else { return }
        let title = NSTextField(labelWithString: "把这台 Mac 连到手机上的 khLink")
        title.font = .boldSystemFont(ofSize: 17)
        let subtitle = NSTextField(wrappingLabelWithString: "完成下面几步后，打开手机 khLink，在电脑列表里选这台 Mac，就能用手机遥控这里的 Codex、Claude Code 等智能体。")
        subtitle.textColor = .secondaryLabelColor

        installButton.target = self; installButton.action = #selector(install)
        loginButton.target = self; loginButton.action = #selector(login)
        axButton.target = self; axButton.action = #selector(grantAccessibility)
        doneButton.target = self; doneButton.action = #selector(finish)
        doneButton.keyEquivalent = "\r"

        let buttons = [installButton, loginButton, axButton]
        var rows: [NSView] = [title, subtitle]
        for i in 0..<3 {
            stepIcons[i].font = .systemFont(ofSize: 18)
            stepIcons[i].setContentHuggingPriority(.required, for: .horizontal)
            stepTexts[i].preferredMaxLayoutWidth = 360
            buttons[i].bezelStyle = .rounded
            buttons[i].setContentHuggingPriority(.required, for: .horizontal)
            let row = NSStackView(views: [stepIcons[i], stepTexts[i], buttons[i]])
            row.alignment = .centerY
            row.spacing = 10
            rows.append(row)
        }
        logView.isEditable = false
        logView.font = .monospacedSystemFont(ofSize: 11, weight: .regular)
        logView.textContainerInset = NSSize(width: 4, height: 4)
        let scroll = NSScrollView()
        scroll.documentView = logView
        scroll.hasVerticalScroller = true
        scroll.borderType = .bezelBorder
        logView.autoresizingMask = [.width]
        logView.minSize = NSSize(width: 0, height: 0)
        logView.maxSize = NSSize(width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude)
        logView.isVerticallyResizable = true
        scroll.translatesAutoresizingMaskIntoConstraints = false
        scroll.heightAnchor.constraint(equalToConstant: 150).isActive = true
        footer.textColor = .secondaryLabelColor
        footer.font = .systemFont(ofSize: 11)
        let bottom = NSStackView(views: [footer, doneButton])
        bottom.alignment = .centerY
        rows += [scroll, bottom]

        let stack = NSStackView(views: rows)
        stack.orientation = .vertical
        stack.alignment = .leading
        stack.spacing = 14
        stack.edgeInsets = NSEdgeInsets(top: 20, left: 24, bottom: 20, right: 24)
        stack.translatesAutoresizingMaskIntoConstraints = false
        content.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: content.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: content.trailingAnchor),
            stack.topAnchor.constraint(equalTo: content.topAnchor),
            stack.bottomAnchor.constraint(lessThanOrEqualTo: content.bottomAnchor),
            scroll.widthAnchor.constraint(equalTo: stack.widthAnchor, constant: -48),
            bottom.widthAnchor.constraint(equalTo: stack.widthAnchor, constant: -48),
        ])
        refresh()
    }

    func append(_ line: String) {
        let text = line.replacingOccurrences(of: "\u{1b}\\[[0-9;]*m", with: "", options: .regularExpression)
        logView.textStorage?.append(NSAttributedString(string: text + "\n", attributes: [.font: logView.font!, .foregroundColor: NSColor.textColor]))
        logView.scrollToEndOfDocument(nil)
    }

    func refresh() {
        let s = KHState.read()
        let needsInstall = !s.installed || (khPayload.flatMap { khConnectorVersion($0.appendingPathComponent("connector")) }.map { khVersionNewer($0, than: s.connectorVersion ?? "0") } ?? false)
        let canInstall = khPayload != nil || s.installed
        set(0, done: !needsInstall, text: needsInstall
            ? (canInstall ? "安装后台服务（连接器、Node 运行环境），只装在你的用户目录里。" : "这个 khLink 不带安装文件，请重新下载安装包。")
            : "后台服务已安装（连接器 \(s.connectorVersion ?? "?")）。")
        installButton.isEnabled = !busy && needsInstall && khPayload != nil
        installButton.isHidden = !needsInstall
        set(1, done: s.loggedIn && s.online, text: s.loggedIn
            ? (s.online ? "已登录并在线：\(s.deviceName ?? "这台 Mac")。" : "已登录，正在启动后台服务…")
            : "登录 khLink 账号：会打开浏览器，在网页里登录并点「授权」。账号里已有别的电脑时，那台电脑要开着 khLink。")
        loginButton.title = s.loggedIn ? "重新登录" : "在浏览器中登录"
        loginButton.isEnabled = !busy && !needsInstall
        set(2, done: s.axTrusted, text: s.axTrusted
            ? "已授权桌面控制，手机可以遥控 Codex 桌面 App。"
            : "授权桌面控制（可选）：在「系统设置 → 隐私与安全性 → 辅助功能」里打开 khLink。只用命令行智能体可以跳过。")
        axButton.isHidden = s.axTrusted
        axButton.isEnabled = !busy
        if s.loggedIn && s.online {
            footer.stringValue = "完成了。以后 khLink 会随 Mac 登录自动运行，菜单栏的 khLink 图标可以查看状态和更新。"
        } else {
            footer.stringValue = busy ? "正在处理，请稍候…" : ""
        }
        doneButton.title = s.loggedIn && s.online ? "完成" : "稍后再说"
    }

    private func set(_ i: Int, done: Bool, text: String) {
        stepIcons[i].stringValue = done ? "✅" : "\(i + 1)️⃣"
        stepTexts[i].stringValue = text
    }

    private func setBusy(_ value: Bool) { busy = value; refresh(); tray?.refresh() }

    @objc func install() {
        guard let payload = khPayload else { return }
        setBusy(true)
        append("开始安装…")
        TrayController.installFromPayload(payload, onLine: { [weak self] in self?.append($0) }) { [weak self] ok in
            guard let self = self else { return }
            self.append(ok ? "安装完成。" : "安装没有完成，请查看上面的输出。")
            self.setBusy(false)
            if ok && KHState.read().loggedIn { self.startService() }
        }
    }

    @objc func login() {
        setBusy(true)
        append("正在打开浏览器登录…（5 分钟内完成授权）")
        khScript(["login"], onLine: { [weak self] in self?.append($0) }) { [weak self] code in
            guard let self = self else { return }
            if code == 0 { self.append("登录完成，正在启动后台服务…"); self.startService() }
            else { self.append("登录没有完成，可以再点一次登录。"); self.setBusy(false) }
        }
    }

    func startService() {
        setBusy(true)
        khScript(["start"], onLine: { [weak self] in self?.append($0) }) { [weak self] _ in
            guard let self = self else { return }
            // Give the connector a few seconds to connect before showing the result.
            DispatchQueue.main.asyncAfter(deadline: .now() + 4) { self.setBusy(false) }
        }
    }

    @objc func grantAccessibility() {
        TrayController.promptAccessibility()
        append("已打开「系统设置 → 隐私与安全性 → 辅助功能」：打开 khLink 旁边的开关（可能要输入 Mac 密码）。")
        axPolling?.invalidate()
        axPolling = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] timer in
            guard AXIsProcessTrusted() else { return }
            timer.invalidate()
            self?.append("已授权桌面控制。")
            TrayController.restartHelper()
            self?.refresh(); self?.tray?.refresh()
        }
    }

    @objc func finish() {
        window?.close()
        if KHState.read().loggedIn { tray?.showMain() }
    }

    func windowWillClose(_ notification: Notification) {
        axPolling?.invalidate()
        // Back to a menu bar only app once the window is gone.
        DispatchQueue.main.async { if !NSApp.windows.contains(where: { $0.isVisible && $0 != self.window }) { NSApp.setActivationPolicy(.accessory) } }
    }
}

// MARK: - Menu bar

final class TrayController: NSObject, NSMenuDelegate {
    private let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    private var setup: SetupWindowController?
    private var main: MainWindowController?
    private var timer: Timer?
    private var state = KHState()
    private var updating = false

    func start() {
        item.button?.image = NSImage(systemSymbolName: "link.circle", accessibilityDescription: "khLink")
        item.button?.image?.isTemplate = true
        let menu = NSMenu()
        menu.delegate = self
        item.menu = menu
        refresh()
        timer = Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { [weak self] _ in self?.refresh() }
        DistributedNotificationCenter.default().addObserver(self, selector: #selector(showMain), name: Notification.Name("vip.fengzhu.khlink.show"), object: nil)
        firstRun()
        // Opened by the user (Finder, Launchpad, Spotlight): show the window, since the menu bar icon
        // may be hidden. Quiet when started at login or reopened after an update (--background).
        let quiet = CommandLine.arguments.contains("--background") || ProcessInfo.processInfo.environment["XPC_SERVICE_NAME"] == "com.khlink.tray"
        if !quiet && setup?.window?.isVisible != true { showMain() }
    }

    /// Installed by an older command-line setup or by an earlier khLink: adopt it quietly.
    private func firstRun() {
        let s = KHState.read()
        let payloadVersion = khPayload.flatMap { khConnectorVersion($0.appendingPathComponent("connector")) }
        let payloadNewer = payloadVersion.map { khVersionNewer($0, than: s.connectorVersion ?? "0") } ?? false
        if !s.installed || !s.loggedIn || payloadNewer {
            showSetup()
            // Step 1 needs no decision from the user: start it right away.
            if khPayload != nil && (!s.installed || payloadNewer) { setup?.install() }
            return
        }
        if !s.helperUsesThisApp {
            khScript(["start"], completion: { [weak self] _ in self?.refresh() })
        }
    }

    func refresh() {
        state = KHState.read()
        let symbol: String
        if !state.installed || !state.loggedIn { symbol = "link.badge.plus" }
        else if state.relayConnected { symbol = "link.circle.fill" }
        else { symbol = "link.circle" }
        item.button?.image = NSImage(systemSymbolName: symbol, accessibilityDescription: "khLink")
        item.button?.image?.isTemplate = true
        item.button?.toolTip = state.relayConnected ? "khLink 已连接" : "khLink 未连接"
        setup?.refresh()
    }

    func menuNeedsUpdate(_ menu: NSMenu) {
        refresh()
        menu.removeAllItems()
        let s = state
        func info(_ title: String) { let i = NSMenuItem(title: title, action: nil, keyEquivalent: ""); i.isEnabled = false; menu.addItem(i) }
        func action(_ title: String, _ sel: Selector, key: String = "") -> NSMenuItem {
            let i = NSMenuItem(title: title, action: sel, keyEquivalent: key); i.target = self; menu.addItem(i); return i
        }
        if !s.installed || !s.loggedIn {
            info("khLink 还没有设置好")
            _ = action("打开设置向导…", #selector(showSetup))
        } else {
            info(s.relayConnected ? "● 已连接 · \(s.deviceName ?? "这台 Mac")" : (s.online ? "○ 正在连接中转…" : "○ 后台服务没有运行"))
            info("连接器 \(s.connectorVersion ?? "?") · 菜单程序 \(khAppVersion)")
            _ = action("打开 khLink 主界面…", #selector(showMain))
            if s.axTrusted { info("桌面控制：已授权") } else { _ = action("桌面控制：未授权，点此授权…", #selector(grantAccessibility)) }
            if !s.online { _ = action("启动后台服务", #selector(restartService)) }
        }
        menu.addItem(.separator())
        let update = action(updating ? "正在检查更新…" : "立即检查更新", #selector(checkUpdate))
        update.isEnabled = !updating && s.installed
        let auto = action("自动更新", #selector(toggleAutoUpdate))
        auto.state = s.autoUpdate ? .on : .off
        auto.isEnabled = s.installed && s.loggedIn
        _ = action("打开日志文件夹", #selector(openLogs))
        if s.installed && s.loggedIn {
            _ = action("设置向导…", #selector(showSetup))
            _ = action("重新启动后台服务", #selector(restartService))
        }
        _ = action("使用说明", #selector(openHelp))
        menu.addItem(.separator())
        _ = action("退出菜单栏图标（后台服务继续运行）", #selector(quit), key: "q")
        _ = action("卸载 khLink…", #selector(uninstall))
    }

    @objc func showSetup() {
        if setup == nil { setup = SetupWindowController(tray: self) }
        // While the window is open khLink shows in the Dock and the app switcher, so it can be found
        // even when macOS hides the menu bar icon (crowded menu bar, or not allowed in Menu Bar settings).
        NSApp.setActivationPolicy(.regular)
        khActivate()
        setup?.showWindow(nil)
        setup?.window?.center()
        setup?.window?.makeKeyAndOrderFront(nil)
        setup?.refresh()
    }

    /// The main window once khLink is set up; the setup steps until then.
    @objc func showMain() {
        let s = KHState.read()
        guard s.installed && s.loggedIn else { showSetup(); return }
        if main == nil { main = MainWindowController(tray: self) }
        NSApp.setActivationPolicy(.regular)
        khActivate()
        if main?.window?.isVisible != true { main?.window?.center() }
        main?.showWindow(nil)
        main?.window?.makeKeyAndOrderFront(nil)
        main?.refresh()
    }

    func setupLogin() { setup?.login() }

    @objc func grantAccessibility() {
        showSetup()
        setup?.grantAccessibility()
    }

    @objc func restartService() {
        khScript(["start"], completion: { [weak self] _ in DispatchQueue.main.asyncAfter(deadline: .now() + 3) { self?.refresh() } })
    }

    @objc func checkUpdate() {
        updating = true
        let logURL = KHPaths.serviceLogs.appendingPathComponent("com.khlink.update.log")
        let before = (try? String(contentsOf: logURL, encoding: .utf8))?.count ?? 0
        khDetachedUpdate()
        // The update script may replace and restart this app; until then, follow its log.
        var waited = 0
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] timer in
            waited += 1
            let text = (try? String(contentsOf: logURL, encoding: .utf8)) ?? ""
            let added = text.count > before ? String(text.suffix(text.count - before)) : ""
            let lines = added.split(separator: "\n").map(String.init)
            let finished = lines.contains { $0.hasSuffix("检查结束") }
            if finished || waited > 300 {
                timer.invalidate()
                self?.updating = false
                self?.refresh()
                let summary = lines.map { $0.replacingOccurrences(of: #"^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d "#, with: "", options: .regularExpression) }.joined(separator: "\n")
                TrayController.alert("检查更新", summary.isEmpty ? "更新检查还在进行，结果会写进日志。" : summary)
            }
        }
    }

    @objc func toggleAutoUpdate() {
        khScript(["autoupdate", state.autoUpdate ? "off" : "on"], completion: { [weak self] _ in self?.refresh() })
    }

    @objc func openLogs() {
        try? fm.createDirectory(at: KHPaths.connectorLogs, withIntermediateDirectories: true)
        NSWorkspace.shared.open(KHPaths.connectorLogs)
        if fm.fileExists(atPath: KHPaths.serviceLogs.path) { NSWorkspace.shared.open(KHPaths.serviceLogs) }
    }

    @objc func openHelp() {
        if let url = URL(string: "https://khsci.com/khlink/") { NSWorkspace.shared.open(url) }
    }

    @objc func quit() { NSApp.terminate(nil) }

    @objc func uninstall() {
        khActivate()
        let alert = NSAlert()
        alert.messageText = "卸载 khLink？"
        alert.informativeText = "会停止后台服务，删除连接器、菜单程序和开机启动项。手机上将看不到这台 Mac。"
        let purge = NSButton(checkboxWithTitle: "同时删除这台 Mac 的 khLink 账号数据（以后要重新登录）", target: nil, action: nil)
        alert.accessoryView = purge
        alert.addButton(withTitle: "卸载")
        alert.addButton(withTitle: "取消")
        alert.alertStyle = .warning
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        let args = purge.state == .on ? ["uninstall", "--purge"] : ["uninstall"]
        khScript(args, completion: { _ in
            NSWorkspace.shared.recycle([Bundle.main.bundleURL]) { _, _ in
                DispatchQueue.main.async { NSApp.terminate(nil) }
            }
        })
    }

    // MARK: shared actions

    static func alert(_ title: String, _ text: String) {
        khActivate()
        let a = NSAlert()
        a.messageText = title
        a.informativeText = text
        a.runModal()
    }

    static func promptAccessibility() {
        let opts = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
        _ = AXIsProcessTrustedWithOptions(opts)
        if let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility") {
            NSWorkspace.shared.open(url)
        }
    }

    static func restartHelper() {
        khRun(["/bin/launchctl", "kickstart", "-k", "gui/\(getuid())/com.khlink.helper"])
    }

    /// Node runtime for this Mac's processor, then the connector package (with its node_modules).
    static func installFromPayload(_ payload: URL, onLine: @escaping (String) -> Void, completion: @escaping (Bool) -> Void) {
        let arch = khIsAppleSilicon() ? "arm64" : "x64"
        let node = payload.appendingPathComponent("runtime/node-\(arch)")
        let runtime = KHPaths.runtime.path
        let connector = payload.appendingPathComponent("connector").path
        let script = "\(connector)/scripts/khlink-macos.sh"
        // Paths go in as arguments ($1…$6), never into the command text.
        let cmd = """
        set -e
        mkdir -p "$1/runtime"
        if [ -d "$2" ]; then
          rm -rf "$3.new"; /usr/bin/ditto "$2" "$3.new"
          /usr/bin/xattr -dr com.apple.quarantine "$3.new" 2>/dev/null || true
          rm -rf "$3"; mv "$3.new" "$3"
          echo "Node 运行环境：$("$3/bin/node" -v)（$6）"
        fi
        /bin/bash "$4" install "$5"
        """
        khRun(["/bin/bash", "-c", cmd, "bash", KHPaths.base.path, node.path, runtime, script, connector, arch], onLine: onLine) { code in completion(code == 0) }
    }
}

// MARK: - App entry

final class TrayAppDelegate: NSObject, NSApplicationDelegate {
    let tray = TrayController()
    func applicationDidFinishLaunching(_ notification: Notification) { tray.start() }
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool { tray.showMain(); return false }
}

private var khTrayLockFd: Int32 = -1

/// Outside Applications (still on the disk image, or translocated by Gatekeeper) the
/// login item and the desktop-control helper would point at a path that goes away.
private func ensureInApplications() -> Bool {
    let path = Bundle.main.bundlePath
    let fine = (path.hasPrefix("/Applications/") || path.hasPrefix(homeURL.appendingPathComponent("Applications").path + "/")) && !path.contains("/AppTranslocation/")
    if fine { return true }
    khActivate()
    let alert = NSAlert()
    alert.messageText = "把 khLink 放进「应用程序」文件夹"
    alert.informativeText = "khLink 要在「应用程序」文件夹里运行，才能随 Mac 登录自动启动。点「移过去并打开」由 khLink 自己复制过去。"
    alert.addButton(withTitle: "移过去并打开")
    alert.addButton(withTitle: "退出")
    guard alert.runModal() == .alertFirstButtonReturn else { return false }
    let target = "/Applications/khLink.app"
    let tmp = "/Applications/.khLink-installing.app"
    // Paths go in as arguments, never into the command text.
    let cmd = "set -e; rm -rf \"$2\"; /usr/bin/ditto \"$1\" \"$2\"; /usr/bin/xattr -dr com.apple.quarantine \"$2\" 2>/dev/null || true; if [ -d \"$3\" ]; then mv \"$3\" \"$HOME/.Trash/khLink-$4.app\"; fi; mv \"$2\" \"$3\""
    let p = Process()
    p.executableURL = URL(fileURLWithPath: "/bin/bash")
    p.arguments = ["-c", cmd, "bash", path, tmp, target, String(Int(Date().timeIntervalSince1970))]
    try? p.run(); p.waitUntilExit()
    if p.terminationStatus != 0 {
        TrayController.alert("没能复制", "请手动把 khLink 拖进「应用程序」文件夹后再打开。")
        return false
    }
    let open = Process()
    open.executableURL = URL(fileURLWithPath: "/usr/bin/open")
    open.arguments = ["-n", target]
    try? open.run()
    return false
}

func runTrayApp() {
    let app = NSApplication.shared
    app.setActivationPolicy(.accessory)
    try? fm.createDirectory(at: KHPaths.base, withIntermediateDirectories: true)
    // One menu bar icon: a second launch (Finder, login item) asks the first to show its window.
    khTrayLockFd = open(KHPaths.trayLock.path, O_CREAT | O_RDWR, 0o600)
    if khTrayLockFd >= 0 && flock(khTrayLockFd, LOCK_EX | LOCK_NB) != 0 {
        // The user just opened this copy, so it may hand the foreground to the running one.
        if #available(macOS 14.0, *) { app.yieldActivation(toApplicationWithBundleIdentifier: "vip.fengzhu.khlink") }
        DistributedNotificationCenter.default().postNotificationName(Notification.Name(CommandLine.arguments.contains("--snapshot") ? "vip.fengzhu.khlink.snapshot" : "vip.fengzhu.khlink.show"), object: nil, userInfo: nil, deliverImmediately: true)
        exit(0)
    }
    if !ensureInApplications() { exit(0) }
    // Approved once by the user; drop the download mark so the helper and Node start without prompts.
    let x = Process()
    x.executableURL = URL(fileURLWithPath: "/usr/bin/xattr")
    x.arguments = ["-dr", "com.apple.quarantine", Bundle.main.bundlePath]
    try? x.run()
    let delegate = TrayAppDelegate()
    app.delegate = delegate
    withExtendedLifetime(delegate) { app.run() }
}

/// Bring khLink to the front; activate(ignoringOtherApps:) does nothing from macOS 14 on.
func khActivate() {
    if #available(macOS 14.0, *) { NSApp.activate() } else { NSApp.activate(ignoringOtherApps: true) }
}
