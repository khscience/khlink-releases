#!/bin/bash
# Build the macOS release files (run on a Mac with the Xcode command line tools):
#
#   package-mac.sh <connector.tgz> <node-arm64-dir> <node-x64-dir> <out-dir>
#
#   khLink-mac-<v>.dmg       first install: khLink.app carrying the connector
#                            (with node_modules) and Node for both processors
#   khLink-mac-<v>-app.zip   in-app update: khLink.app only
#
# The node dirs are unpacked official Node.js darwin builds (node-v22.x-darwin-*).
# Sign with KHLINK_MACOS_SIGN_IDENTITY (see build-app.sh).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
TGZ="$1"; NODE_ARM="$2"; NODE_X64="$3"; OUT="$4"
VERSION="${KHLINK_APP_VERSION:-$(tr -d "[:space:]" < "$HERE/VERSION")}"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
mkdir -p "$OUT"

# Node: the binary and npm (for connector updates that change dependencies).
slim_node() {
  local from="$1" to="$2"
  mkdir -p "$to/bin" "$to/lib/node_modules"
  cp "$from/bin/node" "$to/bin/node"
  ditto "$from/lib/node_modules/npm" "$to/lib/node_modules/npm"
  ln -s ../lib/node_modules/npm/bin/npm-cli.js "$to/bin/npm"
  ln -s ../lib/node_modules/npm/bin/npx-cli.js "$to/bin/npx"
  cp "$from/LICENSE" "$to/LICENSE" 2>/dev/null || true
}
slim_node "$NODE_ARM" "$WORK/node-arm64"
slim_node "$NODE_X64" "$WORK/node-x64"

# The connector with its (pure JavaScript) dependencies installed.
mkdir -p "$WORK/pkg"
tar xzf "$TGZ" -C "$WORK/pkg"
(cd "$WORK/pkg/package" && PATH="$WORK/node-arm64/bin:$PATH" npm install --omit=dev --no-audit --no-fund --ignore-scripts >/dev/null)
CONNECTOR_VERSION="$("$WORK/node-arm64/bin/node" -p "require('$WORK/pkg/package/package.json').version")"

# In-app update package.
bash "$HERE/build-app.sh" "$WORK/lean"
rm -f "$OUT/khLink-mac-$VERSION-app.zip"
ditto -c -k --keepParent "$WORK/lean/khLink.app" "$OUT/khLink-mac-$VERSION-app.zip"

# First-install disk image: the app and a link to Applications to drag it onto.
bash "$HERE/build-app.sh" "$WORK/full" --payload "$WORK/pkg/package" "$WORK/node-arm64" "$WORK/node-x64"
mkdir -p "$WORK/dmg"
ditto "$WORK/full/khLink.app" "$WORK/dmg/khLink.app"
ln -s /Applications "$WORK/dmg/Applications"
rm -f "$OUT/khLink-mac-$VERSION.dmg"
# Made uncompressed first, then LZMA (macOS 10.15+): about a third smaller
# than compressing straight from the folder.
hdiutil create -quiet -volname "khLink $VERSION" -srcfolder "$WORK/dmg" -ov -format UDRW "$WORK/raw.dmg"
hdiutil convert -quiet "$WORK/raw.dmg" -format ULMO -o "$OUT/khLink-mac-$VERSION.dmg" -ov

ls -l "$OUT/khLink-mac-$VERSION-app.zip" "$OUT/khLink-mac-$VERSION.dmg"
echo "khLink for macOS $VERSION (connector $CONNECTOR_VERSION, node $("$WORK/node-arm64/bin/node" -v))"
shasum -a 256 "$OUT/khLink-mac-$VERSION-app.zip" "$OUT/khLink-mac-$VERSION.dmg"
