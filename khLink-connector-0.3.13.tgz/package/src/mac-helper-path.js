'use strict';
// Where the macOS desktop-control helper lives: the khLink app's own binary
// (the menu bar app from the .dmg is also the helper, so one Accessibility
// grant covers both), or the helper earlier command-line installs built from
// macos-adapter/. khlink-macos.sh passes the one it set up in KHLINK_HELPER_BIN.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

function legacyMacHelperBin(home = os.homedir()) {
  return path.join(home, 'Library', 'Application Support', 'khLink', 'khLinkHelper.app', 'Contents', 'MacOS', 'khLinkHelper');
}

function macHelperBin({ env = process.env, home = os.homedir(), exists = fs.existsSync } = {}) {
  const candidates = [
    env.KHLINK_HELPER_BIN,
    '/Applications/khLink.app/Contents/MacOS/khLink',
    path.join(home, 'Applications', 'khLink.app', 'Contents', 'MacOS', 'khLink'),
  ].filter((file) => typeof file === 'string' && file.trim());
  return candidates.find((file) => exists(file)) || legacyMacHelperBin(home);
}

module.exports = { macHelperBin, legacyMacHelperBin };
