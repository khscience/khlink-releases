'use strict';

// Small copies of big videos for watching on the phone.
//
// On 2026-11-23/24 one account moved 2.4 GB and 4.8 GB through the relay,
// almost all of it 1080p renders (140–470 MB each) the phone fetched whole to
// play. A phone that asks `file.videoPreview` gets a 720p H.264 copy instead
// (about 1.5 Mbit/s, roughly a tenth of the size), made here with ffmpeg and
// then fetched with the ordinary file.read. The original stays one tap away.
//
// The first request starts the conversion and answers `pending` with a
// progress fraction; the phone asks again until `ready`. Copies are keyed by
// the source's path, size and modification time, so an edited render gets a
// new copy, and old copies are pruned by age and total size.

const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn: nodeSpawn } = require('node:child_process');

const VIDEO_EXTENSIONS = new Set(['.mp4', '.mov', '.m4v', '.mkv', '.webm', '.avi', '.wmv', '.flv', '.ts']);
const MIN_SOURCE_BYTES = 20 * 1024 * 1024;
const MAX_AGE_MS = 14 * 24 * 60 * 60_000;
const MAX_TOTAL_BYTES = 3 * 1024 * 1024 * 1024;
// Fit inside 1280x1280 keeping the aspect ratio (a portrait clip stays portrait), even sizes for H.264.
const SCALE = "scale='if(gt(iw,ih),min(1280,iw),-2)':'if(gt(iw,ih),-2,min(1280,ih))'";

function encoderArgs(encoder) {
  if (encoder === 'h264_nvenc') return ['-c:v', 'h264_nvenc', '-preset', 'p4', '-rc', 'vbr', '-cq', '28', '-b:v', '1500k', '-maxrate', '2000k', '-bufsize', '4000k'];
  return ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '28', '-maxrate', '2000k', '-bufsize', '4000k'];
}

function ffmpegArgs(source, target, encoder) {
  return ['-hide_banner', '-nostdin', '-y', '-i', source, '-map', '0:v:0', '-map', '0:a:0?', '-vf', SCALE,
    ...encoderArgs(encoder), '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '96k', '-ac', '2',
    '-movflags', '+faststart', '-f', 'mp4', target];
}

/** Seconds in an ffmpeg `HH:MM:SS.xx` time, or null. */
function seconds(text) {
  const match = /(\d+):(\d{2}):(\d{2}(?:\.\d+)?)/.exec(String(text || ''));
  return match ? Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3]) : null;
}

class VideoPreviews {
  constructor(options = {}) {
    this.dir = options.dir || path.join(os.tmpdir(), 'FengzhuAgentBridge', 'previews');
    this.ffmpeg = options.ffmpeg || process.env.KHLINK_FFMPEG || 'ffmpeg';
    this.spawn = options.spawn || nodeSpawn;
    this.log = options.log || ((line) => console.log(line));
    this.now = options.now || Date.now;
    this.minSourceBytes = options.minSourceBytes ?? MIN_SOURCE_BYTES;
    this.encoders = options.encoders || ['h264_nvenc', 'libx264'];
    this.jobs = new Map(); // key -> { progress, error }
    this.queue = [];
    this.running = null;
  }

  /**
   * What the phone should play for `source` (an already validated, real
   * local path): `ready` with the copy's path, `pending` while it is being
   * made, or `original` when the phone should fetch the file itself.
   */
  request(source) {
    const ext = path.extname(source).toLowerCase();
    if (!VIDEO_EXTENSIONS.has(ext)) return { status: 'original', reason: 'not-video' };
    const stat = fs.statSync(source);
    if (!stat.isFile()) throw new Error('Not a file');
    if (stat.size < this.minSourceBytes) return { status: 'original', reason: 'small', sourceTotal: stat.size };
    const key = crypto.createHash('sha256').update(`preview-v1\0${source}\0${stat.size}\0${Math.round(stat.mtimeMs)}`).digest('hex').slice(0, 32);
    // The phone names its copy after this file, so keep the render's own name visible.
    const base = path.basename(source, path.extname(source)).slice(0, 120);
    const target = path.join(this.dir, key, `${base}-720p预览.mp4`);
    const skipped = path.join(this.dir, `${key}.original`);
    if (fs.existsSync(target)) {
      const total = fs.statSync(target).size;
      try { fs.utimesSync(target, new Date(), new Date()); } catch { /* age is only for pruning */ }
      return { status: 'ready', path: target, total, sourceTotal: stat.size };
    }
    if (fs.existsSync(skipped)) return { status: 'original', reason: 'no-saving', sourceTotal: stat.size };
    const job = this.jobs.get(key);
    if (job?.error) {
      // One failure is reported once; asking again later tries again.
      this.jobs.delete(key);
      return { status: 'original', reason: 'failed', error: job.error, sourceTotal: stat.size };
    }
    if (!job) {
      this.jobs.set(key, { progress: 0, error: null });
      this.queue.push({ key, source, target, skipped, sourceTotal: stat.size });
      this.pump();
    }
    return { status: 'pending', progress: this.jobs.get(key)?.progress || 0, sourceTotal: stat.size };
  }

  pump() {
    if (this.running || !this.queue.length) return;
    const item = this.queue.shift();
    this.running = item.key;
    const started = this.now();
    this.convert(item, 0).then((result) => {
      const seconds = ((this.now() - started) / 1000).toFixed(1);
      if (result.saved) this.log(`[fengzhu-connect] video preview ${path.basename(item.source)} ${mb(item.sourceTotal)} -> ${mb(result.total)} (${result.encoder}, ${seconds}s)`);
      else this.log(`[fengzhu-connect] video preview ${path.basename(item.source)} skipped: copy ${mb(result.total)} saves too little`);
      this.jobs.delete(item.key);
    }).catch((error) => {
      this.log(`[fengzhu-connect] video preview ${path.basename(item.source)} failed: ${error.message}`);
      const job = this.jobs.get(item.key); if (job) job.error = error.message;
    }).finally(() => {
      this.running = null;
      this.prune();
      this.pump();
    });
  }

  async convert(item, encoderIndex) {
    const encoder = this.encoders[encoderIndex];
    fs.mkdirSync(path.dirname(item.target), { recursive: true });
    const temporary = `${item.target}.${process.pid}.tmp.mp4`;
    try {
      await this.run(ffmpegArgs(item.source, temporary, encoder), item.key);
    } catch (error) {
      try { fs.unlinkSync(temporary); } catch { /* nothing written */ }
      if (encoderIndex + 1 < this.encoders.length) return this.convert(item, encoderIndex + 1);
      throw error;
    }
    const total = fs.statSync(temporary).size;
    // A copy that is not clearly smaller is not worth a second file: play the original.
    if (!total || total > item.sourceTotal * 0.7) {
      fs.unlinkSync(temporary);
      fs.writeFileSync(item.skipped, '');
      return { saved: false, total, encoder };
    }
    fs.renameSync(temporary, item.target);
    return { saved: true, total, encoder };
  }

  run(args, key) {
    return new Promise((resolve, reject) => {
      let child;
      try { child = this.spawn(this.ffmpeg, args, { windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'] }); }
      catch (error) { reject(error); return; }
      let duration = null; let tail = '';
      child.stderr?.setEncoding?.('utf8');
      child.stderr?.on('data', (text) => {
        tail = (tail + text).slice(-4000);
        if (duration == null) { const found = /Duration:\s*([\d:.]+)/.exec(tail); if (found) duration = seconds(found[1]); }
        const times = [...String(text).matchAll(/time=\s*([\d:.]+)/g)];
        const done = times.length ? seconds(times[times.length - 1][1]) : null;
        const job = this.jobs.get(key);
        if (job && duration && done != null) job.progress = Math.max(job.progress, Math.min(0.99, done / duration));
      });
      child.on('error', reject);
      child.on('close', (code) => {
        if (code === 0) resolve();
        else reject(new Error(`ffmpeg exited ${code}: ${tail.trim().split(/\r?\n/).slice(-1)[0] || ''}`.trim()));
      });
    });
  }

  /** Drop copies older than two weeks, then the least recently used until under the size cap. */
  prune() {
    try {
      const entries = [];
      for (const name of fs.readdirSync(this.dir)) {
        const entry = path.join(this.dir, name);
        if (name.endsWith('.original')) { entries.push(entry); continue; }
        if (!/^[0-9a-f]{32}$/.test(name)) continue;
        for (const inner of fs.readdirSync(entry)) if (inner.endsWith('.mp4') && !inner.includes('.tmp.')) entries.push(path.join(entry, inner));
      }
      const files = entries.map((file) => { const stat = fs.statSync(file); return { file, size: stat.size, used: stat.mtimeMs }; })
        .sort((a, b) => a.used - b.used);
      let total = files.reduce((sum, entry) => sum + entry.size, 0);
      for (const entry of files) {
        if (this.now() - entry.used <= MAX_AGE_MS && total <= MAX_TOTAL_BYTES) continue;
        try {
          fs.unlinkSync(entry.file); total -= entry.size;
          if (entry.file.endsWith('.mp4')) fs.rmSync(path.dirname(entry.file), { recursive: true, force: true });
        } catch { /* in use; next time */ }
      }
    } catch { /* no directory yet */ }
  }
}

function mb(bytes) { return `${(bytes / 1048576).toFixed(1)} MB`; }

module.exports = { VideoPreviews, ffmpegArgs, seconds, VIDEO_EXTENSIONS, MIN_SOURCE_BYTES };
