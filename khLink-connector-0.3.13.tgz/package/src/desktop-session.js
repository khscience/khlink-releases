'use strict';

// The desktop account session for a computer without the Tauri desktop app (the
// khLink app on macOS). It does what kh-link-desktop lib.rs does with its
// session: account, account pairing codes (with the pairing v2 key envelope),
// bound devices, logout, and the connector's local direct-connection control.
// `khlink desktop <command> [json]` prints one JSON line: { ok, value } or { ok: false, error }.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const sodium = require('libsodium-wrappers-sumo');
const { identityStore } = require('./account-login');

const SESSION_FILE = 'desktop-session.dat';
const REFRESH_MARGIN_MS = 60_000;

function sessionStore({ dir, protect, unprotect }) {
  const file = path.join(dir, SESSION_FILE);
  return {
    file,
    load() {
      try {
        const value = JSON.parse(unprotect(fs.readFileSync(file, 'utf8')));
        return value?.accountId && value?.refreshToken ? value : null;
      } catch { return null; }
    },
    save(session) {
      fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
      fs.writeFileSync(file, protect(JSON.stringify(session)), { mode: 0o600 });
    },
    clear() { try { fs.unlinkSync(file); } catch { /* already gone */ } },
  };
}

async function request(fetchFn, url, { method = 'GET', token = null, body } = {}) {
  const response = await fetchFn(url, {
    method,
    headers: { ...(body === undefined ? {} : { 'content-type': 'application/json' }), ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(20_000),
  });
  const text = await response.text();
  let value = null; try { value = text ? JSON.parse(text) : null; } catch { value = null; }
  if (!response.ok) {
    const message = value?.message || text || response.statusText;
    throw new Error(`${method} ${new URL(url).pathname} 失败 (${response.status})：${Array.isArray(message) ? message.join('; ') : message}`);
  }
  return value || {};
}

/** Wraps the account key for a phone that asked to pair (kh-link-desktop pairing_envelope). */
function pairingEnvelope(identity, pairingId, deviceId, phonePublicKey) {
  const priv = Buffer.from(identity.privateKey, 'base64');
  const shared = sodium.crypto_scalarmult(priv, Buffer.from(phonePublicKey, 'base64'));
  const key = crypto.createHash('sha256').update('KH Link pairing v2').update(shared).update(pairingId).digest();
  const nonce = crypto.randomBytes(24);
  const aad = Buffer.from(`kh-link-pairing-v2|${pairingId}|${deviceId}`);
  const ciphertext = sodium.crypto_aead_xchacha20poly1305_ietf_encrypt(Buffer.from(identity.accountKey, 'base64'), aad, null, nonce, key);
  return JSON.stringify({
    version: 2,
    algorithm: 'X25519-XChaCha20-Poly1305',
    desktopPublicKey: Buffer.from(sodium.crypto_scalarmult_base(priv)).toString('base64'),
    nonce: nonce.toString('base64'),
    ciphertext: Buffer.from(ciphertext).toString('base64'),
  });
}

function createDesktop({ dataDir, protect, unprotect, serverUrl, fetchFn = fetch }) {
  const sessions = sessionStore({ dir: dataDir, protect, unprotect });
  const identities = identityStore({ dir: dataDir, protect, unprotect });
  const api = () => `${(sessions.load()?.serverUrl || serverUrl).replace(/\/$/, '')}/api/v2`;

  const fresh = (session) => session?.accessToken && session.expiresAt > Date.now() + REFRESH_MARGIN_MS;

  // The window runs several commands at once, each its own process: one
  // refreshes at a time, and the others take the token it saved. Two using
  // the same refresh token could have the second refused and sign out.
  async function withRefreshLock(fn) {
    const lock = path.join(dataDir, 'desktop-session.lock');
    const deadline = Date.now() + 15_000;
    for (;;) {
      try { fs.mkdirSync(lock); break; } catch (error) {
        if (error.code !== 'EEXIST') throw error;
        try { if (Date.now() - fs.statSync(lock).mtimeMs > 30_000) { fs.rmSync(lock, { recursive: true, force: true }); continue; } } catch { continue; }
        if (Date.now() > deadline) throw new Error('账号登录状态正在刷新，请稍后再试');
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
    }
    try { return await fn(); } finally { fs.rmSync(lock, { recursive: true, force: true }); }
  }

  async function token() {
    const first = sessions.load();
    if (!first) throw new Error('尚未登录');
    if (fresh(first)) return first.accessToken;
    return withRefreshLock(async () => {
      const session = sessions.load();
      if (!session) throw new Error('尚未登录');
      if (fresh(session)) return session.accessToken;
      const identity = identities.load();
      try {
        const value = await request(fetchFn, `${api()}/session/refresh`, {
          method: 'POST', body: { accountId: session.accountId, deviceId: identity?.deviceId, refreshToken: session.refreshToken },
        });
        sessions.save({ ...session, accessToken: value.accessToken, refreshToken: value.refreshToken, expiresAt: value.expiresAt });
        return value.accessToken;
      } catch (error) {
        if (/\(401\)/.test(error.message)) sessions.clear();
        throw error;
      }
    });
  }

  async function authed(method, route, body) {
    return request(fetchFn, `${api()}${route}`, { method, token: await token(), body });
  }

  // The connector's local control port for QR direct connection (direct-hub.js).
  async function direct(method, route, body) {
    let control;
    try { control = JSON.parse(fs.readFileSync(path.join(dataDir, 'direct-control.json'), 'utf8')); }
    catch { throw new Error('请启动支持二维码直连的新版本连接器'); }
    const port = Number(control.port);
    if (!(port > 0 && port <= 65535)) throw new Error('本机控制端口无效');
    const response = await fetchFn(`http://127.0.0.1:${port}${route}`, {
      method,
      headers: { authorization: `Bearer ${unprotect(control.protected)}`, ...(body === undefined ? {} : { 'content-type': 'application/json' }) },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: AbortSignal.timeout(method === 'GET' ? 3_000 : 50_000),
    }).catch((error) => { throw new Error(`本机直连控制暂不可用：${error.message}`); });
    const value = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(value?.error || '直连操作失败');
    return value;
  }

  return {
    sessions,
    async state() {
      const session = sessions.load();
      return { authenticated: Boolean(session), profile: session?.profile || null };
    },
    account: () => authed('GET', '/account'),
    async create_pairing() {
      const value = await authed('POST', '/pairing', {});
      if (!value.id || !value.secret || !value.expiresAt) throw new Error('配对响应不完整');
      const server = sessions.load()?.serverUrl || serverUrl;
      const payload = `khlink://pair?v=2&server=${encodeURIComponent(server)}&id=${value.id}&secret=${value.secret}&expiresAt=${value.expiresAt}`;
      return { id: value.id, secret: value.secret, expiresAt: value.expiresAt, payload };
    },
    pairing_status: ({ id }) => authed('GET', `/pairing/${encodeURIComponent(id)}`),
    async confirm_pairing({ id }) {
      await sodium.ready;
      const status = await authed('GET', `/pairing/${encodeURIComponent(id)}`);
      if (status.status !== 'pending') throw new Error('手机尚未提交配对申请');
      const identity = identities.load();
      if (!identity) throw new Error('这台电脑的身份信息丢失，请重新登录');
      const keyEnvelope = pairingEnvelope(identity, id, status.deviceId, status.publicKey);
      return authed('POST', `/pairing/${encodeURIComponent(id)}/confirm`, { keyEnvelope });
    },
    revoke_device: ({ deviceId }) => authed('POST', '/devices/revoke', { deviceId }),
    async logout() { sessions.clear(); return {}; },
    direct: ({ method = 'GET', route, body }) => direct(method, route, body),
  };
}

/** Saves the session from loginAccount, with the server it belongs to. */
function saveLoginSession({ dataDir, protect, unprotect, serverUrl, session, profile }) {
  if (!session?.refreshToken) return;
  sessionStore({ dir: dataDir, protect, unprotect }).save({
    serverUrl, accountId: session.accountId, accessToken: session.accessToken,
    refreshToken: session.refreshToken, expiresAt: session.expiresAt || 0, profile: profile || null,
  });
}

async function runDesktopCommand(command, args, options) {
  const desktop = createDesktop(options);
  const fn = desktop[command];
  if (typeof fn !== 'function' || command === 'sessions') throw new Error(`未知命令：${command}`);
  return fn(args || {});
}

module.exports = { createDesktop, sessionStore, pairingEnvelope, saveLoginSession, runDesktopCommand, SESSION_FILE };
