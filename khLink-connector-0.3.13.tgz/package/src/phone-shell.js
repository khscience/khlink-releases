'use strict';
// Running a command on this computer from a paired phone
// (docs/zh-CN/phone-shell-2026-11.md).
//
// The switch lives in phone-shell.json next to config.json and is written by
// the desktop console only: there is no phone action that can change it. A
// phone must also be allowed one by one, by the relay-authenticated device id.
// Requests travel as file.command frames, which the relay never stores, so a
// reconnect cannot replay a command; requestIds are also remembered here.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn, execFileSync } = require('node:child_process');

const MAX_COMMAND_CHARS = 8000;
const MAX_OUTPUT_BYTES = 1024 * 1024;
const MAX_RUNNING = 2;
const MAX_PER_MINUTE = 10;
const DEFAULT_TIMEOUT_SEC = 120;
const MAX_TIMEOUT_SEC = 30 * 60;
const KEEP_FINISHED_MS = 30 * 60 * 1000;
const MAX_ISSUED_SKEW_MS = 5 * 60 * 1000;
const AUDIT_KEEP_DAYS = 90;
const MAX_PENDING = 8;

// Reminders, not the boundary: the switch, the per-phone allow list and the
// confirmation on the phone are what protect the computer.
const DANGERS = [
  [/\b(rm|rmdir)\b[^\n]*\s-[a-z]*[rf]/i, '递归或强制删除文件'],
  [/\bRemove-Item\b[^\n]*-(Recurse|Force)\b/i, '递归或强制删除文件'],
  [/\b(del|erase)\b[^\n]*\s\/[sq]\b/i, '批量删除文件'],
  [/\b(rd|rmdir)\b[^\n]*\s\/s\b/i, '删除整个目录'],
  [/\b(format|diskpart|mkfs|Format-Volume|Clear-Disk|Initialize-Disk)\b/i, '格式化或分区磁盘'],
  [/\b(reg(\.exe)?\s+(add|delete|import)|Set-ItemProperty\s+[^\n]*HK(LM|CU)|Remove-ItemProperty|New-ItemProperty)\b/i, '修改注册表'],
  [/\b(shutdown|Restart-Computer|Stop-Computer|reboot|halt|poweroff)\b/i, '关机或重启'],
  [/\b(Stop-Service|Set-Service|sc(\.exe)?\s+(stop|delete|config)|net\s+(stop|user|localgroup)|launchctl\s+(unload|bootout))\b/i, '修改系统服务或账户'],
  [/\b(Invoke-Expression|iex)\b/i, '执行动态生成的代码'],
  [/\b(curl|wget|iwr|irm|Invoke-WebRequest|Invoke-RestMethod)\b[^\n]*\|\s*(sh|bash|zsh|iex|Invoke-Expression|powershell|pwsh)\b/i, '下载后直接执行'],
  [/\bSet-ExecutionPolicy\b/i, '修改脚本执行策略'],
  [/\b(sudo|runas|Start-Process\b[^\n]*-Verb\s+RunAs)\b/i, '请求管理员权限'],
  [/\b(takeown|icacls|chmod\s+-R|chown\s+-R|attrib\b[^\n]*[+-][shr])\b/i, '修改文件权限'],
  [/\b(bcdedit|vssadmin|wbadmin|cipher\s+\/w)\b/i, '修改启动项或删除备份'],
  [/(\.ssh|\.aws|\.config[\\/]gh|Credentials|\.git-credentials|FengzhuAgentBridge|id_rsa|id_ed25519|\.npmrc|\.netrc)/i, '读取或改动凭据所在位置'],
  [/\b(git\s+push\b[^\n]*--force|git\s+reset\s+--hard|git\s+clean\s+-[a-z]*f)/i, '不可恢复的 Git 操作'],
];

function dangers(command) {
  const found = [];
  for (const [pattern, label] of DANGERS) if (pattern.test(command) && !found.includes(label)) found.push(label);
  return found;
}

function shellsFor(platform) { return platform === 'win32' ? ['powershell', 'cmd'] : ['zsh']; }

// Phones name the fence language; anything shell-like maps to this
// computer's default shell, cmd/bat to cmd.exe.
function resolveShell(requested, platform) {
  const name = String(requested || '').toLowerCase();
  if (platform !== 'win32') return 'zsh';
  return ['cmd', 'bat', 'batch'].includes(name) ? 'cmd' : 'powershell';
}

function cleanEnv(env) {
  const out = {};
  for (const [key, value] of Object.entries(env || {})) {
    if (/^(FENGZHU|KHLINK|KH_LINK|ELECTRON_RUN_AS_NODE|NODE_OPTIONS)/i.test(key)) continue;
    out[key] = value;
  }
  return out;
}

class PhoneShell {
  constructor({ home, log = () => {}, platform = process.platform, now = () => Date.now(), spawnImpl = spawn, kill = null, workspace = null } = {}) {
    this.home = home;
    this.file = path.join(home, 'phone-shell.json');
    this.requestsFile = path.join(home, 'phone-shell-requests.json');
    this.auditDir = path.join(home, 'logs');
    this.log = log;
    this.platform = platform;
    this.now = now;
    this.spawnImpl = spawnImpl;
    this.killImpl = kill || ((child) => this.killTree(child));
    this.workspace = workspace;
    this.runs = new Map();
    this.byRequest = new Map();
    this.recent = [];
    this.watch = null;
  }

  settings() {
    let raw = {};
    try { raw = JSON.parse(fs.readFileSync(this.file, 'utf8')); } catch {}
    const devices = Array.isArray(raw.devices) ? raw.devices.filter((d) => d && typeof d.id === 'string' && d.id) : [];
    const timeout = Math.round(Number(raw.timeoutSec) || DEFAULT_TIMEOUT_SEC);
    return { enabled: raw.enabled === true, devices, timeoutSec: Math.min(MAX_TIMEOUT_SEC, Math.max(5, timeout)) };
  }

  allowed(deviceId, settings = this.settings()) {
    return Boolean(settings.enabled && deviceId && settings.devices.some((d) => d.id === deviceId));
  }

  // A phone that asks while not yet allowed is listed for the desktop to
  // approve; names are labels only, the id is what is trusted.
  noteRequest(deviceId, phoneName) {
    if (!deviceId) return;
    let list = [];
    try { list = JSON.parse(fs.readFileSync(this.requestsFile, 'utf8')); } catch {}
    if (!Array.isArray(list)) list = [];
    list = list.filter((r) => r && r.id !== deviceId);
    list.unshift({ id: deviceId, name: String(phoneName || '').slice(0, 60) || null, at: this.now() });
    try {
      fs.mkdirSync(this.home, { recursive: true });
      fs.writeFileSync(this.requestsFile, JSON.stringify(list.slice(0, MAX_PENDING), null, 2));
    } catch (error) { this.log(`phone shell: request list not saved: ${error.message}`); }
  }

  status(deviceId, args = {}) {
    const settings = this.settings();
    const allowed = this.allowed(deviceId, settings);
    if (settings.enabled && !allowed && args.ask === true) this.noteRequest(deviceId, args.phoneName);
    return { enabled: settings.enabled, allowed, platform: this.platform, shells: shellsFor(this.platform), timeoutSec: settings.timeoutSec, maxCommandChars: MAX_COMMAND_CHARS };
  }

  check(args = {}) {
    const command = String(args.command || '');
    return { dangers: dangers(command), shell: resolveShell(args.shell, this.platform), tooLong: command.length > MAX_COMMAND_CHARS };
  }

  refuse(code, message) { throw Object.assign(new Error(message), { code }); }

  run(args = {}, deviceId = null) {
    const requestId = String(args.requestId || '');
    if (!requestId || requestId.length > 100) this.refuse('shell_bad_request', '命令请求不完整');
    // The same request again (a resend after reconnect) is the same run.
    const existing = this.byRequest.get(requestId);
    if (existing) return this.view(existing, 0);
    const settings = this.settings();
    if (!settings.enabled) this.refuse('shell_disabled', '电脑上没有开启手机命令行，请在电脑上的 khLink 设置里开启');
    if (!this.allowed(deviceId, settings)) {
      this.noteRequest(deviceId, args.phoneName);
      this.refuse('shell_not_allowed', '这台手机还没有获得授权，请在电脑上的 khLink 设置里允许它');
    }
    const issuedAt = Number(args.issuedAt);
    if (!Number.isFinite(issuedAt) || Math.abs(this.now() - issuedAt) > MAX_ISSUED_SKEW_MS) {
      this.refuse('shell_stale', '这条命令请求已过期，请重新点击运行');
    }
    const command = String(args.command || '').replace(/\r\n/g, '\n');
    if (!command.trim()) this.refuse('shell_empty', '命令是空的');
    if (command.length > MAX_COMMAND_CHARS) this.refuse('shell_too_long', `命令太长（超过 ${MAX_COMMAND_CHARS} 个字符）`);
    const found = dangers(command);
    if (found.length && args.confirmDanger !== true) this.refuse('shell_danger_unconfirmed', `这条命令包含高风险操作（${found.join('、')}），需要再确认一次`);
    const active = [...this.runs.values()].filter((r) => r.state === 'running').length;
    if (active >= MAX_RUNNING) this.refuse('shell_busy', `电脑上已有 ${MAX_RUNNING} 条命令在运行，请等它们结束或先停止`);
    const cutoff = this.now() - 60_000;
    this.recent = this.recent.filter((t) => t > cutoff);
    if (this.recent.length >= MAX_PER_MINUTE) this.refuse('shell_rate', '运行太频繁，请稍后再试');
    this.recent.push(this.now());

    const shell = resolveShell(args.shell, this.platform);
    const cwd = this.pickCwd(args.cwd);
    const device = settings.devices.find((d) => d.id === deviceId);
    const run = {
      id: `sh-${this.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
      requestId, deviceId, deviceName: device?.name || null, command, shell, cwd,
      startedAt: this.now(), endedAt: null, state: 'running', exitCode: null, reason: null,
      chunks: [], size: 0, dropped: 0, child: null, timer: null, tempFile: null, dangers: found,
    };
    this.runs.set(run.id, run);
    this.byRequest.set(requestId, run);
    try { this.start(run, settings.timeoutSec); }
    catch (error) { this.finish(run, null, 'failed', error.message); }
    this.ensureWatch();
    return this.view(run, 0);
  }

  pickCwd(requested) {
    const candidates = [requested, this.workspace, os.homedir()];
    for (const dir of candidates) {
      if (typeof dir !== 'string' || !dir || !path.isAbsolute(dir)) continue;
      try { if (fs.statSync(dir).isDirectory()) return dir; } catch {}
    }
    return os.homedir();
  }

  start(run, timeoutSec) {
    let file; let argv;
    if (this.platform === 'win32' && run.shell === 'cmd') {
      run.tempFile = path.join(os.tmpdir(), `khlink-shell-${run.id}.cmd`);
      fs.writeFileSync(run.tempFile, `@echo off\r\nchcp 65001 >nul\r\n${run.command.replace(/\n/g, '\r\n')}\r\n`, 'utf8');
      file = process.env.ComSpec || 'cmd.exe';
      argv = ['/d', '/c', run.tempFile];
    } else if (this.platform === 'win32') {
      const script = `$ProgressPreference='SilentlyContinue'\n[Console]::OutputEncoding=[Text.Encoding]::UTF8\n$OutputEncoding=[Text.Encoding]::UTF8\n${run.command}\nif ($LASTEXITCODE) { exit $LASTEXITCODE }`;
      file = 'powershell.exe';
      argv = ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')];
    } else {
      file = '/bin/zsh';
      argv = ['-c', run.command];
    }
    const child = this.spawnImpl(file, argv, {
      cwd: run.cwd, env: cleanEnv(process.env), windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'], detached: this.platform !== 'win32',
    });
    run.child = child;
    const take = (data) => this.append(run, Buffer.isBuffer(data) ? data : Buffer.from(String(data)));
    child.stdout?.on('data', take);
    child.stderr?.on('data', take);
    child.on('error', (error) => this.finish(run, null, 'failed', error.message));
    child.on('close', (code) => this.finish(run, code, run.reason === 'cancel' ? 'cancelled' : run.reason === 'timeout' ? 'timeout' : 'exited'));
    run.timer = setTimeout(() => this.stop(run, 'timeout'), timeoutSec * 1000);
    run.timer.unref?.();
    this.audit(run, 'start');
  }

  append(run, buffer) {
    run.chunks.push(buffer);
    run.size += buffer.length;
    while (run.size - run.dropped > MAX_OUTPUT_BYTES && run.chunks.length > 1) {
      run.dropped += run.chunks.shift().length;
    }
  }

  // Output from an absolute byte offset; bytes dropped from the front are
  // reported so the phone can say that the start was cut.
  view(run, offset) {
    const from = Math.max(Number(offset) || 0, run.dropped);
    const all = Buffer.concat(run.chunks);
    let slice = all.subarray(from - run.dropped);
    // Do not split a UTF-8 character across two polls while still running.
    if (run.state === 'running') {
      let end = slice.length;
      for (let i = slice.length - 1, back = 0; i >= 0 && back < 4; i--, back++) {
        const byte = slice[i];
        if ((byte & 0xc0) === 0x80) continue;
        const need = byte >= 0xf0 ? 4 : byte >= 0xe0 ? 3 : byte >= 0xc0 ? 2 : 1;
        if (slice.length - i < need) end = i;
        break;
      }
      slice = slice.subarray(0, end);
    }
    return {
      runId: run.id, requestId: run.requestId, state: run.state, shell: run.shell, cwd: run.cwd,
      startedAt: run.startedAt, endedAt: run.endedAt, exitCode: run.exitCode, error: run.state === 'failed' ? run.reason : null,
      output: slice.toString('utf8'), offset: from + slice.length, skipped: from > (Number(offset) || 0) ? from - (Number(offset) || 0) : 0,
      truncated: run.dropped > 0,
    };
  }

  poll(args = {}, deviceId = null) {
    const run = this.runs.get(String(args.runId || ''));
    if (!run || run.deviceId !== deviceId) this.refuse('shell_unknown_run', '找不到这条命令的运行记录');
    if (run.state === 'running' && !this.allowed(deviceId)) this.stop(run, 'cancel');
    return this.view(run, args.offset);
  }

  cancel(args = {}, deviceId = null) {
    const run = this.runs.get(String(args.runId || ''));
    if (!run || run.deviceId !== deviceId) this.refuse('shell_unknown_run', '找不到这条命令的运行记录');
    if (run.state === 'running') this.stop(run, 'cancel');
    return this.view(run, args.offset);
  }

  stop(run, reason) {
    if (run.state !== 'running') return;
    run.reason = reason;
    try { this.killImpl(run.child); } catch (error) { this.log(`phone shell: stop failed: ${error.message}`); }
  }

  killTree(child) {
    if (!child?.pid) return;
    if (this.platform === 'win32') {
      try { execFileSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore', timeout: 10_000 }); } catch {}
    } else {
      try { process.kill(-child.pid, 'SIGKILL'); } catch { try { child.kill('SIGKILL'); } catch {} }
    }
  }

  finish(run, code, state, reason = null) {
    if (run.state !== 'running') return;
    clearTimeout(run.timer);
    run.state = state;
    run.exitCode = Number.isInteger(code) ? code : null;
    if (state === 'failed') run.reason = reason || '命令没能启动';
    run.endedAt = this.now();
    run.child = null;
    if (run.tempFile) { try { fs.unlinkSync(run.tempFile); } catch {} }
    this.audit(run, 'end');
    this.prune();
  }

  // The desktop's switch off, or a phone taken off the list, stops what is
  // running within a couple of seconds.
  ensureWatch() {
    if (this.watch) return;
    this.watch = setInterval(() => {
      const settings = this.settings();
      const running = [...this.runs.values()].filter((r) => r.state === 'running');
      for (const run of running) if (!this.allowed(run.deviceId, settings)) this.stop(run, 'cancel');
      if (!running.length) { clearInterval(this.watch); this.watch = null; }
    }, 2000);
    this.watch.unref?.();
  }

  stopAll() { for (const run of this.runs.values()) this.stop(run, 'cancel'); }

  prune() {
    const cutoff = this.now() - KEEP_FINISHED_MS;
    for (const [id, run] of this.runs) {
      if (run.state !== 'running' && run.endedAt < cutoff) { this.runs.delete(id); this.byRequest.delete(run.requestId); }
    }
  }

  audit(run, phase) {
    const day = new Date(this.now());
    const stamp = `${day.getFullYear()}-${String(day.getMonth() + 1).padStart(2, '0')}-${String(day.getDate()).padStart(2, '0')}`;
    const entry = phase === 'start'
      ? { at: run.startedAt, event: 'start', run: run.id, device: run.deviceId, deviceName: run.deviceName, shell: run.shell, cwd: run.cwd, command: run.command, dangers: run.dangers }
      : { at: run.endedAt, event: 'end', run: run.id, device: run.deviceId, state: run.state, exitCode: run.exitCode, durationMs: run.endedAt - run.startedAt, outputBytes: run.size, error: run.state === 'failed' ? run.reason : undefined };
    try {
      fs.mkdirSync(this.auditDir, { recursive: true });
      fs.appendFileSync(path.join(this.auditDir, `shell-audit-${stamp}.log`), `${JSON.stringify(entry)}\n`);
      if (phase === 'start') this.cleanAudit();
    } catch (error) { this.log(`phone shell: audit not written: ${error.message}`); }
    this.log(phase === 'start'
      ? `phone shell ${run.id} start (${run.shell}, ${String(run.deviceId).slice(0, 8)})`
      : `phone shell ${run.id} ${run.state}${run.exitCode === null ? '' : ` code=${run.exitCode}`}`);
  }

  cleanAudit() {
    const cutoff = this.now() - AUDIT_KEEP_DAYS * 86400_000;
    let names = [];
    try { names = fs.readdirSync(this.auditDir); } catch { return; }
    for (const name of names) {
      const match = /^shell-audit-(\d{4})-(\d{2})-(\d{2})\.log$/.exec(name);
      if (match && new Date(+match[1], +match[2] - 1, +match[3]).getTime() < cutoff) {
        try { fs.unlinkSync(path.join(this.auditDir, name)); } catch {}
      }
    }
  }

  // Connector-owned phone actions; the caller passes the relay- or
  // direct-session-authenticated device id, never one from the payload.
  handle(action, args, deviceId) {
    if (action === 'shell.status') return this.status(deviceId, args);
    // Reading back or stopping one's own run stays possible after the switch
    // is turned off; starting or checking a new one does not.
    if (action === 'shell.poll') return this.poll(args, deviceId);
    if (action === 'shell.cancel') return this.cancel(args, deviceId);
    if (action === 'shell.run') return this.run(args, deviceId);
    const settings = this.settings();
    if (!settings.enabled) this.refuse('shell_disabled', '电脑上没有开启手机命令行，请在电脑上的 khLink 设置里开启');
    if (!this.allowed(deviceId, settings)) this.refuse('shell_not_allowed', '这台手机还没有获得授权，请在电脑上的 khLink 设置里允许它');
    if (action === 'shell.check') return this.check(args);
    this.refuse('shell_unknown_action', '电脑上的连接器不认识这个命令行操作');
  }
}

module.exports = { PhoneShell, dangers, resolveShell, cleanEnv, MAX_COMMAND_CHARS };
