'use strict';
// Images kept on this computer instead of inside history rows.
//
// A Codex screenshot or generated picture used to travel inside its encrypted
// history row, so every phone downloaded every image whenever it synced or
// prefetched a conversation, even when the picture sat in a collapsed
// "执行了 N 项操作" group nobody opened (2026-11-20: about 250 MB a day for one
// account). Large images are now replaced in the row by a reference
// { ref: sha256, mimeType, bytes }; the picture is stored here once by its
// content hash and a phone fetches it with `history.image` only when it is
// about to show it. Rows only switch to references when every phone of the
// account says it can load them (ImageRefPhones), so older phones keep seeing
// their images.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

// Images smaller than this stay inline: an icon costs less than a round trip.
const MIN_REF_BYTES = 32 * 1024;
const KEEP_DAYS = 90;
const MAX_CHUNK = 1024 * 1024;
const EXTENSIONS = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif', 'image/bmp': 'bmp', 'image/avif': 'avif' };
const MIME_BY_EXTENSION = Object.fromEntries(Object.entries(EXTENSIONS).filter(([mime]) => mime !== 'image/jpg').map(([mime, ext]) => [ext, mime]));
// Row types whose `images` may move out of the row. User messages are included
// (0.2.204): a message sent on this computer can carry several multi-megabyte
// reference pictures, repeated in every turn (2026-11-22: 01a1ef96 put about
// 150 MB of user-message images into history, which two phones downloaded
// again and again). The phone shows the references in the same bubble.
const REF_TYPES = new Set(['userMessage', 'imageView', 'imageGeneration', 'agentMessage', 'mcpToolCall', 'toolImages']);
const REF_PATTERN = /^[0-9a-f]{64}$/;

function parseDataUri(data) {
  if (typeof data !== 'string') return null;
  const match = data.match(/^data:(image\/[a-z0-9.+-]+);base64,([a-z0-9+/=]+)$/i);
  if (!match) return null;
  return { mimeType: match[1].toLowerCase(), base64: match[2] };
}

class HistoryImages {
  constructor(dir, { io = fs, now = Date.now, minRefBytes = MIN_REF_BYTES } = {}) {
    this.dir = dir; this.io = io; this.now = now; this.minRefBytes = minRefBytes;
    this.known = new Set();
  }

  fileFor(ref, mimeType) { return path.join(this.dir, `${ref}.${EXTENSIONS[mimeType] || 'bin'}`); }

  // Store one data: URI and return its reference, or null to keep it inline.
  put(data) {
    const parsed = parseDataUri(data);
    if (!parsed) return null;
    // base64 length → decoded size without decoding small images.
    const approx = Math.floor(parsed.base64.length * 3 / 4);
    if (approx < this.minRefBytes) return null;
    const bytes = Buffer.from(parsed.base64, 'base64');
    const ref = crypto.createHash('sha256').update(bytes).digest('hex');
    const file = this.fileFor(ref, parsed.mimeType);
    if (!this.known.has(file)) {
      if (!this.io.existsSync(file)) {
        this.io.mkdirSync(this.dir, { recursive: true });
        const temp = `${file}.${process.pid}.${crypto.randomBytes(4).toString('hex')}.tmp`;
        this.io.writeFileSync(temp, bytes);
        try { this.io.renameSync(temp, file); }
        catch (error) { try { this.io.unlinkSync(temp); } catch { /* already gone */ } if (!this.io.existsSync(file)) throw error; }
      }
      this.known.add(file);
    }
    return { ref, mimeType: parsed.mimeType, bytes: bytes.length };
  }

  // The row with its large images replaced by references. Returns the same
  // object when nothing changes; a storage failure keeps the image inline.
  refsFor(value, onError = null) {
    if (!value || typeof value !== 'object' || !REF_TYPES.has(value.type) || !Array.isArray(value.images) || !value.images.length) return value;
    const images = []; const refs = Array.isArray(value.imageRefs) ? [...value.imageRefs] : [];
    let moved = false;
    for (const image of value.images) {
      let ref = null;
      try { ref = this.put(image?.data); } catch (error) { onError?.(error); }
      if (ref) { if (!refs.some((item) => item.ref === ref.ref)) refs.push(ref); moved = true; }
      else images.push(image);
    }
    if (!moved) return value;
    const next = { ...value, imageRefs: refs };
    if (images.length) next.images = images; else delete next.images;
    return next;
  }

  find(ref) {
    if (!REF_PATTERN.test(String(ref || ''))) return null;
    for (const [ext, mimeType] of Object.entries(MIME_BY_EXTENSION)) {
      const file = path.join(this.dir, `${ref}.${ext}`);
      if (this.io.existsSync(file)) return { file, mimeType };
    }
    const file = path.join(this.dir, `${ref}.bin`);
    return this.io.existsSync(file) ? { file, mimeType: 'application/octet-stream' } : null;
  }

  // One chunk of a stored image for `history.image`.
  read(ref, offset = 0, size = 512 * 1024) {
    const found = this.find(ref);
    if (!found) throw new Error('这张图片已不在电脑上');
    const total = this.io.statSync(found.file).size;
    const start = Math.max(0, Math.min(total, Math.floor(Number(offset) || 0)));
    const length = Math.max(1, Math.min(MAX_CHUNK, Math.floor(Number(size) || 512 * 1024)));
    const end = Math.min(total, start + length);
    const chunk = Buffer.alloc(end - start);
    if (chunk.length) {
      const fd = this.io.openSync(found.file, 'r');
      try { this.io.readSync(fd, chunk, 0, chunk.length, start); } finally { this.io.closeSync(fd); }
    }
    if (start === 0) { try { const at = new Date(this.now()); this.io.utimesSync(found.file, at, at); } catch { /* best effort */ } }
    return { ref, mimeType: found.mimeType, data: chunk.toString('base64'), offset: start, bytes: total, eof: end >= total };
  }

  // Drop images nobody fetched or wrote for KEEP_DAYS.
  prune(keepDays = KEEP_DAYS) {
    let names; try { names = this.io.readdirSync(this.dir); } catch { return 0; }
    const cutoff = this.now() - keepDays * 86_400_000; let removed = 0;
    for (const name of names) {
      const file = path.join(this.dir, name);
      try {
        const stat = this.io.statSync(file);
        if (stat.isFile() && stat.mtimeMs < cutoff) { this.io.unlinkSync(file); this.known.delete(file); removed++; }
      } catch { /* raced with another prune */ }
    }
    return removed;
  }
}

// Which phones can load referenced images. Each phone says so when it asks
// for `capabilities`; references are used only while every phone heard from
// in the last STALE_DAYS can load them. Kept on disk so a restart does not
// fall back to inline images until each phone reconnects.
const STALE_DAYS = 14;

class ImageRefPhones {
  constructor(file, { now = Date.now, io = fs } = {}) {
    this.file = file; this.now = now; this.io = io;
    this.phones = {};
    try { const saved = JSON.parse(this.io.readFileSync(file, 'utf8')); if (saved && typeof saved.phones === 'object') this.phones = saved.phones; } catch { /* none yet */ }
  }

  // A phone's answer. True when this changed whether references are used.
  note(deviceId, supported) {
    if (typeof deviceId !== 'string' || !deviceId || deviceId.endsWith('.connector')) return false;
    const before = this.enabled();
    const previous = this.phones[deviceId];
    const at = this.now();
    // Save at most hourly for an unchanged answer: capabilities is asked often.
    if (previous && previous.ok === supported && at - previous.at < 3_600_000) return false;
    this.phones[deviceId] = { ok: supported === true, at };
    try {
      this.io.mkdirSync(path.dirname(this.file), { recursive: true });
      let forceUntil; try { forceUntil = JSON.parse(this.io.readFileSync(this.file, 'utf8')).forceUntil; } catch { /* none */ }
      this.io.writeFileSync(this.file, JSON.stringify({ phones: this.phones, ...(forceUntil ? { forceUntil } : {}) }) + '\n');
    } catch { /* kept in memory */ }
    return before !== this.enabled();
  }

  recent() {
    const cutoff = this.now() - STALE_DAYS * 86_400_000;
    return Object.entries(this.phones).filter(([, phone]) => Number(phone?.at) >= cutoff);
  }

  // A temporary override for testing on one phone while another is still on
  // an older version: { "forceUntil": <ms> } in the same file, read at most
  // once a minute.
  forced() {
    if (this.forcedAt !== undefined && this.now() - this.forcedAt < 60_000) return this.forcedValue;
    this.forcedAt = this.now();
    try { this.forcedValue = Number(JSON.parse(this.io.readFileSync(this.file, 'utf8')).forceUntil) > this.now(); } catch { this.forcedValue = false; }
    return this.forcedValue;
  }

  enabled() {
    if (this.forced()) return true;
    const recent = this.recent();
    return recent.length > 0 && recent.every(([, phone]) => phone.ok === true);
  }
}

module.exports = { HistoryImages, ImageRefPhones, MIN_REF_BYTES, REF_TYPES, parseDataUri };
