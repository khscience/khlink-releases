// Google Antigravity (com.google.antigravity) on macOS, driven through its
// window the way scripts/antigravity-send.ps1 does on Windows: open the
// conversation from its sidebar link (/c/<id>), paste into "Message input",
// press "Send message"; "Stop" for stop. One JSON result per request, in
// AdapterResponse.payload, with the same fields the Windows script prints.
// It never uses Antigravity's local server, debugging port or sign-in token.
import AppKit
import ApplicationServices
import Carbon.HIToolbox
import Foundation

struct AGResult: Encodable {
    var ok: Bool
    var reason: String? = nil
    var mayHaveSent: Bool? = nil
    var receiptSource: String? = nil
    var confirmedAt: Double? = nil
    var queuedInWindow: Bool? = nil
    var steered: Bool? = nil
    var conversationId: String? = nil
    var ids: [String]? = nil
    var sendEnabled: Bool? = nil
    var queuedItems: [String]? = nil
    // settings / set / new: what the selectors under the message box show.
    var model: String? = nil
    var permission: String? = nil
    var project: String? = nil
    var currentProject: String? = nil
    var models: [AGModel]? = nil
    var permissions: [AGPreset]? = nil
}

struct AGModel: Encodable {
    var name: String
    var available: Bool
    var level: String? = nil
    var levels: [String]? = nil
}

struct AGPreset: Encodable {
    var name: String
    var detail: String
    var isDefault: Bool
}

/// The JSON object a request carries in `text` (new, set).
private func agRequestObject(_ req: AdapterRequest) -> [String: Any] {
    guard let data = (req.text ?? "").data(using: .utf8),
          let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return [:] }
    return obj
}

private func agString(_ obj: [String: Any], _ key: String) -> String {
    ((obj[key] as? String) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
}

private func agResponse(_ r: AGResult, controls: [String]? = nil) -> AdapterResponse {
    var resp = r.ok ? makeOk("antigravity", r.reason ?? "ok", delivery: r.mayHaveSent == false ? "not_sent" : "sent")
        : makeError(r.reason ?? "failed", r.reason ?? "failed", delivery: r.mayHaveSent == true ? "uncertain" : "not_sent")
    if let data = try? jsonEncoder.encode(r) { resp.payload = String(data: data, encoding: .utf8) }
    resp.controls = controls
    return resp
}

private func agFail(_ reason: String, mayHaveSent: Bool = false) -> AdapterResponse {
    agResponse(AGResult(ok: false, reason: reason, mayHaveSent: mayHaveSent))
}

private let agIdPattern = try! NSRegularExpression(pattern: "/c/([0-9a-f-]{36})(?:[?#/]|$)")

func agConversationId(inURL url: String) -> String? {
    let range = NSRange(url.startIndex..., in: url)
    guard let m = agIdPattern.firstMatch(in: url, range: range), let r = Range(m.range(at: 1), in: url) else { return nil }
    return String(url[r])
}

private func agNorm(_ s: String) -> String {
    s.replacingOccurrences(of: "\r", with: "").replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression).trimmingCharacters(in: .whitespacesAndNewlines)
}

/// The window whose page shows a conversation, or the largest one.
private func agWindow(_ app: NSRunningApplication) -> AXUIElement? {
    let axApp = AXHelper.appElement(for: app)
    let wins = AXHelper.windows(axApp)
    if wins.isEmpty { return nil }
    let scored = wins.map { w -> (AXUIElement, CGFloat) in
        let f = AXHelper.frame(w) ?? .zero
        return (w, f.width * f.height)
    }
    return scored.max(by: { $0.1 < $1.1 })?.0
}

private func agWebAreas(_ window: AXUIElement) -> [AXUIElement] {
    var out: [AXUIElement] = []
    // Antigravity 2.35 wraps its page in a blank data: web area; the page
    // with the /c/<id> address is nested inside it, so keep looking inside.
    AXHelper.walk(window, maxDepth: 60, maxNodes: 12000) { el, _ in
        if AXHelper.role(el) == "AXWebArea" { out.append(el) }
        return true
    }
    return out
}

private func agCurrentId(_ window: AXUIElement) -> String? {
    for area in agWebAreas(window) { if let id = agConversationId(inURL: AXHelper.urlStr(area)) { return id } }
    return nil
}

private func agFind(_ window: AXUIElement, maxNodes: Int = 30000, _ match: (AXUIElement, String, String) -> Bool) -> AXUIElement? {
    var found: AXUIElement?
    AXHelper.walk(window, maxDepth: 80, maxNodes: maxNodes) { el, _ in
        if found != nil { return false }
        let role = AXHelper.role(el)
        if match(el, role, AXHelper.label(el)) { found = el; return false }
        return true
    }
    return found
}

private func agFindAll(_ window: AXUIElement, _ match: (AXUIElement, String, String) -> Bool) -> [AXUIElement] {
    var out: [AXUIElement] = []
    AXHelper.walk(window, maxDepth: 80, maxNodes: 30000) { el, _ in
        if match(el, AXHelper.role(el), AXHelper.label(el)) { out.append(el) }
        return true
    }
    return out
}

private func agLink(_ window: AXUIElement, id: String) -> AXUIElement? {
    agFind(window) { el, role, _ in role == "AXLink" && AXHelper.urlStr(el).contains("/c/\(id)") }
}

private func agMessageBox(_ window: AXUIElement) -> AXUIElement? {
    let candidates = agFindAll(window) { el, role, label in
        let ph = AXHelper.stringAttr(el, "AXPlaceholderValue")
        return [kAXTextAreaRole, kAXComboBoxRole, kAXTextFieldRole].contains(role)
            && (AXHelper.desc(el) == "Message input" || AXHelper.title(el) == "Message input" || ph.hasPrefix("Message") || label == "Message input")
    }
    // The composer of the open conversation is the lowest one on screen.
    return candidates.max(by: { (AXHelper.frame($0)?.minY ?? 0) < (AXHelper.frame($1)?.minY ?? 0) })
}

/// The editor reports its placeholder while empty.
private func agBoxText(_ box: AXUIElement) -> String {
    let v = AXHelper.valueStr(box)
    let ph = AXHelper.stringAttr(box, "AXPlaceholderValue")
    if v == "Message input" || (!ph.isEmpty && v == ph) { return "" }
    return v.trimmingCharacters(in: .whitespacesAndNewlines)
}

private func agButton(_ window: AXUIElement, _ pattern: String) -> AXUIElement? {
    let re = try! NSRegularExpression(pattern: pattern, options: [.caseInsensitive])
    return agFind(window) { _, role, label in
        role == kAXButtonRole && re.firstMatch(in: label, range: NSRange(label.startIndex..., in: label)) != nil
    }
}

/// This box's own Send: with several panes (or a side chat) open there is
/// more than one, and the first one found can be another pane's. Take the
/// one nearest this box and wait for it to become enabled.
private func agSendButton(_ window: AXUIElement, box: AXUIElement?) -> AXUIElement? {
    let candidates = agFindAll(window) { _, role, label in
        role == kAXButtonRole && ["send message", "send"].contains(label.trimmingCharacters(in: .whitespaces).lowercased())
    }
    let anchor = box.flatMap { AXHelper.frame($0) }
    func distance(_ el: AXUIElement) -> CGFloat {
        guard let a = anchor, let f = AXHelper.frame(el) else { return .greatestFiniteMagnitude }
        return hypot(f.midX - a.maxX, f.midY - a.maxY)
    }
    // Only the nearest: an enabled Send further away is another pane's,
    // possibly holding the user's own draft.
    return candidates.min { distance($0) < distance($1) }
}

/// Messages Antigravity holds until the running turn ends: each queued row
/// has "Send now: <text>", "Edit: <text>" and "Delete: <text>" buttons.
private func agQueued(_ window: AXUIElement, _ verb: String = "Send now") -> [(AXUIElement, String)] {
    let prefix = verb.lowercased() + ": "
    var out: [(AXUIElement, String)] = []
    for el in agFindAll(window, { _, role, label in role == kAXButtonRole && label.lowercased().hasPrefix(prefix) }) {
        out.append((el, String(AXHelper.label(el).dropFirst(prefix.count))))
    }
    return out
}

/// A row shows its text in full or cut short; either way it matches.
private func agSameQueued(_ a: String, _ b: String) -> Bool {
    let x = agNorm(a).lowercased(), y = agNorm(b).lowercased()
    if x.isEmpty || y.isEmpty { return false }
    return x == y || x.hasPrefix(y) || y.hasPrefix(x)
}

/// "Send now" (steer) or "Delete" (cancel) on the queued row for `text`.
private func agQueuedAction(_ window: AXUIElement, text: String, verb: String, done: String, missing: String) -> AdapterResponse {
    let items = agQueued(window).map { $0.1 }
    func fail(_ reason: String) -> AdapterResponse {
        var r = AGResult(ok: false, reason: reason, mayHaveSent: false); r.queuedItems = items; return agResponse(r)
    }
    if items.isEmpty { return fail("no_queue") }
    guard agQueued(window).contains(where: { agSameQueued($0.1, text) }) else { return fail("queued_item_not_found") }
    guard let button = agQueued(window, verb).first(where: { agSameQueued($0.1, text) })?.0 else { return fail(missing) }
    if !AXHelper.press(button), let f = AXHelper.frame(button) { postLeftClick(at: CGPoint(x: f.midX, y: f.midY)) }
    var after = items
    for _ in 0..<15 {
        Thread.sleep(forTimeInterval: 0.2)
        after = agQueued(window).map { $0.1 }
        if after.count < items.count || !after.contains(where: { agSameQueued($0, text) }) {
            var r = AGResult(ok: true, reason: done, mayHaveSent: verb == "Send now"); r.queuedItems = after; return agResponse(r)
        }
    }
    var r = AGResult(ok: false, reason: verb == "Send now" ? "steer_invoke_failed" : "delete_invoke_failed", mayHaveSent: verb == "Send now")
    r.queuedItems = after
    return agResponse(r)
}

private func agMatchingTextCount(_ window: AXUIElement, _ text: String) -> Int {
    let want = agNorm(text)
    if want.isEmpty { return 0 }
    return agFindAll(window) { el, role, _ in
        role == kAXStaticTextRole && agNorm(AXHelper.valueStr(el).isEmpty ? AXHelper.label(el) : AXHelper.valueStr(el)) == want
    }.count
}

private func agClearBox(_ box: AXUIElement) {
    postKey(CGKeyCode(kVK_ANSI_A), flags: .maskCommand)
    Thread.sleep(forTimeInterval: 0.05)
    postKey(CGKeyCode(kVK_Delete))
    Thread.sleep(forTimeInterval: 0.15)
}

/// Open the conversation in the window and wait until its page shows it.
private func agOpen(_ window: AXUIElement, id: String) -> Bool {
    if agCurrentId(window) == id { return true }
    var link = agLink(window, id: id)
    if link == nil {
        // A project lists only its latest conversations behind "See all (N)".
        for more in agFindAll(window, { _, role, label in role == kAXButtonRole && label.range(of: "^See all \\(\\d+\\)$", options: .regularExpression) != nil }) {
            _ = AXHelper.press(more)
            Thread.sleep(forTimeInterval: 0.3)
            if let l = agLink(window, id: id) { link = l; break }
        }
    }
    guard let target = link else { return false }
    AXHelper.scrollToVisible(target)
    if !AXHelper.press(target), let f = AXHelper.frame(target) { postLeftClick(at: CGPoint(x: f.midX, y: f.midY)) }
    for _ in 0..<30 {
        Thread.sleep(forTimeInterval: 0.15)
        if agCurrentId(window) == id { return true }
    }
    return false
}

func handleAntigravity(_ req: AdapterRequest, transportId: UInt64?, writeLine: (String) -> Void) -> AdapterResponse {
    guard let app = runningAntigravityApp() else { return agFail("not_running") }
    guard let window = agWindow(app) else { return agFail("not_running") }
    let mode = (req.mode ?? "send").lowercased()
    let id = (req.threadId ?? "").lowercased()

    switch mode {
    case "inspect":
        if req.text == "windows" {
            var lines: [String] = []
            for w in AXHelper.windows(AXHelper.appElement(for: app)) {
                let f = AXHelper.frame(w) ?? .zero
                lines.append("WIN title=\(AXHelper.title(w)) frame=(\(Int(f.minX)),\(Int(f.minY)),\(Int(f.width))x\(Int(f.height)))")
                for area in agWebAreas(w) { lines.append("  AREA url=\(String(AXHelper.urlStr(area).prefix(160)))") }
                let links = agFindAll(w) { _, role, _ in role == "AXLink" }.prefix(12)
                for l in links { lines.append("  LINK \(String(AXHelper.label(l).prefix(40))) url=\(String(AXHelper.urlStr(l).prefix(120)))") }
                for b in agFindAll(w, { _, role, _ in role == kAXButtonRole }).prefix(60) {
                    let f = AXHelper.frame(b) ?? .zero
                    lines.append("  BUTTON \(String(AXHelper.label(b).prefix(40)))\(AXHelper.isEnabled(b) ? "" : " (disabled)") at=(\(Int(f.midX)),\(Int(f.midY)))")
                }
                if let box = agMessageBox(w), let f = AXHelper.frame(box) { lines.append("  BOX at=(\(Int(f.minX)),\(Int(f.minY)),\(Int(f.width))x\(Int(f.height)))") }
            }
            return agResponse(AGResult(ok: true, reason: "inspected", mayHaveSent: false, conversationId: agCurrentId(window)), controls: lines)
        }
        if req.text == "page" {
            // Every control of the page itself (the web area nested in 2.35's blank wrapper).
            var lines: [String] = []
            let root = agWebAreas(window).last { AXHelper.urlStr($0).hasPrefix("http") } ?? window
            AXHelper.walk(root, maxDepth: 80, maxNodes: 30000) { el, depth in
                let role = AXHelper.role(el)
                let label = AXHelper.label(el).replacingOccurrences(of: "\n", with: " ")
                let skip = role == kAXStaticTextRole || role == kAXGroupRole || role == "AXGenericElement" || role.isEmpty
                if !skip || (role == kAXStaticTextRole && req.idleSeconds == 1 && !label.isEmpty) {
                    let f = AXHelper.frame(el) ?? .zero
                    var parts = ["d=\(depth)", role, "lbl=\(String(label.prefix(80)))", "at=(\(Int(f.minX)),\(Int(f.minY)),\(Int(f.width))x\(Int(f.height)))"]
                    let url = AXHelper.urlStr(el); if !url.isEmpty { parts.append("url=\(String(url.prefix(100)))") }
                    let v = AXHelper.valueStr(el); if !v.isEmpty && v != label { parts.append("v=\(String(v.prefix(60)))") }
                    if !AXHelper.isEnabled(el) { parts.append("disabled") }
                    lines.append(parts.joined(separator: " | "))
                }
                return lines.count < 1500
            }
            return agResponse(AGResult(ok: true, reason: "inspected", mayHaveSent: false, conversationId: agCurrentId(window)), controls: lines)
        }
        return agResponse(AGResult(ok: true, reason: "inspected", mayHaveSent: false, conversationId: agCurrentId(window)), controls: dumpControls(for: app, window: window, mode: req.text))
    case "list":
        let ids = agFindAll(window) { el, role, _ in role == "AXLink" && agConversationId(inURL: AXHelper.urlStr(el)) != nil }
            .compactMap { agConversationId(inURL: AXHelper.urlStr($0)) }
        return agResponse(AGResult(ok: true, reason: "listed", mayHaveSent: false, ids: Array(NSOrderedSet(array: ids)) as? [String]))
    case "probe", "open":
        guard !id.isEmpty else { return agFail("conversation_not_in_sidebar") }
        if mode == "probe" {
            let open = agCurrentId(window) == id
            let known = open || agLink(window, id: id) != nil
            if !known { return agFail("conversation_not_in_sidebar") }
            let box = open ? agMessageBox(window) : nil
            let send = open ? agSendButton(window, box: box) : nil
            var r = AGResult(ok: true, reason: "probed", mayHaveSent: false, conversationId: agCurrentId(window))
            r.sendEnabled = send.map { AXHelper.isEnabled($0) }
            if open && box == nil { return agFail("no_message_box") }
            return agResponse(r)
        }
        return agOpen(window, id: id) ? agResponse(AGResult(ok: true, reason: "opened", mayHaveSent: false, conversationId: id)) : agFail("conversation_not_opened")
    case "queue", "steer", "cancel_queued":
        guard !id.isEmpty, agOpen(window, id: id) else { return agFail("conversation_not_opened") }
        if mode == "queue" {
            var r = AGResult(ok: true, reason: "queue", mayHaveSent: false, conversationId: id)
            r.queuedItems = agQueued(window).map { $0.1 }
            return agResponse(r)
        }
        return mode == "steer"
            ? agQueuedAction(window, text: req.text ?? "", verb: "Send now", done: "steered", missing: "steer_button_not_found")
            : agQueuedAction(window, text: req.text ?? "", verb: "Delete", done: "deleted", missing: "delete_button_not_found")
    case "stop":
        guard !id.isEmpty, agOpen(window, id: id) else { return agFail("conversation_not_opened") }
        // The composer's own cancel ("Cancel (⌃C)" in 2.35, "Cancel (Ctrl+C)"
        // before), the one nearest the message box. A bare "Cancel" can be any
        // dialog's. Else this conversation's own sidebar row "Stop execution".
        let box = agMessageBox(window)
        let composerStop = try! NSRegularExpression(pattern: "^(stop task|stop generation|stop response|(stop|cancel) \\((ctrl\\+|⌃)\\w\\))$", options: [.caseInsensitive])
        func isComposerStop(_ label: String) -> Bool { composerStop.firstMatch(in: label, range: NSRange(label.startIndex..., in: label)) != nil }
        let anchor = box.flatMap { AXHelper.frame($0) }
        func findStop() -> AXUIElement? {
            if let near = agFindAll(window, { _, role, label in role == kAXButtonRole && isComposerStop(label) }).min(by: { l, r in
                guard let a = anchor, let lf = AXHelper.frame(l), let rf = AXHelper.frame(r) else { return false }
                return hypot(lf.midX - a.maxX, lf.midY - a.maxY) < hypot(rf.midX - a.maxX, rf.midY - a.maxY)
            }) { return near }
            guard let row = agLink(window, id: id).flatMap({ AXHelper.frame($0) }) else { return nil }
            return agFindAll(window) { el, role, label in
                guard role == kAXButtonRole, label.lowercased() == "stop execution", let f = AXHelper.frame(el) else { return false }
                return f.midY >= row.minY - 4 && f.midY <= row.maxY + 4
            }.first
        }
        guard let button = findStop() else { return agFail("no_stop_button") }
        if !AXHelper.press(button), let f = AXHelper.frame(button) { postLeftClick(at: CGPoint(x: f.midX, y: f.midY)) }
        for _ in 0..<15 {
            Thread.sleep(forTimeInterval: 0.2)
            if findStop() == nil { return agResponse(AGResult(ok: true, reason: "stopped", mayHaveSent: true)) }
        }
        return agFail("stop_not_confirmed", mayHaveSent: true)
    case "send", "check":
        return agSend(app: app, window: window, id: id, req: req, check: mode == "check", transportId: transportId, writeLine: writeLine)
    case "settings", "set":
        guard !id.isEmpty, agOpen(window, id: id) else { return agFail("conversation_not_opened") }
        let target = { agCurrentId(window) == id }
        return agWithFront(app) { mode == "settings" ? agReadSettings(window, app: app, onTarget: target) : agApplySettings(window, app: app, req: req, onTarget: target) }
    case "new":
        return agWithFront(app) { agNew(app: app, window: window, req: req, transportId: transportId, writeLine: writeLine) }
    default:
        return agFail("unsupported_on_mac")
    }
}

private func agSend(app: NSRunningApplication, window: AXUIElement, id: String, req: AdapterRequest, check: Bool, transportId: UInt64?, writeLine: (String) -> Void) -> AdapterResponse {
    let text = req.text ?? ""
    let images = (req.attachments ?? []).map { $0.path }
    let hasText = !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    if !hasText && images.isEmpty { return agFail("empty_message") }
    if let idle = req.idleSeconds, idle > 0, userIdleSeconds() < Double(idle) { return agFail("user_active") }
    for path in images where !FileManager.default.fileExists(atPath: path) { return agFail("image_missing") }
    guard !id.isEmpty else { return agFail("conversation_not_in_sidebar") }
    guard agOpen(window, id: id) else {
        return agFail(agLink(window, id: id) == nil && agCurrentId(window) != id ? "conversation_not_in_sidebar" : "conversation_not_opened")
    }
    guard let box = agMessageBox(window) else { return agFail("no_message_box") }
    if !agBoxText(box).isEmpty { return agFail("draft_in_box") }

    let previousFront = frontmostApp()
    defer {
        if let prev = previousFront, prev.processIdentifier != app.processIdentifier {
            onMain { if #available(macOS 14.0, *) { _ = prev.activate() } else { _ = prev.activate(options: []) } }
        }
    }
    guard activateAndFocus(app, window: window, editor: box) else { return agFail(images.isEmpty ? "needs_foreground" : "image_needs_foreground") }
    let saved = saveClipboard()
    defer { restoreClipboard(saved) }
    let before = hasText ? agMatchingTextCount(window, text) : 0
    let queuedBefore = agQueued(window).count

    if !images.isEmpty {
        let pb = NSPasteboard.general
        pb.clearContents()
        pb.writeObjects(images.map { URL(fileURLWithPath: $0) as NSURL })
        postKey(CGKeyCode(kVK_ANSI_V), flags: .maskCommand)
        Thread.sleep(forTimeInterval: 0.6)
    }
    if hasText {
        guard agCurrentId(window) == id else { return agFail("conversation_not_opened") }
        let pb = NSPasteboard.general
        pb.clearContents()
        pb.setString(text, forType: .string)
        postKey(CGKeyCode(kVK_ANSI_V), flags: .maskCommand)
        var taken = false
        for _ in 0..<10 {
            Thread.sleep(forTimeInterval: 0.15)
            if agNorm(agBoxText(box)) == agNorm(text) { taken = true; break }
        }
        if !taken { if !agBoxText(box).isEmpty { agClearBox(box) }; return agFail("text_not_taken") }
    }
    var send: AXUIElement?
    for i in 0..<(images.isEmpty ? 10 : 20) {
        send = agSendButton(window, box: box)
        if let s = send, AXHelper.isEnabled(s) { break }
        // The editor can keep Send disabled until it sees a typed key after a
        // paste: type a space and take it back once.
        if i == 6 && hasText {
            postKey(CGKeyCode(kVK_End), flags: .maskCommand)
            postKey(CGKeyCode(kVK_Space)); Thread.sleep(forTimeInterval: 0.05); postKey(CGKeyCode(kVK_Delete))
        }
        Thread.sleep(forTimeInterval: 0.15)
    }
    if check {
        let enabled = send.map { AXHelper.isEnabled($0) } ?? false
        agClearBox(box)
        var r = AGResult(ok: true, reason: "checked", mayHaveSent: false)
        r.sendEnabled = enabled
        return agResponse(r)
    }
    guard let sendButton = send, AXHelper.isEnabled(sendButton) else {
        agClearBox(box)
        return agFail(hasText ? "send_unavailable" : "image_paste_failed")
    }
    guard agCurrentId(window) == id else { agClearBox(box); return agFail("conversation_not_opened") }
    emitWritePhase(transportId, writeLine: writeLine)
    _ = AXHelper.press(sendButton)
    for _ in 0..<15 {
        Thread.sleep(forTimeInterval: 0.2)
        let current = agMessageBox(window)
        let cleared = current.map { agBoxText($0).isEmpty } ?? false
        let shown = !hasText || agMatchingTextCount(window, text) > before
        let queue = agQueued(window).map { $0.1 }
        // While a turn runs, Antigravity holds the message in its queue.
        let queued = queue.count > queuedBefore || (hasText && queue.contains { agSameQueued($0, text) })
        if cleared && (shown || queued) {
            var steered = false, items = queue
            if queued && req.steerNow == true {
                let r = agQueuedAction(window, text: text, verb: "Send now", done: "steered", missing: "steer_button_not_found")
                if r.ok { steered = true; items = agQueued(window).map { $0.1 } }
            }
            var result = AGResult(ok: true, reason: "confirmed", mayHaveSent: true, receiptSource: "window", confirmedAt: Date().timeIntervalSince1970 * 1000, queuedInWindow: queued && !steered, steered: steered)
            result.queuedItems = items
            return agResponse(result)
        }
    }
    return agResponse(AGResult(ok: true, reason: "clicked", mayHaveSent: true))
}

// MARK: - Selectors under the message box: model, permission preset, project
//
// "Select model, current: Gemini 4 Hydrogen High", "Agent permissions preset
// selector, current: Auto" and, on the New Conversation page, "Select
// project, current: No Project" are pop-up buttons. Each opens a menu named
// like its button. A model row with thinking levels has AXPopupValue "menu":
// its levels open in a submenu named like the row (hover, then Right).

private let agPresetNames = ["Request Review", "Default", "Auto", "Turbo"]

/// Run with Antigravity in front (menus need it), then give the front back.
private func agWithFront(_ app: NSRunningApplication, _ body: () -> AdapterResponse) -> AdapterResponse {
    let previous = frontmostApp()
    defer {
        if let prev = previous, prev.processIdentifier != app.processIdentifier {
            onMain { if #available(macOS 14.0, *) { _ = prev.activate() } else { _ = prev.activate(options: []) } }
        }
    }
    if frontmostApp()?.processIdentifier != app.processIdentifier {
        onMain { if #available(macOS 14.0, *) { _ = app.activate() } else { _ = app.activate(options: []) } }
        Thread.sleep(forTimeInterval: 0.3)
    }
    return body()
}

private func agSelector(_ window: AXUIElement, _ prefix: String) -> AXUIElement? {
    agFind(window) { _, role, label in (role == kAXPopUpButtonRole || role == kAXButtonRole) && label.hasPrefix(prefix) }
}

private func agCurrentOf(_ button: AXUIElement?) -> String {
    guard let b = button else { return "" }
    let label = AXHelper.label(b)
    guard let r = label.range(of: "current:") else { return "" }
    var current = label[r.upperBound...].trimmingCharacters(in: .whitespaces)
    // While a turn runs: "Gemini 3.8 Flash Low. Applies to /btw and messages sent after this turn".
    if let note = current.range(of: ". ") { current = String(current[..<note.lowerBound]) }
    return current
}

/// The open menu named `name`, if any.
private func agMenu(_ window: AXUIElement, named name: String) -> AXUIElement? {
    agFind(window) { _, role, label in role == kAXMenuRole && label == name }
}

/// The nearest menu around a row.
private func agEnclosingMenu(_ el: AXUIElement) -> AXUIElement? {
    var node = AXHelper.parent(el)
    for _ in 0..<8 {
        guard let n = node else { return nil }
        if AXHelper.role(n) == kAXMenuRole { return n }
        node = AXHelper.parent(n)
    }
    return nil
}

/// The rows of the open menu of the selector named `name`: in a menu named
/// like it, or (the model menu of 2.35 has no name) in an unnamed one. Rows
/// of a submenu (named like its row) are not counted.
private func agOpenRows(_ window: AXUIElement, named name: String) -> [AXUIElement] {
    agFindAll(window) { el, role, label in
        guard role == kAXMenuItemRole, !label.isEmpty, label != "View Usage" else { return false }
        let menuName = agEnclosingMenu(el).map { AXHelper.label($0) } ?? ""
        return menuName == name || menuName.isEmpty
    }
}

private func agPressOrClick(_ el: AXUIElement) {
    if !AXHelper.press(el), let f = AXHelper.frame(el) { postLeftClick(at: CGPoint(x: f.midX, y: f.midY)) }
}

/// Open the selector's menu (if it is not open yet) and return its rows.
private func agOpenMenu(_ window: AXUIElement, _ prefix: String) -> [AXUIElement] {
    guard let button = agSelector(window, prefix) else { return [] }
    let name = AXHelper.label(button)
    if agOpenRows(window, named: name).isEmpty { agPressOrClick(button) }
    for _ in 0..<20 {
        let rows = agOpenRows(window, named: name)
        if !rows.isEmpty { return rows }
        Thread.sleep(forTimeInterval: 0.15)
    }
    return []
}

private func agCloseMenu(_ window: AXUIElement, _ prefix: String) {
    guard let button = agSelector(window, prefix) else { return }
    let name = AXHelper.label(button)
    if !agOpenRows(window, named: name).isEmpty {
        postKey(CGKeyCode(kVK_Escape))
        Thread.sleep(forTimeInterval: 0.2)
        if !agOpenRows(window, named: name).isEmpty { postKey(CGKeyCode(kVK_Escape)); Thread.sleep(forTimeInterval: 0.2) }
        if !agOpenRows(window, named: name).isEmpty { agPressOrClick(button); Thread.sleep(forTimeInterval: 0.2) }
    }
}

private func agHasLevels(_ row: AXUIElement) -> Bool {
    AXHelper.stringAttr(row, "AXPopupValue") == "menu"
}

/// The thinking levels of a model row (its submenu's rows), the submenu left open.
private func agLevelRows(_ window: AXUIElement, row: AXUIElement) -> [AXUIElement] {
    let name = AXHelper.label(row)
    for _ in 0..<2 {
        if agMenu(window, named: name) == nil {
            if let f = AXHelper.frame(row) {
                CGEvent(mouseEventSource: nil, mouseType: .mouseMoved, mouseCursorPosition: CGPoint(x: f.midX, y: f.midY), mouseButton: .left)?.post(tap: .cghidEventTap)
            }
            Thread.sleep(forTimeInterval: 0.3)
            AXUIElementSetAttributeValue(row, kAXFocusedAttribute as CFString, kCFBooleanTrue)
            if agMenu(window, named: name) == nil { postKey(CGKeyCode(kVK_RightArrow)) }
        }
        for _ in 0..<10 {
            Thread.sleep(forTimeInterval: 0.15)
            if let sub = agMenu(window, named: name) {
                var rows: [AXUIElement] = []
                AXHelper.walk(sub, maxDepth: 12, maxNodes: 2000) { el, _ in
                    if AXHelper.role(el) == kAXMenuItemRole && !AXHelper.label(el).isEmpty { rows.append(el) }
                    return true
                }
                if !rows.isEmpty { return rows }
            }
        }
    }
    return []
}

/// "Gemini 4 Hydrogen High New" -> ("Gemini 4 Hydrogen High", available). The
/// tags after the name change between releases ("Notice", "New", "Leaving
/// Soon", "Paid Pro", "Unavailable"); a disabled row is not available.
private func agModelRowName(_ row: AXUIElement) -> (String, Bool) {
    var name = agNorm(AXHelper.label(row))
    var unavailable = !AXHelper.isEnabled(row)
    let tags = ["Leaving Soon", "Paid Pro", "Unavailable", "Notice", "New"]
    var stripped = true
    while stripped {
        stripped = false
        for tag in tags where name.hasSuffix(" " + tag) {
            name = String(name.dropLast(tag.count + 1)).trimmingCharacters(in: .whitespaces)
            if tag == "Unavailable" { unavailable = true }
            stripped = true
        }
    }
    return (name, !unavailable)
}

private func agPresetOf(_ row: AXUIElement) -> AGPreset? {
    let label = agNorm(AXHelper.label(row))
    for p in agPresetNames where label == p || label.hasPrefix(p + " ") {
        var rest = String(label.dropFirst(p.count)).trimmingCharacters(in: .whitespaces)
        let isDefault = rest == "Default" || rest.hasPrefix("Default ")
        if isDefault { rest = String(rest.dropFirst("Default".count)).trimmingCharacters(in: .whitespaces) }
        return AGPreset(name: p, detail: rest, isDefault: isDefault)
    }
    return nil
}

private func agWaitCurrent(_ window: AXUIElement, _ prefix: String, _ wanted: String) -> Bool {
    for _ in 0..<15 {
        Thread.sleep(forTimeInterval: 0.15)
        if agCurrentOf(agSelector(window, prefix)) == wanted { return true }
    }
    return false
}

private func agReadSettings(_ window: AXUIElement, app: NSRunningApplication, onTarget: () -> Bool) -> AdapterResponse {
    let modelButton = agSelector(window, "Select model")
    let presetButton = agSelector(window, "Agent permissions preset")
    if modelButton == nil && presetButton == nil { return agFail("no_settings") }
    var models: [AGModel] = []
    if modelButton != nil {
        let labels = agOpenMenu(window, "Select model").map { AXHelper.label($0) }
        for label in labels {
            guard onTarget() else { agCloseMenu(window, "Select model"); return agFail("conversation_not_opened") }
            // Rows are found again each time: a closed submenu can replace them.
            guard let row = agOpenMenu(window, "Select model").first(where: { AXHelper.label($0) == label }) else {
                agCloseMenu(window, "Select model"); return agFail("model_list_changed")
            }
            let (name, available) = agModelRowName(row)
            var option = AGModel(name: name, available: available)
            if available && agHasLevels(row) {
                let levels = agLevelRows(window, row: row).map { agNorm(AXHelper.label($0)) }
                if levels.isEmpty { continue }
                for level in levels.sorted(by: { $0.count > $1.count }) where name.hasSuffix(" " + level) {
                    option.name = String(name.dropLast(level.count + 1)); option.level = level; break
                }
                option.levels = levels
                postKey(CGKeyCode(kVK_LeftArrow))
                Thread.sleep(forTimeInterval: 0.15)
            }
            models.append(option)
        }
        agCloseMenu(window, "Select model")
        if models.isEmpty { return agFail("model_list_changed") }
    }
    var presets: [AGPreset] = []
    if presetButton != nil {
        presets = agOpenMenu(window, "Agent permissions preset").compactMap { agPresetOf($0) }
        agCloseMenu(window, "Agent permissions preset")
    }
    guard onTarget() else { return agFail("conversation_not_opened") }
    var r = AGResult(ok: true, reason: "settings", mayHaveSent: false)
    r.model = agCurrentOf(agSelector(window, "Select model"))
    r.permission = agCurrentOf(agSelector(window, "Agent permissions preset"))
    r.models = models
    r.permissions = presets
    return agResponse(r)
}

/// Choose a model (and thinking level). "ok" or the failure reason.
private func agChooseModel(_ window: AXUIElement, wanted: String, level wantedLevel: String) -> String {
    let current = agCurrentOf(agSelector(window, "Select model"))
    if (wantedLevel.isEmpty && current == wanted) || (!wantedLevel.isEmpty && current == "\(wanted) \(wantedLevel)") { return "ok" }
    let rows = agOpenMenu(window, "Select model")
    var target: AXUIElement?
    var shownName = ""
    for row in rows {
        let (name, available) = agModelRowName(row)
        if !available { continue }
        if name == wanted || (agHasLevels(row) && name.hasPrefix(wanted + " ")) { target = row; shownName = name; break }
    }
    guard let row = target else { agCloseMenu(window, "Select model"); return "model_not_set" }
    if !agHasLevels(row) {
        agPressOrClick(row)
        return agWaitCurrent(window, "Select model", wanted) ? "ok" : "model_not_set"
    }
    let levels = agLevelRows(window, row: row)
    var level = wantedLevel
    if level.isEmpty && shownName != wanted { level = String(shownName.dropFirst(wanted.count + 1)) }
    guard let pick = levels.first(where: { agNorm(AXHelper.label($0)) == level }) else {
        agCloseMenu(window, "Select model"); return "level_not_set"
    }
    agPressOrClick(pick)
    return agWaitCurrent(window, "Select model", "\(wanted) \(level)") ? "ok" : "level_not_set"
}

private func agChoosePreset(_ window: AXUIElement, wanted: String) -> Bool {
    if agCurrentOf(agSelector(window, "Agent permissions preset")) == wanted { return true }
    guard let row = agOpenMenu(window, "Agent permissions preset").first(where: { agPresetOf($0)?.name == wanted }) else {
        agCloseMenu(window, "Agent permissions preset"); return false
    }
    agPressOrClick(row)
    return agWaitCurrent(window, "Agent permissions preset", wanted)
}

private func agApplySettings(_ window: AXUIElement, app: NSRunningApplication, req: AdapterRequest, onTarget: () -> Bool) -> AdapterResponse {
    let obj = agRequestObject(req)
    let model = agString(obj, "model"), level = agString(obj, "level"), permission = agString(obj, "permission")
    if model.isEmpty && permission.isEmpty { return agFail("bad_settings") }
    if !model.isEmpty {
        if agSelector(window, "Select model") == nil { return agFail("no_settings") }
        let outcome = agChooseModel(window, wanted: model, level: level)
        if outcome != "ok" {
            var r = AGResult(ok: false, reason: outcome, mayHaveSent: false)
            r.model = agCurrentOf(agSelector(window, "Select model"))
            return agResponse(r)
        }
    }
    if !permission.isEmpty {
        if agSelector(window, "Agent permissions preset") == nil { return agFail("no_settings") }
        if !agChoosePreset(window, wanted: permission) {
            var r = AGResult(ok: false, reason: "permission_not_set", mayHaveSent: false)
            r.permission = agCurrentOf(agSelector(window, "Agent permissions preset"))
            return agResponse(r)
        }
    }
    guard onTarget() else { return agFail("conversation_not_opened") }
    var r = AGResult(ok: true, reason: "set", mayHaveSent: false)
    r.model = agCurrentOf(agSelector(window, "Select model"))
    r.permission = agCurrentOf(agSelector(window, "Agent permissions preset"))
    return agResponse(r)
}

// MARK: - New conversation

/// The address of the page itself (not 2.35's blank wrapper).
private func agPageURL(_ window: AXUIElement) -> URLComponents? {
    for area in agWebAreas(window).reversed() {
        let s = AXHelper.urlStr(area)
        if s.hasPrefix("http"), let c = URLComponents(string: s) { return c }
    }
    return nil
}

private func agIsNewPage(_ window: AXUIElement) -> Bool {
    guard let url = agPageURL(window) else { return false }
    return url.path.isEmpty || url.path == "/"
}

private func agShownProjectId(_ window: AXUIElement) -> String {
    agPageURL(window)?.queryItems?.first(where: { $0.name == "project" })?.value ?? ""
}

private func agCurrentProjectName(_ window: AXUIElement) -> String {
    let current = agCurrentOf(agSelector(window, "Select project"))
    // "name (folder)": the menu lists only the name.
    if let r = current.range(of: "\\s+\\([^()]+\\)$", options: .regularExpression) { return String(current[..<r.lowerBound]) }
    return current
}

private func agProjectMatches(_ window: AXUIElement, id: String, name: String) -> Bool {
    if id.isEmpty && name.isEmpty { return true }
    let current = agCurrentProjectName(window)
    if id == "outside-of-project" { return current == "No Project" }
    if !id.isEmpty && agShownProjectId(window) == id { return true }
    return !name.isEmpty && current == name
}

/// The sidebar link to a new conversation: a project's own (?project=<id>)
/// or the plain one (path "/", no query).
private func agNewLink(_ window: AXUIElement, projectId: String) -> AXUIElement? {
    agFind(window) { el, role, _ in
        guard role == "AXLink", let url = URLComponents(string: AXHelper.urlStr(el)),
              ["127.0.0.1", "localhost"].contains(url.host ?? ""), url.path.isEmpty || url.path == "/" else { return false }
        let project = url.queryItems?.first(where: { $0.name == "project" })?.value ?? ""
        if projectId.isEmpty { return (url.query ?? "").isEmpty }
        return project == projectId
    }
}

private func agNew(app: NSRunningApplication, window: AXUIElement, req: AdapterRequest, transportId: UInt64?, writeLine: (String) -> Void) -> AdapterResponse {
    let obj = agRequestObject(req)
    let prompt = (obj["prompt"] as? String) ?? ""
    if prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return agFail("empty_message") }
    let projectId = agString(obj, "projectId"), projectName = agString(obj, "projectName")
    let model = agString(obj, "model"), level = agString(obj, "level"), permission = agString(obj, "permission")
    func fail(_ reason: String) -> AdapterResponse {
        var r = AGResult(ok: false, reason: reason, mayHaveSent: false)
        if reason == "project_not_selected" { r.currentProject = agCurrentProjectName(window) }
        return agResponse(r)
    }

    // 1. The New Conversation page, from the project's own link when there is one.
    var link: AXUIElement? = nil
    if !projectId.isEmpty && projectId != "outside-of-project" { link = agNewLink(window, projectId: projectId) }
    if link == nil { link = agNewLink(window, projectId: "") ?? agFind(window) { _, role, label in role == "AXLink" && label == "New Conversation" } }
    if let l = link { agPressOrClick(l) } else if !agIsNewPage(window) { return fail("new_conversation_unavailable") }
    var opened = false
    for _ in 0..<30 {
        Thread.sleep(forTimeInterval: 0.15)
        if agIsNewPage(window) && agMessageBox(window) != nil { opened = true; break }
    }
    if !agIsNewPage(window) { return fail("new_conversation_unavailable") }
    if !opened { return fail("no_message_box") }

    // 2. The project. A row can carry its own button's text after the name
    // ("No Project Project Settings").
    if !agProjectMatches(window, id: projectId, name: projectName) {
        let label = projectId == "outside-of-project" ? "No Project" : projectName
        if label.isEmpty || agSelector(window, "Select project") == nil { return fail("project_not_selected") }
        let rows = agOpenMenu(window, "Select project")
        guard let row = rows.first(where: { let l = agNorm(AXHelper.label($0)); return l == label || l.hasPrefix(label + " ") }) else {
            agCloseMenu(window, "Select project"); return fail("project_not_selected")
        }
        agPressOrClick(row)
        var matched = false
        for _ in 0..<15 {
            Thread.sleep(forTimeInterval: 0.15)
            if agProjectMatches(window, id: projectId, name: projectName) { matched = true; break }
        }
        if !matched { return fail("project_not_selected") }
    }

    // 3. Never overwrite a draft left in the box.
    guard let emptyBox = agMessageBox(window) else { return fail("no_message_box") }
    if !agBoxText(emptyBox).isEmpty { return fail("draft_in_box") }

    // 4. Model, thinking level and permission preset.
    if !model.isEmpty {
        if agSelector(window, "Select model") == nil { return fail("no_settings") }
        let outcome = agChooseModel(window, wanted: model, level: level)
        if outcome != "ok" {
            var r = AGResult(ok: false, reason: outcome, mayHaveSent: false)
            r.model = agCurrentOf(agSelector(window, "Select model"))
            return agResponse(r)
        }
    }
    if !permission.isEmpty {
        if agSelector(window, "Agent permissions preset") == nil { return fail("no_settings") }
        if !agChoosePreset(window, wanted: permission) { return fail("permission_not_set") }
    }

    // 5. Paste the prompt and Send.
    guard let target = agMessageBox(window), agIsNewPage(window) else { return fail("new_conversation_unavailable") }
    if !agProjectMatches(window, id: projectId, name: projectName) { return fail("project_not_selected") }
    guard activateAndFocus(app, window: window, editor: target) else { return fail("needs_foreground") }
    let saved = saveClipboard()
    defer { restoreClipboard(saved) }
    let pb = NSPasteboard.general
    pb.clearContents()
    pb.setString(prompt, forType: .string)
    postKey(CGKeyCode(kVK_ANSI_V), flags: .maskCommand)
    var taken = false
    for _ in 0..<10 {
        Thread.sleep(forTimeInterval: 0.15)
        if agNorm(agBoxText(target)) == agNorm(prompt) { taken = true; break }
    }
    if !taken { if !agBoxText(target).isEmpty { agClearBox(target) }; return fail("text_not_taken") }
    var send: AXUIElement?
    for i in 0..<12 {
        send = agSendButton(window, box: target)
        if let s = send, AXHelper.isEnabled(s) { break }
        if i == 6 {
            postKey(CGKeyCode(kVK_End), flags: .maskCommand)
            postKey(CGKeyCode(kVK_Space)); Thread.sleep(forTimeInterval: 0.05); postKey(CGKeyCode(kVK_Delete))
        }
        Thread.sleep(forTimeInterval: 0.15)
    }
    guard let sendButton = send, AXHelper.isEnabled(sendButton) else { agClearBox(target); return fail("send_unavailable") }
    guard agIsNewPage(window) else { agClearBox(target); return fail("new_conversation_unavailable") }
    emitWritePhase(transportId, writeLine: writeLine)
    _ = AXHelper.press(sendButton)

    // 6. The page moves from / to /c/<new id>.
    for _ in 0..<40 {
        Thread.sleep(forTimeInterval: 0.2)
        if let created = agCurrentId(window) {
            var r = AGResult(ok: true, reason: "created", mayHaveSent: true, receiptSource: "window", confirmedAt: Date().timeIntervalSince1970 * 1000, conversationId: created)
            r.model = agCurrentOf(agSelector(window, "Select model"))
            r.permission = agCurrentOf(agSelector(window, "Agent permissions preset"))
            r.project = agCurrentProjectName(window)
            return agResponse(r)
        }
    }
    return agResponse(AGResult(ok: true, reason: "clicked", mayHaveSent: true))
}
